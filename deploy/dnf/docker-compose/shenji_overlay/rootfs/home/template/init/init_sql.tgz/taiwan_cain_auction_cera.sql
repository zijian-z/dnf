-- generated from VMDK full dump
-- source_db=taiwan_cain_auction_cera

--



--
-- Table structure for table `auction_average_price`
--

DROP TABLE IF EXISTS `auction_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_average_price` (
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `average_price` int(11) DEFAULT NULL,
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`,`upgrade`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_average_price`
--

LOCK TABLES `auction_average_price` WRITE;
/*!40000 ALTER TABLE `auction_average_price` DISABLE KEYS */;
INSERT INTO `auction_average_price` VALUES (2675347,0,100000,0);
/*!40000 ALTER TABLE `auction_average_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history`
--

DROP TABLE IF EXISTS `auction_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `unit_price` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`auction_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history`
--

LOCK TABLES `auction_history` WRITE;
/*!40000 ALTER TABLE `auction_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201608`
--

DROP TABLE IF EXISTS `auction_history_201608`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201608` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`),
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201608`
--

LOCK TABLES `auction_history_201608` WRITE;
/*!40000 ALTER TABLE `auction_history_201608` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201608` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201903`
--

DROP TABLE IF EXISTS `auction_history_201903`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201903` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201903`
--

LOCK TABLES `auction_history_201903` WRITE;
/*!40000 ALTER TABLE `auction_history_201903` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201903` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201904`
--

DROP TABLE IF EXISTS `auction_history_201904`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201904` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201904`
--

LOCK TABLES `auction_history_201904` WRITE;
/*!40000 ALTER TABLE `auction_history_201904` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201904` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201905`
--

DROP TABLE IF EXISTS `auction_history_201905`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201905` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201905`
--

LOCK TABLES `auction_history_201905` WRITE;
/*!40000 ALTER TABLE `auction_history_201905` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201905` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201906`
--

DROP TABLE IF EXISTS `auction_history_201906`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201906` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201906`
--

LOCK TABLES `auction_history_201906` WRITE;
/*!40000 ALTER TABLE `auction_history_201906` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201906` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201907`
--

DROP TABLE IF EXISTS `auction_history_201907`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201907` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201907`
--

LOCK TABLES `auction_history_201907` WRITE;
/*!40000 ALTER TABLE `auction_history_201907` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201907` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201908`
--

DROP TABLE IF EXISTS `auction_history_201908`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201908` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201908`
--

LOCK TABLES `auction_history_201908` WRITE;
/*!40000 ALTER TABLE `auction_history_201908` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201908` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201909`
--

DROP TABLE IF EXISTS `auction_history_201909`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201909` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201909`
--

LOCK TABLES `auction_history_201909` WRITE;
/*!40000 ALTER TABLE `auction_history_201909` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201909` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201910`
--

DROP TABLE IF EXISTS `auction_history_201910`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201910` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201910`
--

LOCK TABLES `auction_history_201910` WRITE;
/*!40000 ALTER TABLE `auction_history_201910` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201910` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201911`
--

DROP TABLE IF EXISTS `auction_history_201911`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201911` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201911`
--

LOCK TABLES `auction_history_201911` WRITE;
/*!40000 ALTER TABLE `auction_history_201911` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201911` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_201912`
--

DROP TABLE IF EXISTS `auction_history_201912`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_201912` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(10) unsigned NOT NULL DEFAULT '0',
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE,
  KEY `idx_owner_id` (`owner_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_201912`
--

LOCK TABLES `auction_history_201912` WRITE;
/*!40000 ALTER TABLE `auction_history_201912` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_201912` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer`
--

DROP TABLE IF EXISTS `auction_history_buyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `commission` int(11) unsigned NOT NULL DEFAULT '0',
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer`
--

LOCK TABLES `auction_history_buyer` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201608`
--

DROP TABLE IF EXISTS `auction_history_buyer_201608`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201608` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201608`
--

LOCK TABLES `auction_history_buyer_201608` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201608` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201608` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201903`
--

DROP TABLE IF EXISTS `auction_history_buyer_201903`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201903` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201903`
--

LOCK TABLES `auction_history_buyer_201903` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201903` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201903` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201904`
--

DROP TABLE IF EXISTS `auction_history_buyer_201904`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201904` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201904`
--

LOCK TABLES `auction_history_buyer_201904` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201904` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201904` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201905`
--

DROP TABLE IF EXISTS `auction_history_buyer_201905`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201905` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201905`
--

LOCK TABLES `auction_history_buyer_201905` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201905` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201905` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201906`
--

DROP TABLE IF EXISTS `auction_history_buyer_201906`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201906` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201906`
--

LOCK TABLES `auction_history_buyer_201906` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201906` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201906` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201907`
--

DROP TABLE IF EXISTS `auction_history_buyer_201907`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201907` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201907`
--

LOCK TABLES `auction_history_buyer_201907` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201907` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201907` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201908`
--

DROP TABLE IF EXISTS `auction_history_buyer_201908`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201908` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201908`
--

LOCK TABLES `auction_history_buyer_201908` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201908` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201908` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201909`
--

DROP TABLE IF EXISTS `auction_history_buyer_201909`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201909` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201909`
--

LOCK TABLES `auction_history_buyer_201909` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201909` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201909` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201910`
--

DROP TABLE IF EXISTS `auction_history_buyer_201910`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201910` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201910`
--

LOCK TABLES `auction_history_buyer_201910` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201910` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201910` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201911`
--

DROP TABLE IF EXISTS `auction_history_buyer_201911`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201911` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201911`
--

LOCK TABLES `auction_history_buyer_201911` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201911` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201911` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history_buyer_201912`
--

DROP TABLE IF EXISTS `auction_history_buyer_201912`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer_201912` (
  `auction_id` bigint(20) unsigned DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `pre_buyer_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `pre_price` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `pre_buyer_postal_id` int(10) unsigned DEFAULT NULL,
  KEY `idx_auction_id` (`auction_id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history_buyer_201912`
--

LOCK TABLES `auction_history_buyer_201912` WRITE;
/*!40000 ALTER TABLE `auction_history_buyer_201912` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history_buyer_201912` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_main`
--

DROP TABLE IF EXISTS `auction_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_main` (
  `auction_id` bigint(20) NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `expire_time` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `owner_name` varchar(20) DEFAULT NULL,
  `owner_type` tinyint(4) NOT NULL DEFAULT '0',
  `owner_nexon_id` varchar(25) NOT NULL DEFAULT '',
  `buyer_id` int(11) DEFAULT NULL,
  `buyer_name` varchar(20) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `instant_price` bigint(20) DEFAULT NULL,
  `seal_flag` tinyint(3) unsigned DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `black_point` int(10) unsigned NOT NULL DEFAULT '0',
  `unit_price` int(11) DEFAULT NULL,
  `random_option` varchar(14) NOT NULL DEFAULT '',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(11) NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` varbinary(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`auction_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_main`
--

LOCK TABLES `auction_main` WRITE;
/*!40000 ALTER TABLE `auction_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_manual_average_price`
--

DROP TABLE IF EXISTS `auction_manual_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_manual_average_price` (
  `no` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `upgrade` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `average_price` int(11) unsigned NOT NULL DEFAULT '0',
  `is_apply` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_serverid_isapply` (`is_apply`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_manual_average_price`
--

LOCK TABLES `auction_manual_average_price` WRITE;
/*!40000 ALTER TABLE `auction_manual_average_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_manual_average_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_roi_average_price`
--

DROP TABLE IF EXISTS `auction_roi_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_roi_average_price` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `roi_high_key` bigint(20) NOT NULL DEFAULT '0',
  `roi_low_key` int(10) unsigned NOT NULL DEFAULT '0',
  `roi_index1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `roi_index2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `roi_index3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `average_price` int(10) unsigned NOT NULL DEFAULT '0',
  `real_purchase_count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  UNIQUE KEY `item_id` (`item_id`,`upgrade`,`roi_high_key`,`roi_low_key`,`roi_index1`,`roi_index2`,`roi_index3`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_roi_average_price`
--

LOCK TABLES `auction_roi_average_price` WRITE;
/*!40000 ALTER TABLE `auction_roi_average_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_roi_average_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_roi_constraint`
--

DROP TABLE IF EXISTS `auction_roi_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_roi_constraint` (
  `db_inf_max_price` int(10) unsigned NOT NULL DEFAULT '0',
  `db_inf_min_price` int(10) unsigned NOT NULL DEFAULT '0',
  `db_inf_prob` int(10) unsigned NOT NULL DEFAULT '0',
  `db_inf_limit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `db_inf_base_mul_min_a` int(10) unsigned NOT NULL DEFAULT '0',
  `db_inf_base_mul_max_b` int(10) unsigned NOT NULL DEFAULT '0',
  `last_update_date` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_roi_constraint`
--

LOCK TABLES `auction_roi_constraint` WRITE;
/*!40000 ALTER TABLE `auction_roi_constraint` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_roi_constraint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_system_iteminfo`
--

DROP TABLE IF EXISTS `auction_system_iteminfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_system_iteminfo` (
  `sys_auction_id` int(11) DEFAULT '0',
  `probability` smallint(5) unsigned DEFAULT '0',
  `price` int(11) DEFAULT '0',
  `seal_flag` tinyint(3) unsigned DEFAULT '0',
  `item_id` int(10) unsigned DEFAULT '0',
  `add_info` int(11) DEFAULT '0',
  `upgrade` tinyint(3) unsigned DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT '0',
  `endurance` smallint(5) unsigned DEFAULT '0',
  `extend_info` int(10) unsigned DEFAULT '0',
  KEY `idx1` (`sys_auction_id`,`item_id`) USING BTREE,
  KEY `idx2` (`item_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_system_iteminfo`
--

LOCK TABLES `auction_system_iteminfo` WRITE;
/*!40000 ALTER TABLE `auction_system_iteminfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_system_iteminfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_system_main`
--

DROP TABLE IF EXISTS `auction_system_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_system_main` (
  `sys_auction_id` int(11) NOT NULL AUTO_INCREMENT,
  `occ_time` datetime DEFAULT '0000-00-00 00:00:00',
  `regist_interval` int(11) DEFAULT '0',
  `regist_time` time DEFAULT '00:00:00',
  `start_date` date DEFAULT '0000-00-00',
  `end_date` date DEFAULT '0000-00-00',
  `expire_interval` smallint(5) unsigned DEFAULT '0',
  `last_auction_time` datetime DEFAULT '0000-00-00 00:00:00',
  `expected_regist_time` time DEFAULT '00:00:00',
  PRIMARY KEY (`sys_auction_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_system_main`
--

LOCK TABLES `auction_system_main` WRITE;
/*!40000 ALTER TABLE `auction_system_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_system_main` ENABLE KEYS */;
UNLOCK TABLES;

--
