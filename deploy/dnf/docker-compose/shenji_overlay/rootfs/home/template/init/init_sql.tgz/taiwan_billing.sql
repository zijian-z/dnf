-- generated from VMDK full dump
-- source_db=taiwan_billing

--



--
-- Table structure for table `cash_cera`
--

DROP TABLE IF EXISTS `cash_cera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_cera` (
  `account` varchar(30) NOT NULL,
  `cera` int(10) unsigned NOT NULL,
  `mod_tran` bigint(20) unsigned NOT NULL,
  `mod_date` datetime NOT NULL,
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`account`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_cera`
--

LOCK TABLES `cash_cera` WRITE;
/*!40000 ALTER TABLE `cash_cera` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_cera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_cera_point`
--

DROP TABLE IF EXISTS `cash_cera_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_cera_point` (
  `account` varchar(30) NOT NULL DEFAULT '',
  `cera_point` int(10) unsigned NOT NULL,
  `reg_date` datetime NOT NULL,
  `mod_date` datetime NOT NULL,
  PRIMARY KEY (`account`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_cera_point`
--

LOCK TABLES `cash_cera_point` WRITE;
/*!40000 ALTER TABLE `cash_cera_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_cera_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_transaction`
--

DROP TABLE IF EXISTS `cash_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_transaction` (
  `tran_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dummy` char(1) NOT NULL,
  PRIMARY KEY (`tran_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_transaction`
--

LOCK TABLES `cash_transaction` WRITE;
/*!40000 ALTER TABLE `cash_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cs_table2`
--

DROP TABLE IF EXISTS `cs_table2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cs_table2` (
  `account_id` char(30) NOT NULL,
  `charac_id` char(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cs_table2`
--

LOCK TABLES `cs_table2` WRITE;
/*!40000 ALTER TABLE `cs_table2` DISABLE KEYS */;
/*!40000 ALTER TABLE `cs_table2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_error_history`
--

DROP TABLE IF EXISTS `log_error_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_error_history` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `error_id` int(10) NOT NULL,
  `error_msg` varchar(255) NOT NULL,
  `error_query` varchar(512) NOT NULL,
  `proc_name` varchar(45) NOT NULL,
  `proc_line` int(10) NOT NULL,
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_error_history`
--

LOCK TABLES `log_error_history` WRITE;
/*!40000 ALTER TABLE `log_error_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_error_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gift_history`
--

DROP TABLE IF EXISTS `log_gift_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gift_history` (
  `tran_id` bigint(20) unsigned NOT NULL,
  `tran_state` tinyint(3) unsigned NOT NULL,
  `send_account_id` varchar(30) NOT NULL,
  `send_charac_id` varchar(30) NOT NULL,
  `recv_account_id` varchar(30) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `cera` int(10) unsigned NOT NULL,
  `send_befor_cera` int(10) unsigned NOT NULL,
  `send_after_cera` int(10) unsigned NOT NULL,
  `recv_befor_cera` int(10) unsigned NOT NULL,
  `recv_after_cera` int(10) unsigned NOT NULL,
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`tran_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='gift history';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gift_history`
--

LOCK TABLES `log_gift_history` WRITE;
/*!40000 ALTER TABLE `log_gift_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gift_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_refund_history`
--

DROP TABLE IF EXISTS `log_item_refund_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_refund_history` (
  `pf_rel_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_tran_id` bigint(20) unsigned NOT NULL,
  `recharge_tran_id` bigint(20) unsigned NOT NULL,
  `account_id` char(30) NOT NULL,
  `occ_date` datetime NOT NULL,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `admin_id` varchar(30) NOT NULL DEFAULT '',
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`pf_rel_id`) USING BTREE,
  KEY `log_item_refund_history_idx001` (`account_id`) USING BTREE,
  KEY `log_item_refund_history_ibfk_1` (`purchase_tran_id`) USING BTREE,
  KEY `log_item_refund_history_ibfk_2` (`recharge_tran_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_refund_history`
--

LOCK TABLES `log_item_refund_history` WRITE;
/*!40000 ALTER TABLE `log_item_refund_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_refund_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_point_history`
--

DROP TABLE IF EXISTS `log_point_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_point_history` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` varchar(30) NOT NULL DEFAULT '',
  `charac_id` varchar(30) NOT NULL DEFAULT '',
  `cera_point` int(10) unsigned NOT NULL DEFAULT '0',
  `command` enum('A','U') NOT NULL COMMENT 'A(add), U(use)',
  `charge_type` tinyint(4) NOT NULL DEFAULT '0',
  `free_charge_type` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_point_history`
--

LOCK TABLES `log_point_history` WRITE;
/*!40000 ALTER TABLE `log_point_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_point_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_purchase_history`
--

DROP TABLE IF EXISTS `log_purchase_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_purchase_history` (
  `tran_id` bigint(20) unsigned NOT NULL,
  `tran_state` tinyint(3) unsigned NOT NULL,
  `account_id` char(30) NOT NULL,
  `charac_id` char(30) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `cera` int(10) unsigned NOT NULL,
  `befor_cera` int(10) unsigned NOT NULL,
  `after_cera` int(10) unsigned NOT NULL,
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`tran_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='purchase history';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_purchase_history`
--

LOCK TABLES `log_purchase_history` WRITE;
/*!40000 ALTER TABLE `log_purchase_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_purchase_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_recharge_history`
--

DROP TABLE IF EXISTS `log_recharge_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_recharge_history` (
  `tran_id` bigint(20) unsigned NOT NULL,
  `order_tran_id` varchar(35) NOT NULL,
  `tran_state` tinyint(3) unsigned NOT NULL,
  `account_id` varchar(30) NOT NULL,
  `charac_id` varchar(30) NOT NULL,
  `cera` int(10) unsigned NOT NULL,
  `befor_cera` int(10) unsigned NOT NULL,
  `after_cera` int(10) unsigned NOT NULL,
  `charge_type` tinyint(3) unsigned NOT NULL,
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`tran_id`) USING BTREE,
  KEY `log_recharge_history_idx01` (`account_id`) USING BTREE,
  KEY `log_recharge_history_idx02` (`charac_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='recharge history';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_recharge_history`
--

LOCK TABLES `log_recharge_history` WRITE;
/*!40000 ALTER TABLE `log_recharge_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_recharge_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_refund_history`
--

DROP TABLE IF EXISTS `log_refund_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_refund_history` (
  `tran_id` bigint(20) unsigned NOT NULL,
  `account_id` varchar(30) NOT NULL,
  `order_tran_id` varchar(35) NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  `tran_state` tinyint(3) unsigned NOT NULL,
  `query_user` varchar(45) NOT NULL DEFAULT 'None',
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`tran_id`,`account_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_refund_history`
--

LOCK TABLES `log_refund_history` WRITE;
/*!40000 ALTER TABLE `log_refund_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_refund_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_transaction_history`
--

DROP TABLE IF EXISTS `log_transaction_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_transaction_history` (
  `tran_id` bigint(20) unsigned NOT NULL,
  `tran_type` tinyint(3) unsigned NOT NULL,
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`tran_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_transaction_history`
--

LOCK TABLES `log_transaction_history` WRITE;
/*!40000 ALTER TABLE `log_transaction_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_transaction_history` ENABLE KEYS */;
UNLOCK TABLES;

--
