-- generated from VMDK full dump
-- source_db=taiwan_se_event

--



--
-- Table structure for table `event_1112_ontime_info`
--

DROP TABLE IF EXISTS `event_1112_ontime_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_info` (
  `no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_index` int(10) unsigned NOT NULL DEFAULT '0',
  `item_count` int(10) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_info`
--

LOCK TABLES `event_1112_ontime_info` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_reward_user`
--

DROP TABLE IF EXISTS `event_1112_ontime_reward_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_reward_user` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `recv_no` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_reward_user`
--

LOCK TABLES `event_1112_ontime_reward_user` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_reward_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_reward_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_0`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_0` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_0`
--

LOCK TABLES `event_1112_ontime_user_0` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_0` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_1`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_1` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_1`
--

LOCK TABLES `event_1112_ontime_user_1` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_2`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_2` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_2`
--

LOCK TABLES `event_1112_ontime_user_2` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_2` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_3`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_3` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_3`
--

LOCK TABLES `event_1112_ontime_user_3` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_3` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_4`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_4` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_4`
--

LOCK TABLES `event_1112_ontime_user_4` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_5`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_5` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_5`
--

LOCK TABLES `event_1112_ontime_user_5` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_5` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_6`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_6` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_6`
--

LOCK TABLES `event_1112_ontime_user_6` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_6` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_7`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_7` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_7`
--

LOCK TABLES `event_1112_ontime_user_7` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_7` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_8`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_8` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_8`
--

LOCK TABLES `event_1112_ontime_user_8` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_8` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_ontime_user_9`
--

DROP TABLE IF EXISTS `event_1112_ontime_user_9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_ontime_user_9` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_ontime_user_9`
--

LOCK TABLES `event_1112_ontime_user_9` WRITE;
/*!40000 ALTER TABLE `event_1112_ontime_user_9` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_ontime_user_9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_ontime_item`
--

DROP TABLE IF EXISTS `event_ontime_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_ontime_item` (
  `idx` int(10) unsigned NOT NULL DEFAULT '8211',
  `cnt` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_ontime_item`
--

LOCK TABLES `event_ontime_item` WRITE;
/*!40000 ALTER TABLE `event_ontime_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_ontime_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'taiwan_se_event'
--

--
-- Dumping routines for database 'taiwan_se_event'
--

--
