-- generated from VMDK full dump
-- source_db=frida

--



--
-- Table structure for table `charac_ex`
--

DROP TABLE IF EXISTS `charac_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_ex` (
  `charac_no` int(11) NOT NULL,
  `ex_data` blob NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_ex`
--

LOCK TABLES `charac_ex` WRITE;
/*!40000 ALTER TABLE `charac_ex` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_ex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data` (
  `equ_id` int(11) NOT NULL AUTO_INCREMENT,
  `jewel_data` blob NOT NULL,
  `index_flag` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`equ_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event`
--

DROP TABLE IF EXISTS `game_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event` (
  `event_id` varchar(30) NOT NULL,
  `event_info` mediumtext,
  PRIMARY KEY (`event_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event`
--

LOCK TABLES `game_event` WRITE;
/*!40000 ALTER TABLE `game_event` DISABLE KEYS */;
INSERT INTO `game_event` VALUES ('villageattack','{\"state\":3,\"score\":0,\"start_time\":0,\"difficult\":0,\"next_village_monster_id\":0,\"last_killed_monster_id\":0,\"p2_last_killed_monster_time\":0,\"p2_kill_combo\":0,\"gbl_cnt\":0,\"defend_success\":0,\"user_pt_info\":{}}');
/*!40000 ALTER TABLE `game_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'frida'
--

--
-- Dumping routines for database 'frida'
--

--
