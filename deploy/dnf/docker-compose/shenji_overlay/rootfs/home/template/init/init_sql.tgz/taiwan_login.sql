-- generated from VMDK full dump
-- source_db=taiwan_login

--



--
-- Table structure for table `allow_proxy_user`
--

DROP TABLE IF EXISTS `allow_proxy_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allow_proxy_user` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allow_proxy_user`
--

LOCK TABLES `allow_proxy_user` WRITE;
/*!40000 ALTER TABLE `allow_proxy_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `allow_proxy_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_blackip_info`
--

DROP TABLE IF EXISTS `auto_punish_blackip_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_blackip_info` (
  `ip` varchar(11) NOT NULL DEFAULT '',
  `start_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `end_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`,`start_ip`,`end_ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_blackip_info`
--

LOCK TABLES `auto_punish_blackip_info` WRITE;
/*!40000 ALTER TABLE `auto_punish_blackip_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_blackip_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_first_user`
--

DROP TABLE IF EXISTS `auto_punish_first_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_first_user` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `punish_flag` tinyint(4) NOT NULL DEFAULT '0',
  `hack_sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hack_sub_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`hack_type`,`hack_sub_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_first_user`
--

LOCK TABLES `auto_punish_first_user` WRITE;
/*!40000 ALTER TABLE `auto_punish_first_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_first_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_hack_full_ip`
--

DROP TABLE IF EXISTS `auto_punish_hack_full_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_hack_full_ip` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hack_sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `full_ip` varchar(15) NOT NULL DEFAULT '',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`hack_type`,`hack_sub_type`,`full_ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_hack_full_ip`
--

LOCK TABLES `auto_punish_hack_full_ip` WRITE;
/*!40000 ALTER TABLE `auto_punish_hack_full_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_hack_full_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_hack_info`
--

DROP TABLE IF EXISTS `auto_punish_hack_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_hack_info` (
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `etc` bigint(20) unsigned NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  `hack_sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hack_sub_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `ip_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`hack_type`,`apply_flag`,`hack_sub_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_hack_info`
--

LOCK TABLES `auto_punish_hack_info` WRITE;
/*!40000 ALTER TABLE `auto_punish_hack_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_hack_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_hack_ip`
--

DROP TABLE IF EXISTS `auto_punish_hack_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_hack_ip` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hack_sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `c_class_ip` varchar(12) NOT NULL DEFAULT '',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`hack_type`,`hack_sub_type`,`c_class_ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_hack_ip`
--

LOCK TABLES `auto_punish_hack_ip` WRITE;
/*!40000 ALTER TABLE `auto_punish_hack_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_hack_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_second_log`
--

DROP TABLE IF EXISTS `auto_punish_second_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_second_log` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `hack_m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `trade_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`hack_m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_second_log`
--

LOCK TABLES `auto_punish_second_log` WRITE;
/*!40000 ALTER TABLE `auto_punish_second_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_second_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_punish_second_user`
--

DROP TABLE IF EXISTS `auto_punish_second_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_punish_second_user` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_trade_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `total_trade_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `trade_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `punish_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_punish_flag` (`punish_flag`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_punish_second_user`
--

LOCK TABLES `auto_punish_second_user` WRITE;
/*!40000 ALTER TABLE `auto_punish_second_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_punish_second_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `churn_member_info`
--

DROP TABLE IF EXISTS `churn_member_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `churn_member_info` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `accrue_cera` int(10) unsigned NOT NULL DEFAULT '0',
  `play_info` char(30) NOT NULL DEFAULT '',
  `first_reward_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_reward_time` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `add_info` tinyint(4) NOT NULL DEFAULT '0',
  `luck_point` int(10) unsigned NOT NULL DEFAULT '0',
  `last_update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `second_reward_time` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `churn_member_info`
--

LOCK TABLES `churn_member_info` WRITE;
/*!40000 ALTER TABLE `churn_member_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `churn_member_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `churn_reward_history`
--

DROP TABLE IF EXISTS `churn_reward_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `churn_reward_history` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `add_info` int(10) unsigned NOT NULL DEFAULT '0',
  `luck_point` int(10) unsigned NOT NULL DEFAULT '0',
  `reward_order` int(10) unsigned NOT NULL DEFAULT '0',
  `cera` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `churn_reward_history`
--

LOCK TABLES `churn_reward_history` WRITE;
/*!40000 ALTER TABLE `churn_reward_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `churn_reward_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `churn_reward_manager`
--

DROP TABLE IF EXISTS `churn_reward_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `churn_reward_manager` (
  `min_day` tinyint(4) NOT NULL DEFAULT '0',
  `max_day` tinyint(4) NOT NULL DEFAULT '0',
  `min_val` int(10) unsigned NOT NULL DEFAULT '0',
  `max_val` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `add_info` int(10) unsigned NOT NULL DEFAULT '0',
  `luck_point` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`min_day`,`max_day`,`min_val`,`max_val`,`quest_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `churn_reward_manager`
--

LOCK TABLES `churn_reward_manager` WRITE;
/*!40000 ALTER TABLE `churn_reward_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `churn_reward_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `churn_system_manager`
--

DROP TABLE IF EXISTS `churn_system_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `churn_system_manager` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weekday_var_a` int(11) NOT NULL DEFAULT '0',
  `weekday_var_b` int(11) NOT NULL DEFAULT '0',
  `weekday_var_c` int(11) NOT NULL DEFAULT '0',
  `weekend_var_x` int(11) NOT NULL DEFAULT '0',
  `weekend_var_y` int(11) NOT NULL DEFAULT '0',
  `weekend_var_z` int(11) NOT NULL DEFAULT '0',
  `next_reward_day` int(11) NOT NULL DEFAULT '0',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `churn_system_manager`
--

LOCK TABLES `churn_system_manager` WRITE;
/*!40000 ALTER TABLE `churn_system_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `churn_system_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_entry`
--

DROP TABLE IF EXISTS `dnf_event_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_entry` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `obtain_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_entry`
--

LOCK TABLES `dnf_event_entry` WRITE;
/*!40000 ALTER TABLE `dnf_event_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_server_message`
--

DROP TABLE IF EXISTS `event_server_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_server_message` (
  `server_info` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `channel_no` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `kind` char(1) NOT NULL DEFAULT '',
  `message_index` char(1) NOT NULL DEFAULT '',
  `charac_name` char(64) NOT NULL DEFAULT '',
  `message` char(128) NOT NULL DEFAULT '',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_server_message`
--

LOCK TABLES `event_server_message` WRITE;
/*!40000 ALTER TABLE `event_server_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_server_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_manifest`
--

DROP TABLE IF EXISTS `gm_manifest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_manifest` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_manifest`
--

LOCK TABLES `gm_manifest` WRITE;
/*!40000 ALTER TABLE `gm_manifest` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_manifest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hack_cleanpad_ratio_info`
--

DROP TABLE IF EXISTS `hack_cleanpad_ratio_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hack_cleanpad_ratio_info` (
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`hack_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hack_cleanpad_ratio_info`
--

LOCK TABLES `hack_cleanpad_ratio_info` WRITE;
/*!40000 ALTER TABLE `hack_cleanpad_ratio_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `hack_cleanpad_ratio_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `human_certify_try_count`
--

DROP TABLE IF EXISTS `human_certify_try_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `human_certify_try_count` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `human_certify_try_count`
--

LOCK TABLES `human_certify_try_count` WRITE;
/*!40000 ALTER TABLE `human_certify_try_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `human_certify_try_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_monitor_punish`
--

DROP TABLE IF EXISTS `ip_monitor_punish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_monitor_punish` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `m_id_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ip`,`type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_monitor_punish`
--

LOCK TABLES `ip_monitor_punish` WRITE;
/*!40000 ALTER TABLE `ip_monitor_punish` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_monitor_punish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_growth`
--

DROP TABLE IF EXISTS `log_growth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_growth` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(25) NOT NULL DEFAULT '',
  `job` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grow_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`,`server_info`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_growth`
--

LOCK TABLES `log_growth` WRITE;
/*!40000 ALTER TABLE `log_growth` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_growth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_query_dbmw_ref`
--

DROP TABLE IF EXISTS `log_query_dbmw_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_query_dbmw_ref` (
  `query_hash` varchar(16) NOT NULL DEFAULT '',
  `q_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  PRIMARY KEY (`q_id`) USING BTREE,
  UNIQUE KEY `query_hash` (`query_hash`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_query_dbmw_ref`
--

LOCK TABLES `log_query_dbmw_ref` WRITE;
/*!40000 ALTER TABLE `log_query_dbmw_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_query_dbmw_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_query_ref`
--

DROP TABLE IF EXISTS `log_query_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_query_ref` (
  `query_hash` varchar(16) NOT NULL DEFAULT '',
  `q_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  PRIMARY KEY (`q_id`) USING BTREE,
  UNIQUE KEY `query_hash` (`query_hash`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_query_ref`
--

LOCK TABLES `log_query_ref` WRITE;
/*!40000 ALTER TABLE `log_query_ref` DISABLE KEYS */;
INSERT INTO `log_query_ref` VALUES ('*B8583582EDEAD9C',1,'seLect slang from slang_list_name'),('*D97DCEA3E7673B2',2,'seLect @@identity'),('*1A3E38BFC88DE52',3,'seLect slang from slang_list'),('*1682A2ECA954997',4,'seLect m_id, level from gm_manifest'),('*C0D155921D7BA43',5,'seLect level, exp from monster_reward_ref'),('*89D927522E9A6A5',6,'upDate login_account_%d set login_status=0 where m_channel_no=%d'),('*EC2BF0BDCB96F85',7,'seLect event_id, event_name from dnf_event_info'),('*9D85D7D192A29BF',8,'seLect event_type, parameter1, parameter2 from dnf_event_log where end_time = 0 and server_id in (0,%d) and unix_timestamp() >= start_time order by start_time'),('*0049E86CEB03667',9,'seLect guild_id, guild_name, lev , power_side, guild_agit_flag from guild_info where expire_flag = 0 and server_id = %d'),('*B228608CBA743A8',10,'seLect * from in_game_ad where visible = 1'),('*B36C615E3CBDD69',11,'seLect item_id,upgrade,average_price from auction_average_price'),('*EB71B0B0D318301',12,'seLect ip,start_ip,end_ip from auto_punish_blackip_info where apply_flag=1 limit %d'),('*861800114BD642A',13,'seLect hack_type,cnt,etc,hack_sub_type,hack_sub_cnt,apply_flag, ip_cnt from auto_punish_hack_info where apply_flag > 0'),('*B95FCD30ACC980F',14,'seLect hack_type,value from hack_cleanpad_ratio_info'),('*6863ACC34007C7E',15,'seLect ip, type, m_id_cnt, unix_timestamp(start_time), unix_timestamp(end_time) from ip_monitor_punish ORDER BY start_time ASC'),('*CF8023F3B73003B',16,'seLect charac_no from charac_tower_despair_apc limit 10'),('*ED663684CAD3B3B',17,'seLect category, restrict_code, restrict_value from dnf_restrict_state where server_group=%d'),('*BDC65252D0C038C',18,'seLect country_code from geo_allow_country where server_group = %d'),('*2B4EF13CA44D8B5',19,'inSert into log_response_time_%s(channel_no,occ_time,packet_id,packet_count,total_response_time,avg_response_time) values%s'),('*A430F68539EA10B',20,'seLect optimum_gold_supply, over_gold from auto_market_condition_ctrl limit 1'),('*BDD5075C427A5B1',21,'seLect total_gold, auction_gold, optimum_gold_supply, over_gold, gold_phase, item_phase, durability_phase from auto_market_condition_ctrl_daily where occ_time >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) order by occ_time limit 2'),('*3E5F283A8C3D2C1',22,'seLect count(*) from charac_tower_rank where tower_index=%d and part_type=%d'),('*4BDD1A8E6B6297B',23,'seLect b.rank,a.tower_index, a.member_info_%d,a.stage_%d,a.play_time_%d from charac_tower_record a,charac_tower_rank b where b.tower_index=%d and b.tower_index=a.tower_index and (b.rank>5 and (b.rank%%%d)=0) and a.charac_no=b.charac_no and b.part_type=%d order by b.rank asc limit %d'),('*FE9E568D694D9BE',24,'upDate client_down set occ_count = occ_count+%d where occ_date = cast(now() as date)'),('*39636577CD2E623',25,'seLect b.rank,a.tower_index, a.member_info_%d,a.stage_%d,a.play_time_%d from charac_tower_record a,charac_tower_rank_top5 b where b.tower_index=%d and b.tower_index=a.tower_index and b.rank<=5 and a.charac_no=b.charac_no and b.part_type=%d order by b.rank asc limit %d'),('*3CB80E282B6B059',26,'inSert into game_channel (gc_no,gc_now,gc_ip,gc_port,gc_max,gc_game,gc_channel,gc_ch_group,gc_channeltype,gc_up_time, gc_type) values(%d,0,\'%s\',%d,%d,%d,\'%s\',%d,\'%s\',now(),%d)'),('*A28EF36E2AA4850',27,'inSert into channel_occ_info (gc_no, age, occ_num) values %s'),('*0340E761AD8683E',28,'upDate channel_occ_info set occ_num = 0 where gc_no = %d'),('*D9FDAFDD29F1CDA',29,'inSert ignore into dnf_restrict_state (server_group , category , restrict_code , restrict_value , mod_date , reg_date) values(%d, %d, %d, \'%d\', now(), now())'),('*C498B459FC6FB60',30,'inSert ignore into dnf_restrict_info (category , restrict_code , restrict_str , reg_date) values(%d, %d, \'%s\', now())'),('*AEA3E6A45377B58',31,'inSert into log_query_stat(occ_time,q_id,total,response_time,gc_no) values(from_unixtime(%d),%d,%d,%d,%d)'),('*8CA61ABBABFC1AE',32,'seLect kind, message_index, charac_name, message, unix_timestamp(update_time) from event_server_message where server_info=%d and (channel_no=%d or channel_no=0)'),('*668641EC066211D',33,' seLect category, code, state from server_state_info where end_time >= now()'),('*6F0167591240276',34,'upDate game_channel set gc_now=%d,gc_up_time=now(),gc_swordman_cnt=%d,gc_fighter_cnt=%d,gc_gunner_cnt=%d,gc_mage_cnt=%d,gc_priest_cnt=%d,gc_at_gunner_cnt=%d,gc_thief_cnt=%d,gc_hangame=%d,gc_nexon=%d where gc_no=%d'),('*8BC4C91D778EBE4',35,'upDate game_channel set gc_now=0,gc_ip=\'%s\',gc_port=%d,gc_max=%d,gc_game=%d,gc_channel=\'%s\',gc_ch_group=%d,gc_channeltype=\'%s\',gc_up_time=now(),gc_type=%d where gc_no=%d'),('*6773E38D9FBFF0B',36,'inSert into log_game_channel(gc_up_time,gc_game,gc_no,gc_channel,gc_ch_group,gc_ip,gc_now,gc_new,gc_out) values(now(),%d,%d,\'%s\',%d,\'%s\',%d,%d,%d)');
/*!40000 ALTER TABLE `log_query_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_query_ref~`
--

DROP TABLE IF EXISTS `log_query_ref~`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_query_ref~` (
  `query_hash` varchar(16) NOT NULL DEFAULT '',
  `q_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `query` text NOT NULL,
  PRIMARY KEY (`q_id`) USING BTREE,
  UNIQUE KEY `query_hash` (`query_hash`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_query_ref~`
--

LOCK TABLES `log_query_ref~` WRITE;
/*!40000 ALTER TABLE `log_query_ref~` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_query_ref~` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_account_1`
--

DROP TABLE IF EXISTS `login_account_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_account_1` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_channel_no` int(11) NOT NULL DEFAULT '0',
  `login_status` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_account_1`
--

LOCK TABLES `login_account_1` WRITE;
/*!40000 ALTER TABLE `login_account_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_account_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_account_2`
--

DROP TABLE IF EXISTS `login_account_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_account_2` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_channel_no` int(11) NOT NULL DEFAULT '0',
  `login_status` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_account_2`
--

LOCK TABLES `login_account_2` WRITE;
/*!40000 ALTER TABLE `login_account_2` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_account_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_account_3`
--

DROP TABLE IF EXISTS `login_account_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_account_3` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_channel_no` int(11) NOT NULL DEFAULT '0',
  `login_status` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_account_3`
--

LOCK TABLES `login_account_3` WRITE;
/*!40000 ALTER TABLE `login_account_3` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_account_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_history` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` int(11) NOT NULL DEFAULT '0',
  `trigger` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_captcha_info`
--

DROP TABLE IF EXISTS `member_captcha_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_captcha_info` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cert_time` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_captcha_info`
--

LOCK TABLES `member_captcha_info` WRITE;
/*!40000 ALTER TABLE `member_captcha_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_captcha_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_doubt_trade`
--

DROP TABLE IF EXISTS `member_doubt_trade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_doubt_trade` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `last_update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `over_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_doubt_trade`
--

LOCK TABLES `member_doubt_trade` WRITE;
/*!40000 ALTER TABLE `member_doubt_trade` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_doubt_trade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_game_option`
--

DROP TABLE IF EXISTS `member_game_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_game_option` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `option_1` blob NOT NULL,
  `option_2` blob NOT NULL,
  `option_3` blob NOT NULL,
  `shortcut_emoticon` blob NOT NULL,
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_game_option`
--

LOCK TABLES `member_game_option` WRITE;
/*!40000 ALTER TABLE `member_game_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_game_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_key_option`
--

DROP TABLE IF EXISTS `member_key_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_key_option` (
  `m_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `key_type` tinyint(4) NOT NULL DEFAULT '0',
  `key_option` blob NOT NULL,
  PRIMARY KEY (`m_id`,`key_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_key_option`
--

LOCK TABLES `member_key_option` WRITE;
/*!40000 ALTER TABLE `member_key_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_key_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_login`
--

DROP TABLE IF EXISTS `member_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_login` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `total_account_fail` int(10) unsigned NOT NULL DEFAULT '0',
  `account_fail` tinyint(4) NOT NULL DEFAULT '0',
  `report_cnt` int(11) NOT NULL DEFAULT '0',
  `reliable_flag` tinyint(4) NOT NULL DEFAULT '0',
  `trade_gold_daily` int(10) unsigned NOT NULL DEFAULT '0',
  `last_gift_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gift_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  `security_flag` tinyint(4) NOT NULL DEFAULT '0',
  `power_side` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon_gain_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `school_id` int(11) NOT NULL DEFAULT '0',
  `rating` float NOT NULL DEFAULT '0',
  `cleanpad_point` int(10) unsigned NOT NULL DEFAULT '0',
  `tutorial_skipable` char(1) NOT NULL DEFAULT '0',
  `event_charac_flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `garena_token_key` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_login`
--

LOCK TABLES `member_login` WRITE;
/*!40000 ALTER TABLE `member_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_login_backup`
--

DROP TABLE IF EXISTS `member_login_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_login_backup` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `total_account_fail` int(10) unsigned NOT NULL DEFAULT '0',
  `account_fail` tinyint(4) NOT NULL DEFAULT '0',
  `report_cnt` int(11) NOT NULL DEFAULT '0',
  `reliable_flag` tinyint(4) NOT NULL DEFAULT '0',
  `trade_gold_daily` int(10) unsigned NOT NULL DEFAULT '0',
  `last_gift_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gift_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  `security_flag` tinyint(4) NOT NULL DEFAULT '0',
  `power_side` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon_gain_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `school_id` int(11) NOT NULL DEFAULT '0',
  `rating` float NOT NULL DEFAULT '0',
  `cleanpad_point` int(10) unsigned NOT NULL DEFAULT '0',
  `tutorial_skipable` char(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_login_backup`
--

LOCK TABLES `member_login_backup` WRITE;
/*!40000 ALTER TABLE `member_login_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_login_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_mousepass`
--

DROP TABLE IF EXISTS `member_mousepass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_mousepass` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `mousepass` varchar(32) NOT NULL DEFAULT '',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fail_cnt` tinyint(4) NOT NULL DEFAULT '0',
  `cancel_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `version_info` char(1) NOT NULL DEFAULT '1',
  `validity_time` int(11) NOT NULL DEFAULT '0',
  `reward_time` int(11) NOT NULL DEFAULT '0',
  `enable_flag` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_mousepass`
--

LOCK TABLES `member_mousepass` WRITE;
/*!40000 ALTER TABLE `member_mousepass` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_mousepass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_mousepass_history`
--

DROP TABLE IF EXISTS `member_mousepass_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_mousepass_history` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `pre_mousepass` varchar(32) NOT NULL DEFAULT '',
  `modify_type` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_mousepass_history`
--

LOCK TABLES `member_mousepass_history` WRITE;
/*!40000 ALTER TABLE `member_mousepass_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_mousepass_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_play_info`
--

DROP TABLE IF EXISTS `member_play_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_play_info` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `play_count` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_cnt` int(11) NOT NULL DEFAULT '0',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `used_fatigue` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `last_play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pcbang_flag` tinyint(4) NOT NULL DEFAULT '0',
  `end_ip` varchar(3) NOT NULL DEFAULT '',
  `ting_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mac_addr` varchar(64) NOT NULL DEFAULT '',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_play_info`
--

LOCK TABLES `member_play_info` WRITE;
/*!40000 ALTER TABLE `member_play_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_play_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_play_info_del`
--

DROP TABLE IF EXISTS `member_play_info_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_play_info_del` (
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `play_count` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_cnt` int(11) NOT NULL DEFAULT '0',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `used_fatigue` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `last_play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pcbang_flag` tinyint(4) NOT NULL DEFAULT '0',
  `end_ip` varchar(3) NOT NULL DEFAULT '',
  `ting_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mac_addr` varchar(64) NOT NULL DEFAULT '',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sdate`,`occ_date`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_play_info_del`
--

LOCK TABLES `member_play_info_del` WRITE;
/*!40000 ALTER TABLE `member_play_info_del` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_play_info_del` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_premium`
--

DROP TABLE IF EXISTS `member_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_premium` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `pre_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `service_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `service_end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`pre_type`,`server_id`,`m_id`,`service_start`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_premium`
--

LOCK TABLES `member_premium` WRITE;
/*!40000 ALTER TABLE `member_premium` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_premium_old`
--

DROP TABLE IF EXISTS `member_premium_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_premium_old` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `pre_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `service_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `service_end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`,`pre_type`,`server_id`,`m_id`,`service_start`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_premium_old`
--

LOCK TABLES `member_premium_old` WRITE;
/*!40000 ALTER TABLE `member_premium_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_premium_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_security_card`
--

DROP TABLE IF EXISTS `member_security_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_security_card` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `phone` varchar(11) NOT NULL DEFAULT '',
  `cert_key` varchar(12) NOT NULL DEFAULT '',
  `server_key` varchar(32) NOT NULL DEFAULT '',
  `card` varchar(255) NOT NULL DEFAULT '',
  `fail_cnt` tinyint(4) NOT NULL DEFAULT '0',
  `re_issue_cnt` tinyint(4) NOT NULL DEFAULT '0',
  `last_issue_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `validity_time` int(11) NOT NULL DEFAULT '0',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  `cancel_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `web_flag` tinyint(4) NOT NULL DEFAULT '0',
  `cert_flag` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_phone` (`phone`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_security_card`
--

LOCK TABLES `member_security_card` WRITE;
/*!40000 ALTER TABLE `member_security_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_security_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_security_card_history`
--

DROP TABLE IF EXISTS `member_security_card_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_security_card_history` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `modify_type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_security_card_history`
--

LOCK TABLES `member_security_card_history` WRITE;
/*!40000 ALTER TABLE `member_security_card_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_security_card_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nexon_none_memner_restriction`
--

DROP TABLE IF EXISTS `nexon_none_memner_restriction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nexon_none_memner_restriction` (
  `m_id` int(11) unsigned NOT NULL DEFAULT '0',
  `charac_id` int(11) unsigned NOT NULL DEFAULT '0',
  `last_trade_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_trade_gold` int(12) unsigned NOT NULL DEFAULT '0',
  `trade_count` smallint(6) unsigned NOT NULL DEFAULT '0',
  `nexon_user` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nexon_none_memner_restriction`
--

LOCK TABLES `nexon_none_memner_restriction` WRITE;
/*!40000 ALTER TABLE `nexon_none_memner_restriction` DISABLE KEYS */;
/*!40000 ALTER TABLE `nexon_none_memner_restriction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village_attacked_charac_point_rank`
--

DROP TABLE IF EXISTS `village_attacked_charac_point_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_attacked_charac_point_rank` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `hunting_point` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_info`,`occ_date`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village_attacked_charac_point_rank`
--

LOCK TABLES `village_attacked_charac_point_rank` WRITE;
/*!40000 ALTER TABLE `village_attacked_charac_point_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `village_attacked_charac_point_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village_attacked_server_point_rank`
--

DROP TABLE IF EXISTS `village_attacked_server_point_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_attacked_server_point_rank` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `hunting_point` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_info`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village_attacked_server_point_rank`
--

LOCK TABLES `village_attacked_server_point_rank` WRITE;
/*!40000 ALTER TABLE `village_attacked_server_point_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `village_attacked_server_point_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village_attacked_server_time_rank`
--

DROP TABLE IF EXISTS `village_attacked_server_time_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_attacked_server_time_rank` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `clear_time` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_info`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village_attacked_server_time_rank`
--

LOCK TABLES `village_attacked_server_time_rank` WRITE;
/*!40000 ALTER TABLE `village_attacked_server_time_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `village_attacked_server_time_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
