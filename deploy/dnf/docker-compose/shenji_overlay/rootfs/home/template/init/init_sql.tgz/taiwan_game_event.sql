-- generated from VMDK full dump
-- source_db=taiwan_game_event

--



--
-- Table structure for table `cleanup_constant`
--

DROP TABLE IF EXISTS `cleanup_constant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cleanup_constant` (
  `limit_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `base1_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `base2_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `base3_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `base4_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `person_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `person_shop_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `auction_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mail_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mail_min_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `abnormal_npc_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `abnormal_user_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dungeon_clear` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `removal_dungeon_clear` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `penalty_user_trade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `penalty_ghost_clear_n` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `penalty_ghost_clear_m` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `penalty_ghost_clear_l` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pc_room_weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hps_ip_weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `otm_weight_n` smallint(5) unsigned NOT NULL DEFAULT '0',
  `otm_weight_m` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hack_weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pvp_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dungeon_clear_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `quest_clear_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reduce_time_date` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reduce_time_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleanup_constant`
--

LOCK TABLES `cleanup_constant` WRITE;
/*!40000 ALTER TABLE `cleanup_constant` DISABLE KEYS */;
/*!40000 ALTER TABLE `cleanup_constant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleanup_dungeon_list`
--

DROP TABLE IF EXISTS `cleanup_dungeon_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cleanup_dungeon_list` (
  `dungeon_idx` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleanup_dungeon_list`
--

LOCK TABLES `cleanup_dungeon_list` WRITE;
/*!40000 ALTER TABLE `cleanup_dungeon_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `cleanup_dungeon_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleanup_penalty_log`
--

DROP TABLE IF EXISTS `cleanup_penalty_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cleanup_penalty_log` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `penalty_point` tinyint(3) NOT NULL DEFAULT '0',
  `current_point` int(11) NOT NULL DEFAULT '0',
  `reset_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cause` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pattern` tinyint(3) unsigned NOT NULL DEFAULT '0',
  KEY `m_id` (`m_id`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleanup_penalty_log`
--

LOCK TABLES `cleanup_penalty_log` WRITE;
/*!40000 ALTER TABLE `cleanup_penalty_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `cleanup_penalty_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleanup_user_data`
--

DROP TABLE IF EXISTS `cleanup_user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cleanup_user_data` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `restriction_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cur_state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_trade_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `npc_trade_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dungeon_clear_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_clear_map_idx` int(10) unsigned NOT NULL DEFAULT '0',
  `ghost_clear_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_penalty_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `other_penalty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `other_penalty_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleanup_user_data`
--

LOCK TABLES `cleanup_user_data` WRITE;
/*!40000 ALTER TABLE `cleanup_user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cleanup_user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collect_items`
--

DROP TABLE IF EXISTS `collect_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collect_items` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `total_count` int(10) unsigned NOT NULL DEFAULT '0',
  `cur_count` int(10) unsigned NOT NULL DEFAULT '0',
  `change_flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `full_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`server_info`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collect_items`
--

LOCK TABLES `collect_items` WRITE;
/*!40000 ALTER TABLE `collect_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `collect_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_entry_notuse`
--

DROP TABLE IF EXISTS `dnf_event_entry_notuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_entry_notuse` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `obtain_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_entry_notuse`
--

LOCK TABLES `dnf_event_entry_notuse` WRITE;
/*!40000 ALTER TABLE `dnf_event_entry_notuse` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_entry_notuse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1106_idol_bring_count`
--

DROP TABLE IF EXISTS `event_1106_idol_bring_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1106_idol_bring_count` (
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `pot_type` tinyint(4) NOT NULL DEFAULT '0',
  `r_count` int(11) NOT NULL DEFAULT '0',
  `adjust_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_id`,`pot_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1106_idol_bring_count`
--

LOCK TABLES `event_1106_idol_bring_count` WRITE;
/*!40000 ALTER TABLE `event_1106_idol_bring_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1106_idol_bring_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1107_avenger_plan`
--

DROP TABLE IF EXISTS `event_1107_avenger_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1107_avenger_plan` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1107_avenger_plan`
--

LOCK TABLES `event_1107_avenger_plan` WRITE;
/*!40000 ALTER TABLE `event_1107_avenger_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1107_avenger_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1112_at_mage_12up`
--

DROP TABLE IF EXISTS `event_1112_at_mage_12up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1112_at_mage_12up` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1112_at_mage_12up`
--

LOCK TABLES `event_1112_at_mage_12up` WRITE;
/*!40000 ALTER TABLE `event_1112_at_mage_12up` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1112_at_mage_12up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1202_fatigue_attendance`
--

DROP TABLE IF EXISTS `event_1202_fatigue_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1202_fatigue_attendance` (
  `occ_day` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fatigue` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_day`,`m_id`) USING BTREE,
  KEY `m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1202_fatigue_attendance`
--

LOCK TABLES `event_1202_fatigue_attendance` WRITE;
/*!40000 ALTER TABLE `event_1202_fatigue_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1202_fatigue_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1207_growthweapon`
--

DROP TABLE IF EXISTS `event_1207_growthweapon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1207_growthweapon` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `growthweapon_id` int(10) unsigned NOT NULL DEFAULT '0',
  `timepiece` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `infinityweapon_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reward_occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1207_growthweapon`
--

LOCK TABLES `event_1207_growthweapon` WRITE;
/*!40000 ALTER TABLE `event_1207_growthweapon` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1207_growthweapon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1208_bingo`
--

DROP TABLE IF EXISTS `event_1208_bingo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1208_bingo` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `board` int(10) unsigned DEFAULT '0',
  `reward` tinyint(4) unsigned DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `id_date` (`m_id`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1208_bingo`
--

LOCK TABLES `event_1208_bingo` WRITE;
/*!40000 ALTER TABLE `event_1208_bingo` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1208_bingo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1306_account_reward`
--

DROP TABLE IF EXISTS `event_1306_account_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1306_account_reward` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1306_account_reward`
--

LOCK TABLES `event_1306_account_reward` WRITE;
/*!40000 ALTER TABLE `event_1306_account_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1306_account_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1306_account_reward_2nd`
--

DROP TABLE IF EXISTS `event_1306_account_reward_2nd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1306_account_reward_2nd` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1306_account_reward_2nd`
--

LOCK TABLES `event_1306_account_reward_2nd` WRITE;
/*!40000 ALTER TABLE `event_1306_account_reward_2nd` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1306_account_reward_2nd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_account_fatigue`
--

DROP TABLE IF EXISTS `event_account_fatigue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_account_fatigue` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fatigue` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_account_fatigue`
--

LOCK TABLES `event_account_fatigue` WRITE;
/*!40000 ALTER TABLE `event_account_fatigue` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_account_fatigue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_account_fatigue_reward`
--

DROP TABLE IF EXISTS `event_account_fatigue_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_account_fatigue_reward` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_account_fatigue_reward`
--

LOCK TABLES `event_account_fatigue_reward` WRITE;
/*!40000 ALTER TABLE `event_account_fatigue_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_account_fatigue_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_at_fighter_doll`
--

DROP TABLE IF EXISTS `event_at_fighter_doll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_at_fighter_doll` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_at_fighter_doll`
--

LOCK TABLES `event_at_fighter_doll` WRITE;
/*!40000 ALTER TABLE `event_at_fighter_doll` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_at_fighter_doll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_attendance_check_info`
--

DROP TABLE IF EXISTS `event_attendance_check_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_attendance_check_info` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `base_check_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `base_check_cnt` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `bonus_check_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bonus_check_cnt` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_attendance_check_info`
--

LOCK TABLES `event_attendance_check_info` WRITE;
/*!40000 ALTER TABLE `event_attendance_check_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_attendance_check_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_clear_quest`
--

DROP TABLE IF EXISTS `event_clear_quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_clear_quest` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `clear_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='[2010-08] ｽﾅﾀﾎｾｾ ﾀﾌｺ･ﾆｮ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_clear_quest`
--

LOCK TABLES `event_clear_quest` WRITE;
/*!40000 ALTER TABLE `event_clear_quest` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_clear_quest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_create_charac`
--

DROP TABLE IF EXISTS `event_create_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_create_charac` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='[2010-08] ｽﾅﾀﾎｾｾ ﾀﾌｺ･ﾆｮ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_create_charac`
--

LOCK TABLES `event_create_charac` WRITE;
/*!40000 ALTER TABLE `event_create_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_create_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_create_dnf_info`
--

DROP TABLE IF EXISTS `event_create_dnf_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_create_dnf_info` (
  `event_day` int(5) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL,
  `rate` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_create_dnf_info`
--

LOCK TABLES `event_create_dnf_info` WRITE;
/*!40000 ALTER TABLE `event_create_dnf_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_create_dnf_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_create_dnf_user`
--

DROP TABLE IF EXISTS `event_create_dnf_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_create_dnf_user` (
  `occ_date` date NOT NULL,
  `m_id` int(11) NOT NULL,
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `occ_time` time NOT NULL,
  PRIMARY KEY (`occ_date`,`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_create_dnf_user`
--

LOCK TABLES `event_create_dnf_user` WRITE;
/*!40000 ALTER TABLE `event_create_dnf_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_create_dnf_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_give_title_twn`
--

DROP TABLE IF EXISTS `event_give_title_twn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_give_title_twn` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_give_title_twn`
--

LOCK TABLES `event_give_title_twn` WRITE;
/*!40000 ALTER TABLE `event_give_title_twn` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_give_title_twn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_hero_mission_data`
--

DROP TABLE IF EXISTS `event_hero_mission_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_hero_mission_data` (
  `server_group` tinyint(3) unsigned NOT NULL,
  `charac_no` int(10) unsigned NOT NULL,
  `mission` varchar(256) NOT NULL,
  `mod_date` datetime NOT NULL,
  PRIMARY KEY (`server_group`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_hero_mission_data`
--

LOCK TABLES `event_hero_mission_data` WRITE;
/*!40000 ALTER TABLE `event_hero_mission_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_hero_mission_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_ingame_history`
--

DROP TABLE IF EXISTS `event_ingame_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_ingame_history` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `history_1` int(10) unsigned NOT NULL DEFAULT '0',
  `history_2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_ingame_history`
--

LOCK TABLES `event_ingame_history` WRITE;
/*!40000 ALTER TABLE `event_ingame_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_ingame_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_login_reward_in_list`
--

DROP TABLE IF EXISTS `event_login_reward_in_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_login_reward_in_list` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reward_flag` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_login_reward_in_list`
--

LOCK TABLES `event_login_reward_in_list` WRITE;
/*!40000 ALTER TABLE `event_login_reward_in_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_login_reward_in_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_minority_point`
--

DROP TABLE IF EXISTS `event_minority_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_minority_point` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `point` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_minority_point`
--

LOCK TABLES `event_minority_point` WRITE;
/*!40000 ALTER TABLE `event_minority_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_minority_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_ontime_info`
--

DROP TABLE IF EXISTS `event_ontime_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_ontime_info` (
  `no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_index` int(10) unsigned NOT NULL DEFAULT '0',
  `item_count` int(10) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_ontime_info`
--

LOCK TABLES `event_ontime_info` WRITE;
/*!40000 ALTER TABLE `event_ontime_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_ontime_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_ontime_item`
--

DROP TABLE IF EXISTS `event_ontime_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_ontime_item` (
  `idx` int(10) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_ontime_item`
--

LOCK TABLES `event_ontime_item` WRITE;
/*!40000 ALTER TABLE `event_ontime_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_ontime_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_ontime_user`
--

DROP TABLE IF EXISTS `event_ontime_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_ontime_user` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `last_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_ontime_user`
--

LOCK TABLES `event_ontime_user` WRITE;
/*!40000 ALTER TABLE `event_ontime_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_ontime_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_purchase_cnt`
--

DROP TABLE IF EXISTS `event_purchase_cnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_purchase_cnt` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `purchase_cnt` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_purchase_cnt`
--

LOCK TABLES `event_purchase_cnt` WRITE;
/*!40000 ALTER TABLE `event_purchase_cnt` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_purchase_cnt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_reserving_charac_name`
--

DROP TABLE IF EXISTS `event_reserving_charac_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_reserving_charac_name` (
  `user_id` varchar(30) DEFAULT NULL,
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`server_info`,`charac_name`) USING BTREE,
  KEY `event_reserving_charac_name_idx001` (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_reserving_charac_name`
--

LOCK TABLES `event_reserving_charac_name` WRITE;
/*!40000 ALTER TABLE `event_reserving_charac_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_reserving_charac_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_reserving_charac_name_20130328`
--

DROP TABLE IF EXISTS `event_reserving_charac_name_20130328`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_reserving_charac_name_20130328` (
  `user_id` varchar(30) DEFAULT NULL,
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_reserving_charac_name_20130328`
--

LOCK TABLES `event_reserving_charac_name_20130328` WRITE;
/*!40000 ALTER TABLE `event_reserving_charac_name_20130328` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_reserving_charac_name_20130328` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_reserving_charac_name_20130329`
--

DROP TABLE IF EXISTS `event_reserving_charac_name_20130329`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_reserving_charac_name_20130329` (
  `user_id` varchar(30) DEFAULT NULL,
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`server_info`,`charac_name`),
  KEY `event_reserving_charac_name_idx001` (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_reserving_charac_name_20130329`
--

LOCK TABLES `event_reserving_charac_name_20130329` WRITE;
/*!40000 ALTER TABLE `event_reserving_charac_name_20130329` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_reserving_charac_name_20130329` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_return_user`
--

DROP TABLE IF EXISTS `event_return_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_return_user` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_return_user`
--

LOCK TABLES `event_return_user` WRITE;
/*!40000 ALTER TABLE `event_return_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_return_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_reward_item_arad`
--

DROP TABLE IF EXISTS `event_reward_item_arad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_reward_item_arad` (
  `event_id` int(10) NOT NULL DEFAULT '0',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`m_id`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_reward_item_arad`
--

LOCK TABLES `event_reward_item_arad` WRITE;
/*!40000 ALTER TABLE `event_reward_item_arad` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_reward_item_arad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_stamp_checkinfo`
--

DROP TABLE IF EXISTS `event_stamp_checkinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_stamp_checkinfo` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `current` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stamp_checkinfo` binary(96) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_stamp_checkinfo`
--

LOCK TABLES `event_stamp_checkinfo` WRITE;
/*!40000 ALTER TABLE `event_stamp_checkinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_stamp_checkinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_stamp_daily`
--

DROP TABLE IF EXISTS `event_stamp_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_stamp_daily` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `condition1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `condition2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `condition3` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_stamp_daily`
--

LOCK TABLES `event_stamp_daily` WRITE;
/*!40000 ALTER TABLE `event_stamp_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_stamp_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_stamp_reward`
--

DROP TABLE IF EXISTS `event_stamp_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_stamp_reward` (
  `check_step` smallint(5) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`check_step`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_stamp_reward`
--

LOCK TABLES `event_stamp_reward` WRITE;
/*!40000 ALTER TABLE `event_stamp_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_stamp_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_stay_time_charac`
--

DROP TABLE IF EXISTS `event_stay_time_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_stay_time_charac` (
  `m_id` int(10) unsigned NOT NULL,
  `reward_count` int(11) NOT NULL DEFAULT '0',
  `reward_flag` int(11) NOT NULL DEFAULT '0',
  `mod_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='대만 이벤트 [Go Go Fighter] 9:00~9:30 30분 사이 10분간 접속한 케릭터에게 보상 지급';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_stay_time_charac`
--

LOCK TABLES `event_stay_time_charac` WRITE;
/*!40000 ALTER TABLE `event_stay_time_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_stay_time_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_valentine_vote_base`
--

DROP TABLE IF EXISTS `event_valentine_vote_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_valentine_vote_base` (
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stage1` int(11) NOT NULL DEFAULT '0',
  `stage2` int(11) NOT NULL DEFAULT '0',
  `stage3` int(11) NOT NULL DEFAULT '0',
  `stage4` int(11) NOT NULL DEFAULT '0',
  `stage5` int(11) NOT NULL DEFAULT '0',
  `cur_event` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_valentine_vote_base`
--

LOCK TABLES `event_valentine_vote_base` WRITE;
/*!40000 ALTER TABLE `event_valentine_vote_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_valentine_vote_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_valentine_vote_history`
--

DROP TABLE IF EXISTS `event_valentine_vote_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_valentine_vote_history` (
  `check_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vote_A` int(11) NOT NULL DEFAULT '0',
  `vote_B` int(11) NOT NULL DEFAULT '0',
  `vote_C` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`check_date`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_valentine_vote_history`
--

LOCK TABLES `event_valentine_vote_history` WRITE;
/*!40000 ALTER TABLE `event_valentine_vote_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_valentine_vote_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_valentine_vote_history_old`
--

DROP TABLE IF EXISTS `event_valentine_vote_history_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_valentine_vote_history_old` (
  `check_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vote_A` tinyint(4) NOT NULL DEFAULT '0',
  `vote_B` tinyint(4) NOT NULL DEFAULT '0',
  `vote_C` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`check_date`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_valentine_vote_history_old`
--

LOCK TABLES `event_valentine_vote_history_old` WRITE;
/*!40000 ALTER TABLE `event_valentine_vote_history_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_valentine_vote_history_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_valentine_vote_info`
--

DROP TABLE IF EXISTS `event_valentine_vote_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_valentine_vote_info` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vote_A` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vote_B` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vote_C` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_valentine_vote_info`
--

LOCK TABLES `event_valentine_vote_info` WRITE;
/*!40000 ALTER TABLE `event_valentine_vote_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_valentine_vote_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_valentine_vote_info_old`
--

DROP TABLE IF EXISTS `event_valentine_vote_info_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_valentine_vote_info_old` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vote_A` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vote_B` tinyint(4) NOT NULL DEFAULT '0',
  `vote_C` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_valentine_vote_info_old`
--

LOCK TABLES `event_valentine_vote_info_old` WRITE;
/*!40000 ALTER TABLE `event_valentine_vote_info_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_valentine_vote_info_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_message`
--

DROP TABLE IF EXISTS `gm_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_message` (
  `event_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `msg_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_type` tinyint(4) NOT NULL DEFAULT '0',
  `msg` varchar(255) NOT NULL DEFAULT '0',
  `send_charac_name` varchar(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`,`server_id`,`msg_order`,`send_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_message`
--

LOCK TABLES `gm_message` WRITE;
/*!40000 ALTER TABLE `gm_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_game_ad`
--

DROP TABLE IF EXISTS `in_game_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_game_ad` (
  `banner_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `gender` tinyint(4) NOT NULL DEFAULT '-1',
  `age` tinyint(4) NOT NULL DEFAULT '-1',
  `job` tinyint(4) NOT NULL DEFAULT '-1',
  `level` varchar(255) NOT NULL DEFAULT '',
  `banner_url` varchar(255) NOT NULL DEFAULT '',
  `item_no` int(10) unsigned NOT NULL DEFAULT '0',
  `event_url` varchar(255) NOT NULL DEFAULT '',
  `ctrl_banner_url` varchar(255) NOT NULL DEFAULT '',
  `ctrl_event_url` varchar(255) NOT NULL DEFAULT '',
  `ctrl_item_no` int(11) NOT NULL DEFAULT '0',
  `ctrl_description` varchar(255) NOT NULL DEFAULT '',
  `min_sera` int(10) unsigned NOT NULL DEFAULT '0',
  `max_sera` int(10) unsigned NOT NULL DEFAULT '0',
  `type_code` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `limit_m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `view_code` int(10) unsigned NOT NULL DEFAULT '0',
  `image_url` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `log_flag` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ex_property` varchar(255) DEFAULT '',
  PRIMARY KEY (`banner_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_game_ad`
--

LOCK TABLES `in_game_ad` WRITE;
/*!40000 ALTER TABLE `in_game_ad` DISABLE KEYS */;
/*!40000 ALTER TABLE `in_game_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_common`
--

DROP TABLE IF EXISTS `login_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_common` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `member_bonus_fatigue` int(10) unsigned NOT NULL DEFAULT '0',
  `radio_flag` tinyint(4) NOT NULL DEFAULT '0',
  `daily_point` int(11) NOT NULL DEFAULT '0',
  `acc_point` int(11) NOT NULL DEFAULT '0',
  `random_option_guide` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `event_charac_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  `inform_notice` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_common`
--

LOCK TABLES `login_common` WRITE;
/*!40000 ALTER TABLE `login_common` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_auth_reward_tw`
--

DROP TABLE IF EXISTS `mobile_auth_reward_tw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_auth_reward_tw` (
  `m_id` int(10) unsigned NOT NULL,
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_auth_reward_tw`
--

LOCK TABLES `mobile_auth_reward_tw` WRITE;
/*!40000 ALTER TABLE `mobile_auth_reward_tw` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_auth_reward_tw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pcroom_daily_reward_tw`
--

DROP TABLE IF EXISTS `pcroom_daily_reward_tw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pcroom_daily_reward_tw` (
  `m_id` int(10) unsigned NOT NULL,
  `occ_date` datetime NOT NULL,
  `remain_reward_count` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pcroom_daily_reward_tw`
--

LOCK TABLES `pcroom_daily_reward_tw` WRITE;
/*!40000 ALTER TABLE `pcroom_daily_reward_tw` DISABLE KEYS */;
/*!40000 ALTER TABLE `pcroom_daily_reward_tw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_user`
--

DROP TABLE IF EXISTS `return_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_user` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `first_login` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_user`
--

LOCK TABLES `return_user` WRITE;
/*!40000 ALTER TABLE `return_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `return_user` ENABLE KEYS */;
UNLOCK TABLES;

--
