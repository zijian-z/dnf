-- generated from VMDK full dump
-- source_db=d_technical_report

--



--
-- Table structure for table `accessibility_stat`
--

DROP TABLE IF EXISTS `accessibility_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessibility_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `main_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `val` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`main_type`,`sub_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessibility_stat`
--

LOCK TABLES `accessibility_stat` WRITE;
/*!40000 ALTER TABLE `accessibility_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessibility_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assert_manager`
--

DROP TABLE IF EXISTS `assert_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assert_manager` (
  `file_name` varchar(255) NOT NULL DEFAULT '',
  `file_line` smallint(5) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`file_name`,`file_line`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assert_manager`
--

LOCK TABLES `assert_manager` WRITE;
/*!40000 ALTER TABLE `assert_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `assert_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_info`
--

DROP TABLE IF EXISTS `captcha_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_try_count` int(10) unsigned NOT NULL DEFAULT '0',
  `success_count` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_count` int(10) unsigned NOT NULL DEFAULT '0',
  `block_count` int(10) unsigned NOT NULL DEFAULT '0',
  `incomplete_request_count` int(10) unsigned NOT NULL DEFAULT '0',
  `invalid_request_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_info`
--

LOCK TABLES `captcha_info` WRITE;
/*!40000 ALTER TABLE `captcha_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `captcha_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_invalid_request`
--

DROP TABLE IF EXISTS `captcha_invalid_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_invalid_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `request_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_invalid_request`
--

LOCK TABLES `captcha_invalid_request` WRITE;
/*!40000 ALTER TABLE `captcha_invalid_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `captcha_invalid_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_invalid_request_type`
--

DROP TABLE IF EXISTS `captcha_invalid_request_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_invalid_request_type` (
  `type` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type_desc` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_invalid_request_type`
--

LOCK TABLES `captcha_invalid_request_type` WRITE;
/*!40000 ALTER TABLE `captcha_invalid_request_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `captcha_invalid_request_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_lag_index`
--

DROP TABLE IF EXISTS `challenge_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_lag_index`
--

LOCK TABLES `challenge_lag_index` WRITE;
/*!40000 ALTER TABLE `challenge_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenge_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_lag_index_daily`
--

DROP TABLE IF EXISTS `challenge_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_lag_index_daily`
--

LOCK TABLES `challenge_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `challenge_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenge_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collect_interval`
--

DROP TABLE IF EXISTS `collect_interval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collect_interval` (
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `value` smallint(5) unsigned DEFAULT '60'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collect_interval`
--

LOCK TABLES `collect_interval` WRITE;
/*!40000 ALTER TABLE `collect_interval` DISABLE KEYS */;
/*!40000 ALTER TABLE `collect_interval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_index`
--

DROP TABLE IF EXISTS `common_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `share_rate` int(10) unsigned DEFAULT NULL,
  `crash_count` smallint(5) unsigned DEFAULT NULL,
  `village_to_dungeon_lag` smallint(6) NOT NULL DEFAULT '0',
  `dungeon_to_village_lag` smallint(6) NOT NULL DEFAULT '0',
  `crash_village` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_dungeon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_challenge` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_wararea` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_fight_village` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_dead_tower` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_channel` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_chaos` smallint(5) unsigned NOT NULL DEFAULT '0',
  `crash_load` smallint(5) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_index`
--

LOCK TABLES `common_index` WRITE;
/*!40000 ALTER TABLE `common_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_index_daily`
--

DROP TABLE IF EXISTS `common_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  `crash_village` int(11) NOT NULL DEFAULT '0',
  `crash_dungeon` int(11) NOT NULL DEFAULT '0',
  `crash_challenge` int(11) NOT NULL DEFAULT '0',
  `crash_wararea` int(11) NOT NULL DEFAULT '0',
  `crash_fight_village` int(11) NOT NULL DEFAULT '0',
  `crash_dead_tower` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`server_group`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_index_daily`
--

LOCK TABLES `common_index_daily` WRITE;
/*!40000 ALTER TABLE `common_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dead_tower_lag_index`
--

DROP TABLE IF EXISTS `dead_tower_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dead_tower_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dead_tower_lag_index`
--

LOCK TABLES `dead_tower_lag_index` WRITE;
/*!40000 ALTER TABLE `dead_tower_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `dead_tower_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dead_tower_lag_index_daily`
--

DROP TABLE IF EXISTS `dead_tower_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dead_tower_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dead_tower_lag_index_daily`
--

LOCK TABLES `dead_tower_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `dead_tower_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `dead_tower_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deathtower_ting_log`
--

DROP TABLE IF EXISTS `deathtower_ting_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deathtower_ting_log` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ting_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deathtower_ting_log`
--

LOCK TABLES `deathtower_ting_log` WRITE;
/*!40000 ALTER TABLE `deathtower_ting_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `deathtower_ting_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deathtower_ting_log_daily`
--

DROP TABLE IF EXISTS `deathtower_ting_log_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deathtower_ting_log_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ting_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deathtower_ting_log_daily`
--

LOCK TABLES `deathtower_ting_log_daily` WRITE;
/*!40000 ALTER TABLE `deathtower_ting_log_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `deathtower_ting_log_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directx_version`
--

DROP TABLE IF EXISTS `directx_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `directx_version` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `ver_etc` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_8_x` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_9_0` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_9_0_a` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_9_0_b` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_9_0_c` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_10_x` int(10) unsigned NOT NULL DEFAULT '0',
  `ver_11_x` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_group`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directx_version`
--

LOCK TABLES `directx_version` WRITE;
/*!40000 ALTER TABLE `directx_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `directx_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dungeon_lag_index`
--

DROP TABLE IF EXISTS `dungeon_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dungeon_lag_index`
--

LOCK TABLES `dungeon_lag_index` WRITE;
/*!40000 ALTER TABLE `dungeon_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `dungeon_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dungeon_lag_index_daily`
--

DROP TABLE IF EXISTS `dungeon_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dungeon_lag_index_daily`
--

LOCK TABLES `dungeon_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `dungeon_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `dungeon_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fight_village_lag_index`
--

DROP TABLE IF EXISTS `fight_village_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fight_village_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fight_village_lag_index`
--

LOCK TABLES `fight_village_lag_index` WRITE;
/*!40000 ALTER TABLE `fight_village_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `fight_village_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fight_village_lag_index_daily`
--

DROP TABLE IF EXISTS `fight_village_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fight_village_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fight_village_lag_index_daily`
--

LOCK TABLES `fight_village_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `fight_village_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `fight_village_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lag_stat_dungeon`
--

DROP TABLE IF EXISTS `lag_stat_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_stat_dungeon` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon_idx` int(11) NOT NULL DEFAULT '0',
  `first_average` int(10) unsigned NOT NULL DEFAULT '0',
  `first_deviation` int(10) unsigned NOT NULL DEFAULT '0',
  `first_count` int(11) NOT NULL DEFAULT '0',
  `boss_average` int(10) unsigned NOT NULL DEFAULT '0',
  `boss_deviation` int(10) unsigned NOT NULL DEFAULT '0',
  `boss_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_id`,`dungeon_idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lag_stat_dungeon`
--

LOCK TABLES `lag_stat_dungeon` WRITE;
/*!40000 ALTER TABLE `lag_stat_dungeon` DISABLE KEYS */;
/*!40000 ALTER TABLE `lag_stat_dungeon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lag_stat_module`
--

DROP TABLE IF EXISTS `lag_stat_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_stat_module` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `module` tinyint(4) NOT NULL DEFAULT '0',
  `average` int(10) unsigned NOT NULL DEFAULT '0',
  `deviation` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_id`,`module`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lag_stat_module`
--

LOCK TABLES `lag_stat_module` WRITE;
/*!40000 ALTER TABLE `lag_stat_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `lag_stat_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loading_time`
--

DROP TABLE IF EXISTS `loading_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loading_time` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `load_sec` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_id`,`type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loading_time`
--

LOCK TABLES `loading_time` WRITE;
/*!40000 ALTER TABLE `loading_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `loading_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_launcher_stat`
--

DROP TABLE IF EXISTS `log_launcher_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_launcher_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `execute` int(11) NOT NULL DEFAULT '0',
  `cancel` int(11) NOT NULL DEFAULT '0',
  `success` int(11) NOT NULL DEFAULT '0',
  `first_success` int(11) NOT NULL DEFAULT '0',
  `p2p` double NOT NULL DEFAULT '0',
  `all_time` bigint(20) NOT NULL DEFAULT '0',
  `p2p_count` int(11) NOT NULL DEFAULT '0',
  `all_time_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_launcher_stat`
--

LOCK TABLES `log_launcher_stat` WRITE;
/*!40000 ALTER TABLE `log_launcher_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_launcher_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitoring_spec`
--

DROP TABLE IF EXISTS `monitoring_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitoring_spec` (
  `unique_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modify_time` datetime DEFAULT NULL,
  `spec_id` int(10) unsigned DEFAULT NULL,
  `cpu_vendor` tinyint(4) NOT NULL DEFAULT '0',
  `cpu_processor_num` tinyint(4) NOT NULL DEFAULT '0',
  `above_cpu_clock` int(11) NOT NULL DEFAULT '0',
  `below_cpu_clock` int(11) NOT NULL DEFAULT '0',
  `ram` smallint(6) NOT NULL DEFAULT '0',
  `videocard_vendor` int(11) NOT NULL DEFAULT '0',
  `videocard_device` int(11) NOT NULL DEFAULT '0',
  `videocard_texture_mem` smallint(6) NOT NULL DEFAULT '0',
  `os_version` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`unique_id`) USING BTREE,
  KEY `idx1` (`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitoring_spec`
--

LOCK TABLES `monitoring_spec` WRITE;
/*!40000 ALTER TABLE `monitoring_spec` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitoring_spec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p2p_connect_success_rate`
--

DROP TABLE IF EXISTS `p2p_connect_success_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2p_connect_success_rate` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_group` tinyint(3) unsigned NOT NULL,
  `connected_type` tinyint(4) NOT NULL,
  `required_time` int(10) unsigned NOT NULL,
  `check_time` int(10) unsigned NOT NULL DEFAULT '0',
  `nation_code` varchar(15) NOT NULL,
  `peer_address` varchar(15) NOT NULL,
  `occ_date` datetime NOT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='대만 P2P 홀펀칭 성공&실패 여결 타입과 IP까지 함께남기는 작업';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p2p_connect_success_rate`
--

LOCK TABLES `p2p_connect_success_rate` WRITE;
/*!40000 ALTER TABLE `p2p_connect_success_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `p2p_connect_success_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p2p_statistics`
--

DROP TABLE IF EXISTS `p2p_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2p_statistics` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `p2p_user` int(10) unsigned DEFAULT '0',
  `p2p_min_ping` int(10) unsigned DEFAULT '0',
  `p2p_max_ping` int(10) unsigned DEFAULT '0',
  `p2p_avg_ping` int(10) unsigned DEFAULT '0',
  `p2p_over_ping_100` int(10) unsigned DEFAULT '0',
  `p2p_over_ping_200` int(10) unsigned DEFAULT '0',
  `p2p_over_ping_300` int(10) unsigned DEFAULT '0',
  `p2p_over_ping_400` int(10) unsigned DEFAULT '0',
  `relay_user` int(10) unsigned DEFAULT '0',
  `relay_min_ping` int(10) unsigned DEFAULT '0',
  `relay_max_ping` int(10) unsigned DEFAULT '0',
  `relay_avg_ping` int(10) unsigned DEFAULT '0',
  `relay_over_ping_100` int(10) unsigned DEFAULT '0',
  `relay_over_ping_200` int(10) unsigned DEFAULT '0',
  `relay_over_ping_300` int(10) unsigned DEFAULT '0',
  `relay_over_ping_400` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_group`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p2p_statistics`
--

LOCK TABLES `p2p_statistics` WRITE;
/*!40000 ALTER TABLE `p2p_statistics` DISABLE KEYS */;
INSERT INTO `p2p_statistics` VALUES ('2026-01-30 09:47:55',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:36:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:37:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:38:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:39:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:40:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:41:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:42:00',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:42:59',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:43:59',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:44:59',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:45:59',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 14:46:59',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 15:07:42',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-02-28 15:08:42',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:03:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:04:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:05:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:06:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:07:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:08:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:09:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:10:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:11:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:12:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:13:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:14:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:15:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:16:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:17:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:18:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:19:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:20:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:21:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:22:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:23:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:24:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:25:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:26:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:27:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:28:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:29:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:30:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:31:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:32:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:33:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:34:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:35:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:36:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('2026-03-10 11:37:10',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `p2p_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p2pnetwork_statistic`
--

DROP TABLE IF EXISTS `p2pnetwork_statistic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2pnetwork_statistic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `success_party_try` int(11) NOT NULL DEFAULT '0',
  `total_party_try` int(11) NOT NULL DEFAULT '0',
  `dungeon_bad_ping` int(11) NOT NULL DEFAULT '0',
  `dungeon_total` int(11) NOT NULL DEFAULT '0',
  `pvp_bad_ping` int(11) NOT NULL DEFAULT '0',
  `pvp_total` int(11) NOT NULL DEFAULT '0',
  `success_dungeon_clear` int(11) NOT NULL DEFAULT '0',
  `total_dungeon_clear` int(11) NOT NULL DEFAULT '0',
  `fair_pvp_total` int(11) DEFAULT NULL,
  `fair_pvp_bad_ping` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx1` (`occ_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p2pnetwork_statistic`
--

LOCK TABLES `p2pnetwork_statistic` WRITE;
/*!40000 ALTER TABLE `p2pnetwork_statistic` DISABLE KEYS */;
INSERT INTO `p2pnetwork_statistic` VALUES (1,'2026-03-10 11:32:10',3,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `p2pnetwork_statistic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p2pnetwork_statistic_daily`
--

DROP TABLE IF EXISTS `p2pnetwork_statistic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2pnetwork_statistic_daily` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `success_party` float(3,2) NOT NULL DEFAULT '0.00',
  `dungeon_bad` float(3,2) NOT NULL DEFAULT '0.00',
  `pvp_bad` float(3,2) NOT NULL DEFAULT '0.00',
  `success_dungeon_clear` float(3,2) NOT NULL DEFAULT '0.00',
  `fair_pvp_bad` float(3,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`cur_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p2pnetwork_statistic_daily`
--

LOCK TABLES `p2pnetwork_statistic_daily` WRITE;
/*!40000 ALTER TABLE `p2pnetwork_statistic_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `p2pnetwork_statistic_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packet_overflow`
--

DROP TABLE IF EXISTS `packet_overflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packet_overflow` (
  `packet_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `packet_kind` varchar(255) NOT NULL DEFAULT '',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`packet_type`,`packet_kind`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packet_overflow`
--

LOCK TABLES `packet_overflow` WRITE;
/*!40000 ALTER TABLE `packet_overflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `packet_overflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerwar_lag`
--

DROP TABLE IF EXISTS `powerwar_lag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_lag` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `round` smallint(5) unsigned NOT NULL DEFAULT '0',
  `player` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lag_avg` float unsigned NOT NULL DEFAULT '0',
  `lag_cnt` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_time`,`round`) USING BTREE,
  KEY `round_idx` (`occ_time`,`round`) USING BTREE,
  KEY `player_idx` (`occ_time`,`player`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerwar_lag`
--

LOCK TABLES `powerwar_lag` WRITE;
/*!40000 ALTER TABLE `powerwar_lag` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerwar_lag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerwar_loading`
--

DROP TABLE IF EXISTS `powerwar_loading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_loading` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `round` smallint(5) unsigned NOT NULL DEFAULT '0',
  `player` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `my_loading` smallint(5) unsigned NOT NULL DEFAULT '0',
  `other_loading` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vs_loading` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_time`,`round`) USING BTREE,
  KEY `round_idx` (`occ_time`,`round`) USING BTREE,
  KEY `player_idx` (`occ_time`,`player`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerwar_loading`
--

LOCK TABLES `powerwar_loading` WRITE;
/*!40000 ALTER TABLE `powerwar_loading` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerwar_loading` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `powerwar_ting_type`
--

DROP TABLE IF EXISTS `powerwar_ting_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_ting_type` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ting_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ting_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_id`,`ting_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `powerwar_ting_type`
--

LOCK TABLES `powerwar_ting_type` WRITE;
/*!40000 ALTER TABLE `powerwar_ting_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `powerwar_ting_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spec_info`
--

DROP TABLE IF EXISTS `spec_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spec_info` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` int(10) unsigned NOT NULL DEFAULT '0',
  `device_id` int(10) unsigned NOT NULL DEFAULT '0',
  `vendor_name` varchar(50) NOT NULL DEFAULT '',
  `device_name` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spec_info`
--

LOCK TABLES `spec_info` WRITE;
/*!40000 ALTER TABLE `spec_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `spec_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `technical_category`
--

DROP TABLE IF EXISTS `technical_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technical_category` (
  `cateno` int(11) unsigned NOT NULL DEFAULT '0',
  `pcateno` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `step` int(11) NOT NULL DEFAULT '0',
  KEY `idx1` (`cateno`,`pcateno`) USING BTREE,
  KEY `idx2` (`pcateno`,`cateno`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technical_category`
--

LOCK TABLES `technical_category` WRITE;
/*!40000 ALTER TABLE `technical_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `technical_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ting_user_account`
--

DROP TABLE IF EXISTS `ting_user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ting_user_account` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `minute` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ting_user_account`
--

LOCK TABLES `ting_user_account` WRITE;
/*!40000 ALTER TABLE `ting_user_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `ting_user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ting_user_spec`
--

DROP TABLE IF EXISTS `ting_user_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ting_user_spec` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cpu_vendor` char(1) NOT NULL DEFAULT '0',
  `cpu_num` char(1) NOT NULL DEFAULT '0',
  `cpu_clock` int(10) unsigned NOT NULL DEFAULT '0',
  `ram` smallint(5) unsigned NOT NULL DEFAULT '0',
  `video_vendor` smallint(5) unsigned NOT NULL DEFAULT '0',
  `video_device` smallint(5) unsigned NOT NULL DEFAULT '0',
  `video_ram` smallint(5) unsigned NOT NULL DEFAULT '0',
  `os` char(1) NOT NULL DEFAULT '0',
  `os_bit` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ting_user_spec`
--

LOCK TABLES `ting_user_spec` WRITE;
/*!40000 ALTER TABLE `ting_user_spec` DISABLE KEYS */;
/*!40000 ALTER TABLE `ting_user_spec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `used_memory`
--

DROP TABLE IF EXISTS `used_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `used_memory` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `minute_type` char(1) NOT NULL DEFAULT '0',
  `module` char(1) NOT NULL DEFAULT '0',
  `memory` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`minute_type`,`module`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `used_memory`
--

LOCK TABLES `used_memory` WRITE;
/*!40000 ALTER TABLE `used_memory` DISABLE KEYS */;
/*!40000 ALTER TABLE `used_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ting_timecheck`
--

DROP TABLE IF EXISTS `user_ting_timecheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ting_timecheck` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `minute` int(11) NOT NULL DEFAULT '0',
  `cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`minute`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ting_timecheck`
--

LOCK TABLES `user_ting_timecheck` WRITE;
/*!40000 ALTER TABLE `user_ting_timecheck` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ting_timecheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village_lag_index`
--

DROP TABLE IF EXISTS `village_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village_lag_index`
--

LOCK TABLES `village_lag_index` WRITE;
/*!40000 ALTER TABLE `village_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `village_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `village_lag_index_daily`
--

DROP TABLE IF EXISTS `village_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `village_lag_index_daily`
--

LOCK TABLES `village_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `village_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `village_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wararea_lag_index`
--

DROP TABLE IF EXISTS `wararea_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wararea_lag_index` (
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime DEFAULT NULL,
  `server_group` tinyint(4) NOT NULL DEFAULT '0',
  `min_fps` smallint(6) NOT NULL DEFAULT '0',
  `avg_fps` smallint(6) NOT NULL DEFAULT '0',
  `max_fps` smallint(6) NOT NULL DEFAULT '0',
  `win_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_fps` smallint(6) NOT NULL DEFAULT '0',
  `full_win_fps` smallint(6) DEFAULT '0',
  `full_win_nosync_fps` smallint(6) NOT NULL DEFAULT '0',
  `frame1` int(11) NOT NULL DEFAULT '0',
  `time1` float(7,3) NOT NULL DEFAULT '0.000',
  `frame2` int(11) NOT NULL DEFAULT '0',
  `time2` float(7,3) NOT NULL DEFAULT '0.000',
  `frame3` int(11) NOT NULL DEFAULT '0',
  `time3` float(7,3) NOT NULL DEFAULT '0.000',
  `frame4` int(11) NOT NULL DEFAULT '0',
  `time4` float(7,3) NOT NULL DEFAULT '0.000',
  `frame5` int(11) NOT NULL DEFAULT '0',
  `time5` float(7,3) NOT NULL DEFAULT '0.000',
  `frame6` int(11) NOT NULL DEFAULT '0',
  `time6` float(7,3) NOT NULL DEFAULT '0.000',
  `share_rate` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`spec_id`,`occ_time`,`server_group`) USING BTREE,
  KEY `idx2` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wararea_lag_index`
--

LOCK TABLES `wararea_lag_index` WRITE;
/*!40000 ALTER TABLE `wararea_lag_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `wararea_lag_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wararea_lag_index_daily`
--

DROP TABLE IF EXISTS `wararea_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wararea_lag_index_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_fps_cnt` int(11) NOT NULL DEFAULT '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`spec_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wararea_lag_index_daily`
--

LOCK TABLES `wararea_lag_index_daily` WRITE;
/*!40000 ALTER TABLE `wararea_lag_index_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `wararea_lag_index_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'd_technical_report'
--

--
-- Dumping routines for database 'd_technical_report'
--

--
