-- generated from VMDK full dump
-- source_db=taiwan_cain_log

--



--
-- Table structure for table `channel_lev_status`
--

DROP TABLE IF EXISTS `channel_lev_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_lev_status` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '0',
  `occ_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`lev`) USING BTREE,
  KEY `idx_channel_no` (`channel_no`) USING BTREE,
  KEY `idx_lev` (`lev`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_lev_status`
--

LOCK TABLES `channel_lev_status` WRITE;
/*!40000 ALTER TABLE `channel_lev_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_lev_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_down`
--

DROP TABLE IF EXISTS `client_down`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_down` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `occ_count` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_down`
--

LOCK TABLES `client_down` WRITE;
/*!40000 ALTER TABLE `client_down` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_down` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concurrent_user_status`
--

DROP TABLE IF EXISTS `concurrent_user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `concurrent_user_status` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `player_status` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `occ_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`player_status`,`dungeon_index`,`channel_no`) USING BTREE,
  KEY `idx_player_status` (`player_status`) USING BTREE,
  KEY `idx_dungeon_index` (`dungeon_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concurrent_user_status`
--

LOCK TABLES `concurrent_user_status` WRITE;
/*!40000 ALTER TABLE `concurrent_user_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `concurrent_user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crash_down_by_dungeon`
--

DROP TABLE IF EXISTS `crash_down_by_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crash_down_by_dungeon` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `down_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`dungeon_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crash_down_by_dungeon`
--

LOCK TABLES `crash_down_by_dungeon` WRITE;
/*!40000 ALTER TABLE `crash_down_by_dungeon` DISABLE KEYS */;
/*!40000 ALTER TABLE `crash_down_by_dungeon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crash_down_by_packet`
--

DROP TABLE IF EXISTS `crash_down_by_packet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crash_down_by_packet` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `packet_index` smallint(5) NOT NULL DEFAULT '0',
  `down_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`packet_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crash_down_by_packet`
--

LOCK TABLES `crash_down_by_packet` WRITE;
/*!40000 ALTER TABLE `crash_down_by_packet` DISABLE KEYS */;
/*!40000 ALTER TABLE `crash_down_by_packet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crash_down_by_playstatus`
--

DROP TABLE IF EXISTS `crash_down_by_playstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crash_down_by_playstatus` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `play_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `down_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`play_status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crash_down_by_playstatus`
--

LOCK TABLES `crash_down_by_playstatus` WRITE;
/*!40000 ALTER TABLE `crash_down_by_playstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `crash_down_by_playstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `d_date`
--

DROP TABLE IF EXISTS `d_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `d_date` (
  `aa` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `d_date`
--

LOCK TABLES `d_date` WRITE;
/*!40000 ALTER TABLE `d_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `d_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_dbq_log`
--

DROP TABLE IF EXISTS `dnf_dbq_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_dbq_log` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dbq` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_dbq_log`
--

LOCK TABLES `dnf_dbq_log` WRITE;
/*!40000 ALTER TABLE `dnf_dbq_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_dbq_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_hack_log`
--

DROP TABLE IF EXISTS `dnf_hack_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_hack_log` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `etc` int(10) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`m_id`,`hack_type`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_hack_log`
--

LOCK TABLES `dnf_hack_log` WRITE;
/*!40000 ALTER TABLE `dnf_hack_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_hack_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_hack_log_del`
--

DROP TABLE IF EXISTS `dnf_hack_log_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_hack_log_del` (
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `hack_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `etc` int(10) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`sdate`,`occ_date`,`m_id`,`hack_type`) USING BTREE,
  KEY `idx_occdate` (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_hack_log_del`
--

LOCK TABLES `dnf_hack_log_del` WRITE;
/*!40000 ALTER TABLE `dnf_hack_log_del` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_hack_log_del` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_party_ping_history`
--

DROP TABLE IF EXISTS `dnf_party_ping_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_party_ping_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `str_ip` char(16) NOT NULL DEFAULT '',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `ip_1` char(16) NOT NULL DEFAULT '',
  `nat_type_1` tinyint(4) NOT NULL DEFAULT '0',
  `ping1` int(11) NOT NULL DEFAULT '0',
  `mtu_1` int(11) NOT NULL DEFAULT '0',
  `ip_2` char(16) NOT NULL DEFAULT '',
  `nat_type_2` tinyint(4) NOT NULL DEFAULT '0',
  `ping2` int(11) NOT NULL DEFAULT '0',
  `mtu_2` int(11) NOT NULL DEFAULT '0',
  `ip_3` char(16) NOT NULL DEFAULT '',
  `nat_type_3` tinyint(4) NOT NULL DEFAULT '0',
  `ping3` int(11) NOT NULL DEFAULT '0',
  `mtu_3` int(11) NOT NULL DEFAULT '0',
  `ip_4` char(16) NOT NULL DEFAULT '',
  `nat_type_4` tinyint(4) NOT NULL DEFAULT '0',
  `ping4` int(11) NOT NULL DEFAULT '0',
  `mtu_4` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_id` int(11) NOT NULL DEFAULT '0',
  `dungeon_id` int(11) NOT NULL DEFAULT '0',
  `end_reason` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_party_ping_history`
--

LOCK TABLES `dnf_party_ping_history` WRITE;
/*!40000 ALTER TABLE `dnf_party_ping_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_party_ping_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_party_ping_history_pvp`
--

DROP TABLE IF EXISTS `dnf_party_ping_history_pvp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_party_ping_history_pvp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `str_ip` char(16) NOT NULL DEFAULT '',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `ip_1` char(16) NOT NULL DEFAULT '',
  `nat_type_1` tinyint(4) NOT NULL DEFAULT '0',
  `ping1` int(11) NOT NULL DEFAULT '0',
  `mtu_1` int(11) NOT NULL DEFAULT '0',
  `ip_2` char(16) NOT NULL DEFAULT '',
  `nat_type_2` tinyint(4) NOT NULL DEFAULT '0',
  `ping2` int(11) NOT NULL DEFAULT '0',
  `mtu_2` int(11) NOT NULL DEFAULT '0',
  `ip_3` char(16) NOT NULL DEFAULT '',
  `nat_type_3` tinyint(4) NOT NULL DEFAULT '0',
  `ping3` int(11) NOT NULL DEFAULT '0',
  `mtu_3` int(11) NOT NULL DEFAULT '0',
  `ip_4` char(16) NOT NULL DEFAULT '',
  `nat_type_4` tinyint(4) NOT NULL DEFAULT '0',
  `ping4` int(11) NOT NULL DEFAULT '0',
  `mtu_4` int(11) NOT NULL DEFAULT '0',
  `ip_5` char(16) NOT NULL DEFAULT '',
  `nat_type_5` tinyint(4) NOT NULL DEFAULT '0',
  `ping5` int(11) NOT NULL DEFAULT '0',
  `mtu_5` int(11) NOT NULL DEFAULT '0',
  `ip_6` char(16) NOT NULL DEFAULT '',
  `nat_type_6` tinyint(4) NOT NULL DEFAULT '0',
  `ping6` int(11) NOT NULL DEFAULT '0',
  `mtu_6` int(11) NOT NULL DEFAULT '0',
  `ip_7` char(16) NOT NULL DEFAULT '',
  `nat_type_7` tinyint(4) NOT NULL DEFAULT '0',
  `ping7` int(11) NOT NULL DEFAULT '0',
  `mtu_7` int(11) NOT NULL DEFAULT '0',
  `ip_8` char(16) NOT NULL DEFAULT '',
  `nat_type_8` tinyint(4) NOT NULL DEFAULT '0',
  `ping8` int(11) NOT NULL DEFAULT '0',
  `mtu_8` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_id` int(11) NOT NULL DEFAULT '0',
  `dungeon_id` int(11) NOT NULL DEFAULT '0',
  `end_reason` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_party_ping_history_pvp`
--

LOCK TABLES `dnf_party_ping_history_pvp` WRITE;
/*!40000 ALTER TABLE `dnf_party_ping_history_pvp` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_party_ping_history_pvp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_party_result_history`
--

DROP TABLE IF EXISTS `dnf_party_result_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_party_result_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `str_ip` char(16) NOT NULL DEFAULT '',
  `nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `party_result` tinyint(4) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_id` int(11) NOT NULL DEFAULT '0',
  `dungeon_id` int(11) NOT NULL DEFAULT '0',
  `peer_ip` char(16) NOT NULL DEFAULT '',
  `peer_nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `established_time` int(10) unsigned NOT NULL DEFAULT '0',
  `IsConnectedToRelaySrv` char(1) NOT NULL DEFAULT '',
  `ConnectedTimeToRelaySrv` int(10) unsigned NOT NULL DEFAULT '0',
  `relay_ip` char(16) NOT NULL DEFAULT '',
  `relay_udp_port` int(10) unsigned NOT NULL DEFAULT '0',
  `relay_tcp_port` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_party_result_history`
--

LOCK TABLES `dnf_party_result_history` WRITE;
/*!40000 ALTER TABLE `dnf_party_result_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_party_result_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_party_result_history_pvp`
--

DROP TABLE IF EXISTS `dnf_party_result_history_pvp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_party_result_history_pvp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `str_ip` char(16) NOT NULL DEFAULT '',
  `nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `party_result` tinyint(4) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_id` int(11) NOT NULL DEFAULT '0',
  `dungeon_id` int(11) NOT NULL DEFAULT '0',
  `peer_ip` char(16) NOT NULL DEFAULT '',
  `peer_nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `established_time` int(10) unsigned NOT NULL DEFAULT '0',
  `IsConnectedToRelaySrv` char(1) NOT NULL DEFAULT '',
  `ConnectedTimeToRelaySrv` int(10) unsigned NOT NULL DEFAULT '0',
  `relay_ip` char(16) NOT NULL DEFAULT '',
  `relay_udp_port` int(10) unsigned NOT NULL DEFAULT '0',
  `relay_tcp_port` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_party_result_history_pvp`
--

LOCK TABLES `dnf_party_result_history_pvp` WRITE;
/*!40000 ALTER TABLE `dnf_party_result_history_pvp` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_party_result_history_pvp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_party_stat_history`
--

DROP TABLE IF EXISTS `dnf_party_stat_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_party_stat_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `str_ip` char(16) NOT NULL DEFAULT '',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `try_num` int(11) NOT NULL DEFAULT '0',
  `party_result` char(30) NOT NULL DEFAULT '',
  `party_num` int(11) NOT NULL DEFAULT '0',
  `ping1` int(11) NOT NULL DEFAULT '0',
  `ping2` int(11) NOT NULL DEFAULT '0',
  `ping3` int(11) NOT NULL DEFAULT '0',
  `ping4` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_party_stat_history`
--

LOCK TABLES `dnf_party_stat_history` WRITE;
/*!40000 ALTER TABLE `dnf_party_stat_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_party_stat_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_proxy_log`
--

DROP TABLE IF EXISTS `dnf_proxy_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_proxy_log` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `nat_ip` varchar(16) NOT NULL DEFAULT '',
  `peer_ip` varchar(16) NOT NULL DEFAULT '',
  `nat_tye` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_proxy_log`
--

LOCK TABLES `dnf_proxy_log` WRITE;
/*!40000 ALTER TABLE `dnf_proxy_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_proxy_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_zeromoney_log`
--

DROP TABLE IF EXISTS `dnf_zeromoney_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_zeromoney_log` (
  `to_m_id` int(11) NOT NULL DEFAULT '0',
  `to_nat_ip` varchar(16) NOT NULL DEFAULT '',
  `to_peer_ip` varchar(16) NOT NULL DEFAULT '',
  `to_nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `to_mac_addr` varchar(64) NOT NULL DEFAULT '',
  `from_m_id` int(11) NOT NULL DEFAULT '0',
  `from_nat_ip` varchar(16) NOT NULL DEFAULT '',
  `from_peer_ip` varchar(16) NOT NULL DEFAULT '',
  `from_nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `from_mac_addr` varchar(64) NOT NULL DEFAULT '',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `injury_money` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx_to_m_id` (`to_m_id`) USING BTREE,
  KEY `idx_from_m_id` (`from_m_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_zeromoney_log`
--

LOCK TABLES `dnf_zeromoney_log` WRITE;
/*!40000 ALTER TABLE `dnf_zeromoney_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_zeromoney_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dungeon_fail`
--

DROP TABLE IF EXISTS `dungeon_fail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_fail` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `lev` tinyint(4) NOT NULL DEFAULT '0',
  `occ_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`lev`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dungeon_fail`
--

LOCK TABLES `dungeon_fail` WRITE;
/*!40000 ALTER TABLE `dungeon_fail` DISABLE KEYS */;
/*!40000 ALTER TABLE `dungeon_fail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dungeon_lev_log`
--

DROP TABLE IF EXISTS `dungeon_lev_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_lev_log` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `dungeon_id` int(11) NOT NULL DEFAULT '0',
  `sum_lev` int(11) NOT NULL DEFAULT '0',
  `used_coin` int(11) NOT NULL DEFAULT '0',
  `try_cnt` int(11) NOT NULL DEFAULT '0',
  `clear_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`dungeon_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dungeon_lev_log`
--

LOCK TABLES `dungeon_lev_log` WRITE;
/*!40000 ALTER TABLE `dungeon_lev_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dungeon_lev_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_goldcard_log`
--

DROP TABLE IF EXISTS `event_goldcard_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_goldcard_log` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_goldcard_log`
--

LOCK TABLES `event_goldcard_log` WRITE;
/*!40000 ALTER TABLE `event_goldcard_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_goldcard_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_quest_party_member`
--

DROP TABLE IF EXISTS `event_quest_party_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_quest_party_member` (
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  `quest_no` int(11) NOT NULL DEFAULT '0',
  `member_1` int(11) NOT NULL DEFAULT '0',
  `member_1_name` varchar(20) NOT NULL DEFAULT '',
  `member_1_lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `member_2` int(11) NOT NULL DEFAULT '0',
  `member_2_name` varchar(20) NOT NULL DEFAULT '',
  `member_2_lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `member_3` int(11) NOT NULL DEFAULT '0',
  `member_3_name` varchar(20) NOT NULL DEFAULT '',
  `member_3_lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`quest_no`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_quest_party_member`
--

LOCK TABLES `event_quest_party_member` WRITE;
/*!40000 ALTER TABLE `event_quest_party_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_quest_party_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_acquire_item`
--

DROP TABLE IF EXISTS `log_acquire_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_acquire_item` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `m_id` bigint(20) unsigned DEFAULT NULL,
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `item_type` int(11) NOT NULL DEFAULT '0',
  `item_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`charac_no`,`item_id`) USING BTREE,
  KEY `idx_date_mid_itemid` (`occ_date`,`m_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_acquire_item`
--

LOCK TABLES `log_acquire_item` WRITE;
/*!40000 ALTER TABLE `log_acquire_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_acquire_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_advance_alter_entrance`
--

DROP TABLE IF EXISTS `log_advance_alter_entrance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_advance_alter_entrance` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `stage_id` int(10) unsigned NOT NULL DEFAULT '0',
  `entrance_count` int(10) unsigned NOT NULL DEFAULT '0',
  `success_count` int(10) unsigned NOT NULL DEFAULT '0',
  `obtain_star` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`stage_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_advance_alter_entrance`
--

LOCK TABLES `log_advance_alter_entrance` WRITE;
/*!40000 ALTER TABLE `log_advance_alter_entrance` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_advance_alter_entrance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_advance_alter_layer_stat`
--

DROP TABLE IF EXISTS `log_advance_alter_layer_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_advance_alter_layer_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `item_type` smallint(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(5) unsigned NOT NULL DEFAULT '0',
  `item_level` smallint(10) unsigned NOT NULL DEFAULT '0',
  `use_count` smallint(10) unsigned NOT NULL DEFAULT '0',
  `use_star` smallint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`item_type`,`item_id`,`item_level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_advance_alter_layer_stat`
--

LOCK TABLES `log_advance_alter_layer_stat` WRITE;
/*!40000 ALTER TABLE `log_advance_alter_layer_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_advance_alter_layer_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_arad_event_stat`
--

DROP TABLE IF EXISTS `log_arad_event_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_arad_event_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_arad_event_stat`
--

LOCK TABLES `log_arad_event_stat` WRITE;
/*!40000 ALTER TABLE `log_arad_event_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_arad_event_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_assault`
--

DROP TABLE IF EXISTS `log_assault`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_assault` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `channel_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `assault_count` int(10) unsigned NOT NULL DEFAULT '0',
  `load_fail_count` int(11) DEFAULT NULL,
  `p2p_fail_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`occ_date`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_assault`
--

LOCK TABLES `log_assault` WRITE;
/*!40000 ALTER TABLE `log_assault` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_assault` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_avatar_grind`
--

DROP TABLE IF EXISTS `log_avatar_grind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_avatar_grind` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `grade` enum('normal','high','rare') NOT NULL DEFAULT 'normal',
  `body_part` enum('headgear','hair','face','jacket','pants','shoes','breast','waist','skin') NOT NULL DEFAULT 'headgear',
  `avatar_emblem_grind` int(10) unsigned NOT NULL DEFAULT '0',
  `avatar_bindcube_grind` int(10) unsigned NOT NULL DEFAULT '0',
  `avatar_rechargestone_grind` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`grade`,`body_part`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_avatar_grind`
--

LOCK TABLES `log_avatar_grind` WRITE;
/*!40000 ALTER TABLE `log_avatar_grind` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_avatar_grind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_cerashop_gift`
--

DROP TABLE IF EXISTS `log_cerashop_gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cerashop_gift` (
  `idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `from_mid` int(10) unsigned NOT NULL DEFAULT '0',
  `from_charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `to_mid` int(10) unsigned NOT NULL DEFAULT '0',
  `to_charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_idx` int(10) unsigned NOT NULL DEFAULT '0',
  `item_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_cerashop_gift`
--

LOCK TABLES `log_cerashop_gift` WRITE;
/*!40000 ALTER TABLE `log_cerashop_gift` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_cerashop_gift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_charac_money`
--

DROP TABLE IF EXISTS `log_charac_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_charac_money` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `money_plus` int(10) unsigned NOT NULL DEFAULT '0',
  `money_minus` int(10) unsigned NOT NULL DEFAULT '0',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_charac_money`
--

LOCK TABLES `log_charac_money` WRITE;
/*!40000 ALTER TABLE `log_charac_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_charac_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_client_ting`
--

DROP TABLE IF EXISTS `log_client_ting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_client_ting` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `reason` int(11) NOT NULL DEFAULT '0',
  `cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`reason`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_client_ting`
--

LOCK TABLES `log_client_ting` WRITE;
/*!40000 ALTER TABLE `log_client_ting` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_client_ting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_client_ting_stat`
--

DROP TABLE IF EXISTS `log_client_ting_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_client_ting_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `reason` int(11) NOT NULL DEFAULT '0',
  `cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`reason`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_client_ting_stat`
--

LOCK TABLES `log_client_ting_stat` WRITE;
/*!40000 ALTER TABLE `log_client_ting_stat` DISABLE KEYS */;
INSERT INTO `log_client_ting_stat` VALUES ('2026-03-10 11:33:04',11,50,9);
/*!40000 ALTER TABLE `log_client_ting_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_cube_stat`
--

DROP TABLE IF EXISTS `log_cube_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cube_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `item_index` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `item_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`level`,`item_index`,`type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_cube_stat`
--

LOCK TABLES `log_cube_stat` WRITE;
/*!40000 ALTER TABLE `log_cube_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_cube_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_deathtower_playdata_job`
--

DROP TABLE IF EXISTS `log_deathtower_playdata_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deathtower_playdata_job` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_job` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_grow` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `playcount` int(10) unsigned NOT NULL DEFAULT '0',
  `avg_clear_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`type`,`charac_job`,`charac_grow`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_deathtower_playdata_job`
--

LOCK TABLES `log_deathtower_playdata_job` WRITE;
/*!40000 ALTER TABLE `log_deathtower_playdata_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_deathtower_playdata_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_deathtower_playdata_party`
--

DROP TABLE IF EXISTS `log_deathtower_playdata_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deathtower_playdata_party` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `party_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `playcount` int(10) unsigned NOT NULL DEFAULT '0',
  `avg_clear_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`type`,`party_count`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_deathtower_playdata_party`
--

LOCK TABLES `log_deathtower_playdata_party` WRITE;
/*!40000 ALTER TABLE `log_deathtower_playdata_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_deathtower_playdata_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_deathtower_value`
--

DROP TABLE IF EXISTS `log_deathtower_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deathtower_value` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `clear_stage` int(10) unsigned NOT NULL DEFAULT '0',
  `recipeCnt` int(10) unsigned NOT NULL DEFAULT '0',
  `rareCnt` int(10) unsigned NOT NULL DEFAULT '0',
  `uniqCnt` int(10) unsigned NOT NULL DEFAULT '0',
  `card_item_goldprice` int(10) unsigned NOT NULL DEFAULT '0',
  `card_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `repair_price` int(10) unsigned NOT NULL DEFAULT '0',
  `commonCnt` int(10) unsigned NOT NULL DEFAULT '0',
  `uncommonCnt` int(10) unsigned NOT NULL DEFAULT '0',
  `try_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`type`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_deathtower_value`
--

LOCK TABLES `log_deathtower_value` WRITE;
/*!40000 ALTER TABLE `log_deathtower_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_deathtower_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_charac`
--

DROP TABLE IF EXISTS `log_dungeon_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_charac` (
  `channel_no` int(11) NOT NULL DEFAULT '0' COMMENT '채널번호',
  `dungeon_index` int(11) NOT NULL DEFAULT '0' COMMENT '던전번호',
  `dungeon_diff` int(11) NOT NULL DEFAULT '0' COMMENT '던전난이도',
  `charac_job` int(11) NOT NULL DEFAULT '0' COMMENT '케릭직업',
  `charac_grow` int(11) NOT NULL DEFAULT '0' COMMENT '케릭성장직업',
  `clear_time` int(11) NOT NULL DEFAULT '0' COMMENT '클리어시간',
  `die_count` int(11) NOT NULL DEFAULT '0' COMMENT '죽은 횟수',
  `hp_consume` int(11) NOT NULL DEFAULT '0' COMMENT 'hp 소비량',
  `mp_consume` int(11) NOT NULL DEFAULT '0' COMMENT 'mp 소비량',
  `hit_count` int(11) NOT NULL DEFAULT '0' COMMENT '히트수',
  `hit_per_avg_damage` int(11) NOT NULL DEFAULT '0' COMMENT '평균 데미지',
  `hp_recovery` int(11) NOT NULL DEFAULT '0' COMMENT 'hp 회복량',
  `mp_recovery` int(11) NOT NULL DEFAULT '0' COMMENT 'mp 회복량',
  `success` int(11) NOT NULL DEFAULT '0' COMMENT '성공구분',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '등록일시',
  `update_count` int(11) NOT NULL DEFAULT '0' COMMENT '업데이트 횟수',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '레벨',
  `exp_avg` int(11) NOT NULL DEFAULT '0' COMMENT '경험치평균',
  `dungeon_standard_level` int(11) NOT NULL DEFAULT '0' COMMENT '던전표준레벨',
  `fatigue_consume` int(11) NOT NULL DEFAULT '0' COMMENT '소비된피로도',
  `exp_add` int(11) NOT NULL DEFAULT '0' COMMENT '경험치합계',
  `party_user_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`last_time`,`channel_no`,`dungeon_index`,`dungeon_diff`,`dungeon_standard_level`,`charac_job`,`charac_grow`,`success`,`party_user_count`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='케릭터별 던전 로그 정보 저장';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_charac`
--

LOCK TABLES `log_dungeon_charac` WRITE;
/*!40000 ALTER TABLE `log_dungeon_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_entrance`
--

DROP TABLE IF EXISTS `log_dungeon_entrance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_entrance` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `channel_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dungeon_index` smallint(5) unsigned NOT NULL DEFAULT '0',
  `enter_count` int(10) unsigned NOT NULL DEFAULT '0',
  `exercise_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`channel_no`,`dungeon_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_entrance`
--

LOCK TABLES `log_dungeon_entrance` WRITE;
/*!40000 ALTER TABLE `log_dungeon_entrance` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_entrance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_entrance_hour`
--

DROP TABLE IF EXISTS `log_dungeon_entrance_hour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_entrance_hour` (
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dungeon_index` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hour_enter_count` int(10) unsigned NOT NULL DEFAULT '0',
  `cnt_enter_count` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`channel_no`,`dungeon_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_entrance_hour`
--

LOCK TABLES `log_dungeon_entrance_hour` WRITE;
/*!40000 ALTER TABLE `log_dungeon_entrance_hour` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_entrance_hour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_exp`
--

DROP TABLE IF EXISTS `log_dungeon_exp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_exp` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `exp` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fatigue` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`lev`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_exp`
--

LOCK TABLES `log_dungeon_exp` WRITE;
/*!40000 ALTER TABLE `log_dungeon_exp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_exp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_monster`
--

DROP TABLE IF EXISTS `log_dungeon_monster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_monster` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `dungeon_diff` int(11) NOT NULL DEFAULT '0',
  `monster_index` int(11) NOT NULL DEFAULT '0',
  `damage_total` int(11) NOT NULL DEFAULT '0',
  `damage_count` int(11) NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`last_time`,`channel_no`,`dungeon_index`,`dungeon_diff`,`monster_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_monster`
--

LOCK TABLES `log_dungeon_monster` WRITE;
/*!40000 ALTER TABLE `log_dungeon_monster` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_monster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_party`
--

DROP TABLE IF EXISTS `log_dungeon_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_party` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `dungeon_diff` int(11) NOT NULL DEFAULT '0',
  `dungeon_standard_level` tinyint(4) NOT NULL DEFAULT '0',
  `abuse_party` tinyint(4) NOT NULL DEFAULT '0',
  `balkun_party` tinyint(4) NOT NULL DEFAULT '0',
  `party_user_count` int(11) NOT NULL DEFAULT '0',
  `clear_time` int(11) NOT NULL DEFAULT '0',
  `die_count` int(11) NOT NULL DEFAULT '0',
  `hp_consume` int(11) NOT NULL DEFAULT '0',
  `mp_consume` int(11) NOT NULL DEFAULT '0',
  `hit_count` int(11) NOT NULL DEFAULT '0',
  `hit_per_avg_damage` int(11) NOT NULL DEFAULT '0',
  `hp_recovery` int(11) NOT NULL DEFAULT '0',
  `mp_recovery` int(11) NOT NULL DEFAULT '0',
  `success` int(11) NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `update_count` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `fatigue_consume` int(11) NOT NULL DEFAULT '0',
  `exp_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`last_time`,`channel_no`,`dungeon_index`,`dungeon_diff`,`dungeon_standard_level`,`abuse_party`,`balkun_party`,`party_user_count`,`success`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_party`
--

LOCK TABLES `log_dungeon_party` WRITE;
/*!40000 ALTER TABLE `log_dungeon_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_party_job`
--

DROP TABLE IF EXISTS `log_dungeon_party_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_party_job` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `dungeon_diff` int(11) NOT NULL DEFAULT '0',
  `dungeon_standard_level` tinyint(4) NOT NULL DEFAULT '0',
  `abuse_party` tinyint(4) NOT NULL DEFAULT '0',
  `balkun_party` tinyint(4) NOT NULL DEFAULT '0',
  `charac_job` int(11) NOT NULL DEFAULT '0',
  `charac_grow` int(11) NOT NULL DEFAULT '0',
  `party_user_count` int(11) NOT NULL DEFAULT '0',
  `success` int(11) NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `job_count` int(11) NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`last_time`,`channel_no`,`dungeon_index`,`dungeon_diff`,`dungeon_standard_level`,`abuse_party`,`balkun_party`,`charac_job`,`charac_grow`,`party_user_count`,`success`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_party_job`
--

LOCK TABLES `log_dungeon_party_job` WRITE;
/*!40000 ALTER TABLE `log_dungeon_party_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_party_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dungeon_skill`
--

DROP TABLE IF EXISTS `log_dungeon_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_dungeon_skill` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `dungeon_index` int(11) NOT NULL DEFAULT '0',
  `dungeon_diff` int(11) NOT NULL DEFAULT '0',
  `charac_job` int(11) NOT NULL DEFAULT '0',
  `charac_grow` int(11) NOT NULL DEFAULT '0',
  `skill_index` int(11) NOT NULL DEFAULT '0',
  `skill_use` int(11) NOT NULL DEFAULT '0',
  `skill_count` int(11) NOT NULL DEFAULT '0',
  `skill_cool_time` int(11) NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`last_time`,`channel_no`,`dungeon_index`,`dungeon_diff`,`charac_job`,`charac_grow`,`skill_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dungeon_skill`
--

LOCK TABLES `log_dungeon_skill` WRITE;
/*!40000 ALTER TABLE `log_dungeon_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_dungeon_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_eco_point`
--

DROP TABLE IF EXISTS `log_eco_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_eco_point` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `save_time` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `add_point` int(10) unsigned NOT NULL DEFAULT '0',
  `use_point` int(10) unsigned NOT NULL DEFAULT '0',
  `save_type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`save_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_eco_point`
--

LOCK TABLES `log_eco_point` WRITE;
/*!40000 ALTER TABLE `log_eco_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_eco_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_emblem_compound`
--

DROP TABLE IF EXISTS `log_emblem_compound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_emblem_compound` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00' COMMENT '날짜',
  `channel_no` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '채널 번호',
  `grade0` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade1` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade2` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade3` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade4` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade5` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade6` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  PRIMARY KEY (`occ_date`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_emblem_compound`
--

LOCK TABLES `log_emblem_compound` WRITE;
/*!40000 ALTER TABLE `log_emblem_compound` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_emblem_compound` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_emblem_create`
--

DROP TABLE IF EXISTS `log_emblem_create`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_emblem_create` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00' COMMENT '날짜',
  `grade0` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade1` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade2` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade3` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade4` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade5` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  `grade6` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등급 별 카운트',
  PRIMARY KEY (`cur_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_emblem_create`
--

LOCK TABLES `log_emblem_create` WRITE;
/*!40000 ALTER TABLE `log_emblem_create` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_emblem_create` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_fatigue_daily`
--

DROP TABLE IF EXISTS `log_fatigue_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_fatigue_daily` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `fatigue` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_fatigue_daily`
--

LOCK TABLES `log_fatigue_daily` WRITE;
/*!40000 ALTER TABLE `log_fatigue_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_fatigue_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_game_channel`
--

DROP TABLE IF EXISTS `log_game_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_game_channel` (
  `gc_up_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gc_game` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gc_no` int(11) unsigned NOT NULL DEFAULT '0',
  `gc_channel` char(32) NOT NULL DEFAULT '',
  `gc_ch_group` smallint(5) NOT NULL DEFAULT '0',
  `gc_ip` char(64) NOT NULL DEFAULT '',
  `gc_new` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_now` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_out` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gc_up_time`,`gc_game`,`gc_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_game_channel`
--

LOCK TABLES `log_game_channel` WRITE;
/*!40000 ALTER TABLE `log_game_channel` DISABLE KEYS */;
INSERT INTO `log_game_channel` VALUES ('2026-02-28 14:45:14',3,3011,'ch.11',11,'192.168.200.131',0,0,0),('2026-03-10 11:12:23',3,3011,'ch.11',11,'192.168.200.131',0,0,0),('2026-03-10 11:22:23',3,3011,'ch.11',11,'192.168.200.131',0,0,0),('2026-03-10 11:32:23',3,3011,'ch.11',11,'192.168.200.131',0,0,0);
/*!40000 ALTER TABLE `log_game_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gameserver_load_stat`
--

DROP TABLE IF EXISTS `log_gameserver_load_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gameserver_load_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_no` int(10) unsigned NOT NULL DEFAULT '0',
  `dbq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `logdbq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `netq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `packetq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_id`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gameserver_load_stat`
--

LOCK TABLES `log_gameserver_load_stat` WRITE;
/*!40000 ALTER TABLE `log_gameserver_load_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gameserver_load_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gameserver_load_stat_del`
--

DROP TABLE IF EXISTS `log_gameserver_load_stat_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gameserver_load_stat_del` (
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_no` int(10) unsigned NOT NULL DEFAULT '0',
  `dbq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `logdbq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `netq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `packetq_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `idx1` (`sdate`,`occ_time`,`server_id`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gameserver_load_stat_del`
--

LOCK TABLES `log_gameserver_load_stat_del` WRITE;
/*!40000 ALTER TABLE `log_gameserver_load_stat_del` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gameserver_load_stat_del` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gold_stat`
--

DROP TABLE IF EXISTS `log_gold_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gold_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `dungeon_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `result_card` int(10) unsigned NOT NULL DEFAULT '0',
  `sell_store` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `death_tower_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `illusion_tower_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `war_area_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `member_tax` int(10) unsigned NOT NULL DEFAULT '0',
  `sell_auction` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_sell_auction` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_bidding_auction` int(10) unsigned NOT NULL DEFAULT '0',
  `buy_store` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina_recovery` int(10) unsigned NOT NULL DEFAULT '0',
  `repair_item` int(10) unsigned NOT NULL DEFAULT '0',
  `private_store_commission` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_card` int(10) unsigned NOT NULL DEFAULT '0',
  `auction_commission` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_use` int(10) unsigned NOT NULL DEFAULT '0',
  `mail_commission` int(10) unsigned NOT NULL DEFAULT '0',
  `punish_user` int(10) unsigned NOT NULL DEFAULT '0',
  `restrict_trade` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_level_up` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_skill` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_mail` int(10) unsigned NOT NULL DEFAULT '0',
  `item_compound` int(10) unsigned NOT NULL DEFAULT '0',
  `auction_bidding` int(10) unsigned NOT NULL DEFAULT '0',
  `war_area_enter` int(10) unsigned NOT NULL DEFAULT '0',
  `assault_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `blood_dungeon_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `power_dungeon_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `power_dungeon_result_card` int(10) unsigned NOT NULL DEFAULT '0',
  `blood_dungeon_enter` int(10) unsigned NOT NULL DEFAULT '0',
  `blood_dungeon_lotto` int(10) unsigned NOT NULL DEFAULT '0',
  `buy_cerashop` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade_guild_agit` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade_guild_cargo` int(10) unsigned NOT NULL DEFAULT '0',
  `break_away_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `link_charac_bonus` int(10) unsigned NOT NULL DEFAULT '0',
  `ultimate_dungeon_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_fund` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_fund_dungeon` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_shop_init_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `unseal` int(10) unsigned NOT NULL DEFAULT '0',
  `lottery` int(10) unsigned NOT NULL DEFAULT '0',
  `amplify` int(10) unsigned NOT NULL DEFAULT '0',
  `roi_regen` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gold_stat`
--

LOCK TABLES `log_gold_stat` WRITE;
/*!40000 ALTER TABLE `log_gold_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gold_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_hardware_ting`
--

DROP TABLE IF EXISTS `log_hardware_ting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_hardware_ting` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `category2` int(11) NOT NULL DEFAULT '0',
  `category3` int(11) NOT NULL DEFAULT '0',
  `total` int(10) unsigned NOT NULL DEFAULT '0',
  `ting` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`category1`,`category2`,`category3`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_hardware_ting`
--

LOCK TABLES `log_hardware_ting` WRITE;
/*!40000 ALTER TABLE `log_hardware_ting` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_hardware_ting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_develop`
--

DROP TABLE IF EXISTS `log_item_develop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_develop` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `it_no` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `develop` smallint(6) NOT NULL DEFAULT '0',
  `sucess_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`it_no`) USING BTREE,
  KEY `idx_it_no` (`it_no`) USING BTREE,
  KEY `idx_server_id` (`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_develop`
--

LOCK TABLES `log_item_develop` WRITE;
/*!40000 ALTER TABLE `log_item_develop` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_develop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_drop`
--

DROP TABLE IF EXISTS `log_item_drop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_drop` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `channel_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `drop_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackable_common` int(10) unsigned NOT NULL DEFAULT '0',
  `stackable_uncommon` int(10) unsigned NOT NULL DEFAULT '0',
  `stackable_rare` int(10) unsigned NOT NULL DEFAULT '0',
  `stackable_unique` int(10) unsigned NOT NULL DEFAULT '0',
  `stackable_epic` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_common` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_uncommon` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_rare` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_unique` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_epic` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_common` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_uncommon` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_rare` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_unique` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_epic` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_common` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_uncommon` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_rare` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_unique` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_epic` int(10) unsigned NOT NULL DEFAULT '0',
  `equip_chronicle` int(10) unsigned NOT NULL DEFAULT '0',
  `recipe_chronicle` int(10) unsigned NOT NULL DEFAULT '0',
  `artifact_chronicle` int(10) unsigned NOT NULL DEFAULT '0',
  `Stackable_chronicle` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`channel_no`,`drop_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_drop`
--

LOCK TABLES `log_item_drop` WRITE;
/*!40000 ALTER TABLE `log_item_drop` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_drop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_stat`
--

DROP TABLE IF EXISTS `log_item_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_stat` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_stat`
--

LOCK TABLES `log_item_stat` WRITE;
/*!40000 ALTER TABLE `log_item_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_stat_multiproc`
--

DROP TABLE IF EXISTS `log_item_stat_multiproc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_stat_multiproc` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_stat_multiproc`
--

LOCK TABLES `log_item_stat_multiproc` WRITE;
/*!40000 ALTER TABLE `log_item_stat_multiproc` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_stat_multiproc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_stat_multiproc_fix`
--

DROP TABLE IF EXISTS `log_item_stat_multiproc_fix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_stat_multiproc_fix` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_stat_multiproc_fix`
--

LOCK TABLES `log_item_stat_multiproc_fix` WRITE;
/*!40000 ALTER TABLE `log_item_stat_multiproc_fix` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_stat_multiproc_fix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_stat_single`
--

DROP TABLE IF EXISTS `log_item_stat_single`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_stat_single` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_stat_single`
--

LOCK TABLES `log_item_stat_single` WRITE;
/*!40000 ALTER TABLE `log_item_stat_single` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_stat_single` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_upgrade`
--

DROP TABLE IF EXISTS `log_item_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_upgrade` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `upgrade` int(11) NOT NULL DEFAULT '0',
  `amplify_item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rarity` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_upgrade`
--

LOCK TABLES `log_item_upgrade` WRITE;
/*!40000 ALTER TABLE `log_item_upgrade` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_upgrade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_upgrade_multiproc`
--

DROP TABLE IF EXISTS `log_item_upgrade_multiproc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_upgrade_multiproc` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `process_id` tinyint(4) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `upgrade` int(11) NOT NULL DEFAULT '0',
  `amplify_item_cnt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rarity` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`process_id`,`item_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_upgrade_multiproc`
--

LOCK TABLES `log_item_upgrade_multiproc` WRITE;
/*!40000 ALTER TABLE `log_item_upgrade_multiproc` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_item_upgrade_multiproc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_job_gold`
--

DROP TABLE IF EXISTS `log_job_gold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_job_gold` (
  `cur_date` date NOT NULL DEFAULT '0000-00-00',
  `server_info` tinyint(4) NOT NULL DEFAULT '0',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `gold_average` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_max` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_sum` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cur_date`,`server_info`,`job`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_job_gold`
--

LOCK TABLES `log_job_gold` WRITE;
/*!40000 ALTER TABLE `log_job_gold` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_job_gold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_level_dungeon_play_count`
--

DROP TABLE IF EXISTS `log_level_dungeon_play_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_level_dungeon_play_count` (
  `level` smallint(6) NOT NULL DEFAULT '0',
  `total_charac_count` int(10) unsigned NOT NULL DEFAULT '0',
  `total_dungeon_play_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_level_dungeon_play_count`
--

LOCK TABLES `log_level_dungeon_play_count` WRITE;
/*!40000 ALTER TABLE `log_level_dungeon_play_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_level_dungeon_play_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_login_logout`
--

DROP TABLE IF EXISTS `log_login_logout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_login_logout` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`event_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_login_logout`
--

LOCK TABLES `log_login_logout` WRITE;
/*!40000 ALTER TABLE `log_login_logout` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_login_logout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_lucky_ticket_stat`
--

DROP TABLE IF EXISTS `log_lucky_ticket_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_lucky_ticket_stat` (
  `idx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `type_flag` tinyint(4) NOT NULL DEFAULT '0',
  `ticket_flag` tinyint(4) NOT NULL DEFAULT '0',
  `item_idx` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `succ_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_lucky_ticket_stat`
--

LOCK TABLES `log_lucky_ticket_stat` WRITE;
/*!40000 ALTER TABLE `log_lucky_ticket_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_lucky_ticket_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_mercenary`
--

DROP TABLE IF EXISTS `log_mercenary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_mercenary` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `finish_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `period` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gold` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `rarity` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_mercenary`
--

LOCK TABLES `log_mercenary` WRITE;
/*!40000 ALTER TABLE `log_mercenary` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_mercenary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_monstertower_layer_stat`
--

DROP TABLE IF EXISTS `log_monstertower_layer_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_monstertower_layer_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `key_id` int(11) unsigned NOT NULL DEFAULT '0',
  `layer` smallint(5) unsigned NOT NULL DEFAULT '0',
  `monster_diff` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `charac_job` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `charac_grow` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `play_cnt` int(11) unsigned NOT NULL DEFAULT '0',
  `success_cnt` int(11) unsigned NOT NULL DEFAULT '0',
  `play_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uniq_cnt` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`key_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_monstertower_layer_stat`
--

LOCK TABLES `log_monstertower_layer_stat` WRITE;
/*!40000 ALTER TABLE `log_monstertower_layer_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_monstertower_layer_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_nat_daily`
--

DROP TABLE IF EXISTS `log_nat_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_nat_daily` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `nat_type_other` tinyint(4) NOT NULL DEFAULT '0',
  `success_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`nat_type`,`nat_type_other`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_nat_daily`
--

LOCK TABLES `log_nat_daily` WRITE;
/*!40000 ALTER TABLE `log_nat_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_nat_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_nat_stat`
--

DROP TABLE IF EXISTS `log_nat_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_nat_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nat_type` tinyint(4) NOT NULL DEFAULT '0',
  `nat_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`nat_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_nat_stat`
--

LOCK TABLES `log_nat_stat` WRITE;
/*!40000 ALTER TABLE `log_nat_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_nat_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_num_occupations`
--

DROP TABLE IF EXISTS `log_num_occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_num_occupations` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_occupations_charscreen` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_occupations_seriaroom` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_login_per_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_logout_per_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_num_occupations`
--

LOCK TABLES `log_num_occupations` WRITE;
/*!40000 ALTER TABLE `log_num_occupations` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_num_occupations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_ontime_reward`
--

DROP TABLE IF EXISTS `log_ontime_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_ontime_reward` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `event_no` int(10) unsigned NOT NULL DEFAULT '0',
  `reward_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`time`,`event_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_ontime_reward`
--

LOCK TABLES `log_ontime_reward` WRITE;
/*!40000 ALTER TABLE `log_ontime_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_ontime_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_otherserver_load_stat`
--

DROP TABLE IF EXISTS `log_otherserver_load_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_otherserver_load_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `kind` tinyint(4) NOT NULL DEFAULT '0',
  `q_cnt` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`server_type`,`kind`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_otherserver_load_stat`
--

LOCK TABLES `log_otherserver_load_stat` WRITE;
/*!40000 ALTER TABLE `log_otherserver_load_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_otherserver_load_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_packet_dispatcher_error_line`
--

DROP TABLE IF EXISTS `log_packet_dispatcher_error_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_packet_dispatcher_error_line` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `channel_no` tinyint(4) NOT NULL DEFAULT '0',
  `error_line` int(10) unsigned NOT NULL DEFAULT '0',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`channel_no`,`error_line`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_packet_dispatcher_error_line`
--

LOCK TABLES `log_packet_dispatcher_error_line` WRITE;
/*!40000 ALTER TABLE `log_packet_dispatcher_error_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_packet_dispatcher_error_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_party_type`
--

DROP TABLE IF EXISTS `log_party_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_party_type` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `guild_count` int(11) NOT NULL DEFAULT '0',
  `member_count` int(11) NOT NULL DEFAULT '0',
  `helped_count` int(11) NOT NULL DEFAULT '0',
  `normal_count` int(11) NOT NULL DEFAULT '0',
  `member_helped_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_no`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_party_type`
--

LOCK TABLES `log_party_type` WRITE;
/*!40000 ALTER TABLE `log_party_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_party_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_playtime`
--

DROP TABLE IF EXISTS `log_playtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_playtime` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `play_time` int(11) NOT NULL DEFAULT '0',
  `lobby_intime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lobby_outtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `idx_lobby_outtime` (`lobby_outtime`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_playtime`
--

LOCK TABLES `log_playtime` WRITE;
/*!40000 ALTER TABLE `log_playtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_playtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_police_chatting`
--

DROP TABLE IF EXISTS `log_police_chatting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_police_chatting` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_type` tinyint(4) NOT NULL DEFAULT '0',
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `message` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_police_chatting`
--

LOCK TABLES `log_police_chatting` WRITE;
/*!40000 ALTER TABLE `log_police_chatting` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_police_chatting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pvp_map`
--

DROP TABLE IF EXISTS `log_pvp_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_pvp_map` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `map_id` int(11) NOT NULL DEFAULT '0',
  `play_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_no`,`map_id`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pvp_map`
--

LOCK TABLES `log_pvp_map` WRITE;
/*!40000 ALTER TABLE `log_pvp_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_pvp_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pvp_player_rate`
--

DROP TABLE IF EXISTS `log_pvp_player_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_pvp_player_rate` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `single_one_to_one` int(11) NOT NULL DEFAULT '0',
  `single_one_to_one_other` int(11) NOT NULL DEFAULT '0',
  `team_one_to_one` int(11) NOT NULL DEFAULT '0',
  `team_one_to_one_other` int(11) NOT NULL DEFAULT '0',
  `relay_one_to_one` int(11) NOT NULL DEFAULT '0',
  `relay_one_to_one_other` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_no`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pvp_player_rate`
--

LOCK TABLES `log_pvp_player_rate` WRITE;
/*!40000 ALTER TABLE `log_pvp_player_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_pvp_player_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_query_stat`
--

DROP TABLE IF EXISTS `log_query_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_query_stat` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `q_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_no` int(10) unsigned NOT NULL DEFAULT '0',
  `total` int(10) unsigned NOT NULL DEFAULT '0',
  `response_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`,`q_id`,`gc_no`) USING BTREE,
  KEY `idx_q_id` (`q_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_query_stat`
--

LOCK TABLES `log_query_stat` WRITE;
/*!40000 ALTER TABLE `log_query_stat` DISABLE KEYS */;
INSERT INTO `log_query_stat` VALUES ('2026-01-30 09:47:45',2,11,16,1),('2026-01-30 09:47:45',4,11,1,0),('2026-02-28 14:35:56',19,11,2,11),('2026-02-28 14:35:56',31,11,1,4),('2026-02-28 14:35:56',1,11,1,9),('2026-02-28 14:35:56',3,11,1,1),('2026-02-28 14:35:56',4,11,2,0),('2026-02-28 14:35:56',5,11,1,21),('2026-02-28 14:35:56',6,11,1,3),('2026-02-28 14:35:56',7,11,1,1),('2026-02-28 14:35:56',8,11,1,0),('2026-02-28 14:35:56',9,11,1,0),('2026-02-28 14:35:56',10,11,1,0),('2026-02-28 14:35:56',11,11,1,0),('2026-02-28 14:35:56',12,11,1,2),('2026-02-28 14:35:56',13,11,1,12),('2026-02-28 14:35:56',14,11,1,2),('2026-02-28 14:35:56',15,11,1,3),('2026-02-28 14:35:56',16,11,1,3),('2026-02-28 14:35:56',17,11,1,3),('2026-02-28 14:35:56',18,11,1,0),('2026-02-28 15:07:37',19,11,2,1),('2026-02-28 15:07:37',31,11,1,1),('2026-02-28 15:07:37',1,11,1,8),('2026-02-28 15:07:37',3,11,1,0),('2026-02-28 15:07:37',4,11,2,8),('2026-02-28 15:07:37',5,11,1,2),('2026-02-28 15:07:37',6,11,1,1),('2026-02-28 15:07:37',7,11,1,1),('2026-02-28 15:07:37',8,11,1,0),('2026-02-28 15:07:37',9,11,1,0),('2026-02-28 15:07:37',10,11,1,0),('2026-02-28 15:07:37',11,11,1,0),('2026-02-28 15:07:37',12,11,1,1),('2026-02-28 15:07:37',13,11,1,1),('2026-02-28 15:07:37',14,11,1,0),('2026-02-28 15:07:37',15,11,1,1),('2026-02-28 15:07:37',16,11,1,0),('2026-02-28 15:07:37',17,11,1,0),('2026-02-28 15:07:37',18,11,1,0),('2026-03-10 11:03:04',19,11,2,2),('2026-03-10 11:03:04',31,11,1,3),('2026-03-10 11:03:04',1,11,1,8),('2026-03-10 11:03:04',3,11,1,0),('2026-03-10 11:03:04',4,11,2,9),('2026-03-10 11:03:04',5,11,1,17),('2026-03-10 11:03:04',6,11,1,4),('2026-03-10 11:03:04',7,11,1,4),('2026-03-10 11:03:04',8,11,1,2),('2026-03-10 11:03:04',9,11,1,10),('2026-03-10 11:03:04',10,11,1,10),('2026-03-10 11:03:04',11,11,1,8),('2026-03-10 11:03:04',12,11,1,3),('2026-03-10 11:03:04',13,11,1,3),('2026-03-10 11:03:04',14,11,1,4),('2026-03-10 11:03:04',15,11,1,2),('2026-03-10 11:03:04',16,11,1,1),('2026-03-10 11:03:04',17,11,1,2),('2026-03-10 11:03:04',18,11,1,0),('2026-03-10 11:32:10',20096,0,1,10),('2026-03-10 11:32:10',20204,0,30,0),('2026-03-10 11:32:10',20105,0,30,25),('2026-03-10 11:32:10',20244,0,1,8),('2026-03-10 11:32:10',20300,0,15,30),('2026-03-10 11:32:10',20262,0,29,44),('2026-03-10 11:33:04',19,11,4,2),('2026-03-10 11:33:04',24,11,2,2),('2026-03-10 11:33:04',31,11,19,3),('2026-03-10 11:33:04',36,11,3,38),('2026-03-10 11:33:04',20,11,1,2),('2026-03-10 11:33:04',21,11,1,2),('2026-03-10 11:33:04',22,11,20,7),('2026-03-10 11:33:04',23,11,20,3),('2026-03-10 11:33:04',25,11,20,3),('2026-03-10 11:33:04',26,11,1,1),('2026-03-10 11:33:04',27,11,1,2),('2026-03-10 11:33:04',28,11,1,1),('2026-03-10 11:33:04',29,11,34,2),('2026-03-10 11:33:04',30,11,34,5),('2026-03-10 11:33:04',32,11,1,2),('2026-03-10 11:33:04',33,11,1,0),('2026-03-10 11:33:04',34,11,59,74),('2026-03-10 11:33:04',35,11,1,1);
/*!40000 ALTER TABLE `log_query_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_query_stat_del`
--

DROP TABLE IF EXISTS `log_query_stat_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_query_stat_del` (
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `q_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_no` int(10) unsigned NOT NULL DEFAULT '0',
  `total` int(10) unsigned NOT NULL DEFAULT '0',
  `response_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`sdate`,`occ_time`,`q_id`) USING BTREE,
  KEY `idx_q_id` (`q_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_query_stat_del`
--

LOCK TABLES `log_query_stat_del` WRITE;
/*!40000 ALTER TABLE `log_query_stat_del` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_query_stat_del` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_random_option`
--

DROP TABLE IF EXISTS `log_random_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_random_option` (
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `unseal_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `unseal_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `regen_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `regen_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `change_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `change_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pick_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `reset_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`level`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_random_option`
--

LOCK TABLES `log_random_option` WRITE;
/*!40000 ALTER TABLE `log_random_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_random_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_secret_shop`
--

DROP TABLE IF EXISTS `log_secret_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_secret_shop` (
  `npc_idx` tinyint(4) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `dungeon_idx` int(11) NOT NULL DEFAULT '0',
  `show_count` int(10) unsigned NOT NULL DEFAULT '0',
  `show_charac_count` int(10) unsigned NOT NULL DEFAULT '0',
  `buy_count` int(10) unsigned NOT NULL DEFAULT '0',
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`npc_idx`,`occ_date`,`dungeon_idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_secret_shop`
--

LOCK TABLES `log_secret_shop` WRITE;
/*!40000 ALTER TABLE `log_secret_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_secret_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_server_optimize_stat`
--

DROP TABLE IF EXISTS `log_server_optimize_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_server_optimize_stat` (
  `channel_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_count` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_less_5` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_less_10` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_less_30` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_less_50` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_less_100` int(10) unsigned NOT NULL DEFAULT '0',
  `sp_more_100` int(10) unsigned NOT NULL DEFAULT '0',
  `result` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_no`,`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_server_optimize_stat`
--

LOCK TABLES `log_server_optimize_stat` WRITE;
/*!40000 ALTER TABLE `log_server_optimize_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_server_optimize_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_tower_despair_uv_stat`
--

DROP TABLE IF EXISTS `log_tower_despair_uv_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_tower_despair_uv_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `server_id` tinyint(3) NOT NULL DEFAULT '0',
  `uv` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_tower_despair_uv_stat`
--

LOCK TABLES `log_tower_despair_uv_stat` WRITE;
/*!40000 ALTER TABLE `log_tower_despair_uv_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_tower_despair_uv_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_upgrade_pot`
--

DROP TABLE IF EXISTS `log_upgrade_pot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_upgrade_pot` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `id_2670203` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670204` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670205` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670206` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670241` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670242` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670243` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670244` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670245` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670246` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670247` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670248` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670249` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670250` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670251` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670252` int(10) unsigned NOT NULL DEFAULT '0',
  `id_2670253` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_upgrade_pot`
--

LOCK TABLES `log_upgrade_pot` WRITE;
/*!40000 ALTER TABLE `log_upgrade_pot` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_upgrade_pot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_value_stat`
--

DROP TABLE IF EXISTS `log_value_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_value_stat` (
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `level` int(11) NOT NULL DEFAULT '0',
  `uv` int(10) unsigned NOT NULL DEFAULT '0',
  `drop_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `drop_item` int(10) unsigned NOT NULL DEFAULT '0',
  `result_card_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `result_card_item` int(10) unsigned NOT NULL DEFAULT '0',
  `store_item_buy` int(10) unsigned NOT NULL DEFAULT '0',
  `jar_item` int(10) unsigned NOT NULL DEFAULT '0',
  `disjoint_create` int(10) unsigned NOT NULL DEFAULT '0',
  `upgrade_faild_forced_disjoint` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_reward` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_store_item_buy` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_upgrade_attempt` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_upgrade_faild` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_stamina_recovery` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_quest_consume` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_auction_commision` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_item_disjoint` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_item_repair` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_item_use` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_item_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_gold_drop` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_card_item` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_gold_card_price` int(10) unsigned NOT NULL DEFAULT '0',
  `deathtower_card_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `deathtower_card_item` int(10) unsigned NOT NULL DEFAULT '0',
  `consume_qp_init` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_no`,`occ_time`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_value_stat`
--

LOCK TABLES `log_value_stat` WRITE;
/*!40000 ALTER TABLE `log_value_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_value_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_war_stat`
--

DROP TABLE IF EXISTS `log_war_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_war_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `channel_no` int(11) NOT NULL DEFAULT '0',
  `war_zone_cnt` int(11) NOT NULL DEFAULT '0',
  `peace_zone_cnt` int(11) NOT NULL DEFAULT '0',
  `rare_item_cnt` int(11) NOT NULL DEFAULT '0',
  `unique_item_cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`channel_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_war_stat`
--

LOCK TABLES `log_war_stat` WRITE;
/*!40000 ALTER TABLE `log_war_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_war_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_account`
--

DROP TABLE IF EXISTS `login_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_account` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_channel_no` int(11) NOT NULL DEFAULT '0',
  `login_status` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_account`
--

LOCK TABLES `login_account` WRITE;
/*!40000 ALTER TABLE `login_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_view_log`
--

DROP TABLE IF EXISTS `login_view_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_view_log` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`occ_time`,`m_id`) USING BTREE,
  KEY `idx_charac_m_id` (`charac_m_id`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_view_log`
--

LOCK TABLES `login_view_log` WRITE;
/*!40000 ALTER TABLE `login_view_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_view_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mage_grow_log`
--

DROP TABLE IF EXISTS `mage_grow_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mage_grow_log` (
  `grow_type1` int(11) NOT NULL DEFAULT '0',
  `grow_type2` int(11) NOT NULL DEFAULT '0',
  `grow_type3` int(11) NOT NULL DEFAULT '0',
  `grow_type4` int(11) NOT NULL DEFAULT '0',
  `grow_type5` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mage_grow_log`
--

LOCK TABLES `mage_grow_log` WRITE;
/*!40000 ALTER TABLE `mage_grow_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mage_grow_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_environment`
--

DROP TABLE IF EXISTS `member_environment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_environment` (
  `os_type` int(11) NOT NULL DEFAULT '0',
  `hard_wholesize` int(10) unsigned NOT NULL DEFAULT '0',
  `hard_remainsize` int(10) unsigned NOT NULL DEFAULT '0',
  `memory_wholesize` int(10) unsigned NOT NULL DEFAULT '0',
  `memory_remainsize` int(10) unsigned NOT NULL DEFAULT '0',
  `virtualmem_wholesize` int(10) unsigned NOT NULL DEFAULT '0',
  `virtualmem_remainsize` int(10) unsigned NOT NULL DEFAULT '0',
  `cpu_speed` int(11) NOT NULL DEFAULT '0',
  `cpu_count` int(11) NOT NULL DEFAULT '0',
  `cpu_vendor` varchar(20) NOT NULL DEFAULT '',
  `graphic_name` varchar(128) NOT NULL DEFAULT '',
  `graphic_memory` int(10) unsigned NOT NULL DEFAULT '0',
  `average_fps` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_date` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_environment`
--

LOCK TABLES `member_environment` WRITE;
/*!40000 ALTER TABLE `member_environment` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_environment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_environment_entry`
--

DROP TABLE IF EXISTS `member_environment_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_environment_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_environment_entry`
--

LOCK TABLES `member_environment_entry` WRITE;
/*!40000 ALTER TABLE `member_environment_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_environment_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvp_status`
--

DROP TABLE IF EXISTS `pvp_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvp_status` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `room_number` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `no_participants` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`room_number`,`play_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvp_status`
--

LOCK TABLES `pvp_status` WRITE;
/*!40000 ALTER TABLE `pvp_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvp_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `re_stamina_shusia`
--

DROP TABLE IF EXISTS `re_stamina_shusia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `re_stamina_shusia` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `lev` tinyint(4) NOT NULL DEFAULT '0',
  `occ_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`lev`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `re_stamina_shusia`
--

LOCK TABLES `re_stamina_shusia` WRITE;
/*!40000 ALTER TABLE `re_stamina_shusia` DISABLE KEYS */;
/*!40000 ALTER TABLE `re_stamina_shusia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reliable_member_log`
--

DROP TABLE IF EXISTS `reliable_member_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reliable_member_log` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`occ_date`,`m_id`,`ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reliable_member_log`
--

LOCK TABLES `reliable_member_log` WRITE;
/*!40000 ALTER TABLE `reliable_member_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `reliable_member_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trade_gold_daily`
--

DROP TABLE IF EXISTS `trade_gold_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trade_gold_daily` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `gold` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_gold_daily`
--

LOCK TABLES `trade_gold_daily` WRITE;
/*!40000 ALTER TABLE `trade_gold_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `trade_gold_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trade_gold_rank`
--

DROP TABLE IF EXISTS `trade_gold_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trade_gold_rank` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `gold` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`m_id`) USING BTREE,
  KEY `idx_gold` (`gold`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_gold_rank`
--

LOCK TABLES `trade_gold_rank` WRITE;
/*!40000 ALTER TABLE `trade_gold_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `trade_gold_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
