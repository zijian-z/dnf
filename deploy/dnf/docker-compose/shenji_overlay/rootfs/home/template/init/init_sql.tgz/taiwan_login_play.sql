-- generated from VMDK full dump
-- source_db=taiwan_login_play

--



--
-- Table structure for table `member_key_option`
--

DROP TABLE IF EXISTS `member_key_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_key_option` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `key_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `key_option` blob NOT NULL,
  PRIMARY KEY (`m_id`,`key_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_key_option`
--

LOCK TABLES `member_key_option` WRITE;
/*!40000 ALTER TABLE `member_key_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_key_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'taiwan_login_play'
--

--
-- Dumping routines for database 'taiwan_login_play'
--

--
