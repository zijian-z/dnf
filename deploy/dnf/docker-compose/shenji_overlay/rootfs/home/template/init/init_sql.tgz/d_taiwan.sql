-- generated from VMDK full dump
-- source_db=d_taiwan

--



--
-- Table structure for table `account_cerashop_restrict`
--

DROP TABLE IF EXISTS `account_cerashop_restrict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_cerashop_restrict` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ipg_no` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  `next_date` int(10) unsigned NOT NULL DEFAULT '0',
  `end_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_access_date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`ipg_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_cerashop_restrict`
--

LOCK TABLES `account_cerashop_restrict` WRITE;
/*!40000 ALTER TABLE `account_cerashop_restrict` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_cerashop_restrict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `accountname` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `qq` varchar(128) DEFAULT NULL,
  `VIP` int(1) unsigned zerofill NOT NULL,
  PRIMARY KEY (`UID`) USING BTREE,
  UNIQUE KEY `accountname` (`accountname`)
) ENGINE=MyISAM AUTO_INCREMENT=18000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_member`
--

DROP TABLE IF EXISTS `admin_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_member` (
  `no` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `msn` varchar(50) DEFAULT NULL,
  `comment` text,
  `reg_date` int(13) DEFAULT NULL,
  `confirm` char(1) DEFAULT '0',
  `level` varchar(2000) NOT NULL DEFAULT '',
  `level_group1` varchar(2) NOT NULL DEFAULT '_',
  `level_group2` varchar(2) NOT NULL DEFAULT '_',
  `level_group3` varchar(2) NOT NULL DEFAULT '_',
  `level_group4` varchar(2) NOT NULL DEFAULT '_',
  `level_group5` varchar(2) NOT NULL DEFAULT '_',
  `level_group6` varchar(2) NOT NULL DEFAULT '_',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `password` (`password`) USING BTREE,
  KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_member`
--

LOCK TABLES `admin_member` WRITE;
/*!40000 ALTER TABLE `admin_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bad_user`
--

DROP TABLE IF EXISTS `bad_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bad_user` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL DEFAULT '0',
  `bad_code` int(11) NOT NULL DEFAULT '0',
  `create_day` int(11) NOT NULL DEFAULT '0',
  `exit_day` int(11) NOT NULL DEFAULT '0',
  `admin_n` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_mid` (`m_id`) USING BTREE,
  KEY `idx_code` (`bad_code`) USING BTREE,
  KEY `idx_eday` (`exit_day`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bad_user`
--

LOCK TABLES `bad_user` WRITE;
/*!40000 ALTER TABLE `bad_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `bad_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bak_dnf_item_info`
--

DROP TABLE IF EXISTS `bak_dnf_item_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bak_dnf_item_info` (
  `it_no` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `it_name` varchar(25) NOT NULL DEFAULT '',
  `it_eng_name` varchar(50) NOT NULL DEFAULT '',
  `it_explain` varchar(60) NOT NULL DEFAULT '',
  `master_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `job` varchar(12) NOT NULL DEFAULT '',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `revert` varchar(5) NOT NULL DEFAULT '',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `skill` smallint(5) unsigned NOT NULL DEFAULT '0',
  `create_ratio` float NOT NULL DEFAULT '0',
  `rarity` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `price` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cash` smallint(5) unsigned NOT NULL DEFAULT '0',
  `medal` smallint(5) unsigned NOT NULL DEFAULT '0',
  `durability` smallint(6) NOT NULL DEFAULT '0',
  `cooltime` smallint(6) NOT NULL DEFAULT '0',
  `hp_max` smallint(6) NOT NULL DEFAULT '0',
  `mp_max` smallint(6) NOT NULL DEFAULT '0',
  `phy_att` smallint(6) NOT NULL DEFAULT '0',
  `phy_def` smallint(6) NOT NULL DEFAULT '0',
  `mag_att` smallint(6) NOT NULL DEFAULT '0',
  `mag_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_def` smallint(6) NOT NULL DEFAULT '0',
  `ref_fire` tinyint(4) NOT NULL DEFAULT '0',
  `ref_water` tinyint(4) NOT NULL DEFAULT '0',
  `ref_dark` tinyint(4) NOT NULL DEFAULT '0',
  `ref_light` tinyint(4) NOT NULL DEFAULT '0',
  `ref_all` tinyint(4) NOT NULL DEFAULT '0',
  `ref_slow` tinyint(4) NOT NULL DEFAULT '0',
  `ref_freeze` tinyint(4) NOT NULL DEFAULT '0',
  `ref_poison` tinyint(4) NOT NULL DEFAULT '0',
  `ref_stun` tinyint(4) NOT NULL DEFAULT '0',
  `ref_cus` tinyint(4) NOT NULL DEFAULT '0',
  `ref_blind` tinyint(4) NOT NULL DEFAULT '0',
  `ref_lite` tinyint(4) NOT NULL DEFAULT '0',
  `ref_ston` tinyint(4) NOT NULL DEFAULT '0',
  `ref_sleep` tinyint(4) NOT NULL DEFAULT '0',
  `ref_deekement` tinyint(4) NOT NULL DEFAULT '0',
  `ref_deadlystrike` tinyint(4) NOT NULL DEFAULT '0',
  `ref_bleeding` tinyint(4) NOT NULL DEFAULT '0',
  `ref_confuse` tinyint(4) NOT NULL DEFAULT '0',
  `ref_hold` tinyint(4) NOT NULL DEFAULT '0',
  `ref_all_stat` tinyint(4) NOT NULL DEFAULT '0',
  `ref_pierce` smallint(6) NOT NULL DEFAULT '0',
  `ref_stuck` smallint(6) NOT NULL DEFAULT '0',
  `inven_max` smallint(6) NOT NULL DEFAULT '0',
  `hp_regenrate` smallint(6) NOT NULL DEFAULT '0',
  `mp_regenrate` smallint(6) NOT NULL DEFAULT '0',
  `mov_speed` smallint(6) NOT NULL DEFAULT '0',
  `att_speed` smallint(6) NOT NULL DEFAULT '0',
  `quest` smallint(6) NOT NULL DEFAULT '0',
  `hit_recovery` smallint(6) NOT NULL DEFAULT '0',
  `jump` smallint(6) NOT NULL DEFAULT '0',
  `att_element` enum('Void','Fire','Water','Dark','Light') NOT NULL DEFAULT 'Void',
  `att_active_status` smallint(6) NOT NULL DEFAULT '0',
  `att_active_status_ratio` float NOT NULL DEFAULT '0',
  `att_active_status_pow` smallint(6) NOT NULL DEFAULT '0',
  `att_backforce` smallint(6) NOT NULL DEFAULT '0',
  `att_upforce` smallint(6) NOT NULL DEFAULT '0',
  `att_hp_drain` tinyint(4) NOT NULL DEFAULT '0',
  `att_mp_drain` tinyint(4) NOT NULL DEFAULT '0',
  `criticalhit_rate` float NOT NULL DEFAULT '0',
  `stuck_rate` float NOT NULL DEFAULT '0',
  `att_defenseIgnore` tinyint(4) NOT NULL DEFAULT '0',
  `skill_levelup` varchar(25) NOT NULL DEFAULT '',
  `set_type` enum('n','y') NOT NULL DEFAULT 'n',
  `url` varchar(64) NOT NULL DEFAULT '',
  `jewel_type` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`it_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bak_dnf_item_info`
--

LOCK TABLES `bak_dnf_item_info` WRITE;
/*!40000 ALTER TABLE `bak_dnf_item_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `bak_dnf_item_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ch_status`
--

DROP TABLE IF EXISTS `ch_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ch_status` (
  `gc_group` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `gc_status` tinyint(3) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ch_status`
--

LOCK TABLES `ch_status` WRITE;
/*!40000 ALTER TABLE `ch_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `ch_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_pick_up_random_option_item`
--

DROP TABLE IF EXISTS `check_pick_up_random_option_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_pick_up_random_option_item` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `check_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_pick_up_random_option_item`
--

LOCK TABLES `check_pick_up_random_option_item` WRITE;
/*!40000 ALTER TABLE `check_pick_up_random_option_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_pick_up_random_option_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_connect`
--

DROP TABLE IF EXISTS `db_connect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_connect` (
  `no` int(10) unsigned NOT NULL DEFAULT '0',
  `host_name` varchar(50) DEFAULT NULL,
  `db_server_group` tinyint(3) unsigned DEFAULT NULL,
  `db_type` int(10) unsigned NOT NULL,
  `db_name` varchar(50) NOT NULL,
  `db_ip` varchar(16) NOT NULL,
  `db_port` int(10) unsigned NOT NULL,
  `db_userid` varchar(20) NOT NULL,
  `db_passwd` varchar(50) NOT NULL,
  `comments` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_connect`
--

LOCK TABLES `db_connect` WRITE;
/*!40000 ALTER TABLE `db_connect` DISABLE KEYS */;
INSERT INTO `db_connect` VALUES (1,'',3,1,'d_taiwan','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(2,'',3,2,'taiwan_cain','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(3,'',3,3,'taiwan_cain_2nd','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(4,'',3,4,'taiwan_cain_log','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(5,'',3,5,'taiwan_cain_web','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(6,'',3,6,'taiwan_login','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(7,'',3,7,'taiwan_prod','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(8,'',3,8,'d_guild','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(9,'',3,9,'taiwan_game_event','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(10,'',3,10,'d_taiwan_secu','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(12,'',3,12,'taiwan_cain_auction_gold','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(13,'',3,13,'taiwan_se_event','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(11,'',3,11,'taiwan_login_play','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(14,'',3,15,'d_technical_report','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b',''),(15,'',3,14,'taiwan_billing','127.0.0.1',3306,'game','20e35501e56fcedbe8b10c1f8bc3595be8b10c1f8bc3595b','taiwan billing');
/*!40000 ALTER TABLE `db_connect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_charac_mov`
--

DROP TABLE IF EXISTS `dnf_charac_mov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_charac_mov` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `move_server_id` tinyint(4) NOT NULL DEFAULT '0',
  `move_charac_no` int(11) NOT NULL DEFAULT '0',
  `move_check` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `m_id` (`m_id`,`server_id`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_charac_mov`
--

LOCK TABLES `dnf_charac_mov` WRITE;
/*!40000 ALTER TABLE `dnf_charac_mov` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_charac_mov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_address`
--

DROP TABLE IF EXISTS `dnf_event_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_address` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `zipcode` varchar(7) NOT NULL DEFAULT '',
  `address` varchar(150) NOT NULL DEFAULT '',
  `phone_no` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`event_id`,`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_address`
--

LOCK TABLES `dnf_event_address` WRITE;
/*!40000 ALTER TABLE `dnf_event_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_entry_notuse`
--

DROP TABLE IF EXISTS `dnf_event_entry_notuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_entry_notuse` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `obtain_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_entry_notuse`
--

LOCK TABLES `dnf_event_entry_notuse` WRITE;
/*!40000 ALTER TABLE `dnf_event_entry_notuse` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_entry_notuse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_info`
--

DROP TABLE IF EXISTS `dnf_event_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_info` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `event_name` varchar(30) NOT NULL DEFAULT '',
  `event_explain` varchar(100) NOT NULL DEFAULT '',
  `apply_type` tinyint(4) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `end_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`event_id`) USING BTREE,
  UNIQUE KEY `event_name` (`event_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_info`
--

LOCK TABLES `dnf_event_info` WRITE;
/*!40000 ALTER TABLE `dnf_event_info` DISABLE KEYS */;
INSERT INTO `dnf_event_info` VALUES (1,'CUnlimitFatigueEvent','疲勞度無限大',0,'0000-00-00','2016-01-16'),(2,'CMaxFatigueFactorEvent','最大疲勞度|百分比',1,'0000-00-00','2015-08-01'),(3,'CExpDoubleEvent','雙倍經驗|百分比',1,'0000-00-00','2015-08-01'),(4,'CCoinEventPerDay','每日分發復活幣|1~17級|18~26級|27級以上|未使用',4,'0000-00-00','2015-08-01'),(5,'CCoinEventOnCharCreate','創建角色時，分發復活幣|復活幣數|',1,'0000-00-00','0000-00-00'),(6,'CLeadingChannelEvent','頻道引導',0,'0000-00-00','0000-00-00'),(7,'CItemDropRatioEvent','道具掉落率加倍|倍數',1,'0000-00-00','0000-00-00'),(8,'CPCRoomBurningEvent','網咖燃燒時間|百分比',1,'0000-00-00','0000-00-00'),(9,'CSchoolMatchEvent','超級學校對戰',3,'0000-00-00','0000-00-00'),(10,'CPCRoomFatigueEvent','網咖玩家疲勞度無限大活動',0,'0000-00-00','0000-00-00'),(12,'CReformingDanjinEvent','土罐改版活動',0,'0000-00-00','0000-00-00'),(13,'CCoinRefillEvent','復活幣加值活動|第一時間|第二十間',2,'0000-00-00','0000-00-00'),(15,'CBurningFatigueEvent','燃燒疲勞度活動',0,'0000-00-00','0000-00-00'),(16,'CClearRewardCardEvent','完成地下城 獎賞限定道具活動',0,'0000-00-00','0000-00-00'),(17,'CCeraShopBonusItemEvent','商城BONUS道具活動|給予BONUS道具的機率是（1000分比。如為100，將無條件獲得道具。如為10，將有10%機率可獲得）',1,'0000-00-00','0000-00-00'),(18,'CTournamentPvPEvent','撥放用決戰場',0,'0000-00-00','0000-00-00'),(19,'CGoldCardBlankItemEvent','金卡活動',0,'0000-00-00','0000-00-00'),(21,'CCollectArchieveEventLog','收集達成成就的Log',0,'0000-00-00','0000-00-00'),(22,'CPCRoomWorldDropEvent','網咖world掉落活動',0,'0000-00-00','0000-00-00'),(24,'CPartyExpBonusEvent','組隊經驗值獎賞|百分比',1,'0000-00-00','0000-00-00'),(29,'CPcRoomCardBlankItemEvent','網咖卡Blank活動',0,'0000-00-00','0000-00-00'),(30,'CPowerWarEvent','勢力戰活動',0,'0000-00-00','0000-00-00'),(32,'CStabToDeathEvent','刺殺週活動',0,'0000-00-00','0000-00-00'),(33,'CGuildWarEvent','',0,'0000-00-00','0000-00-00'),(34,'CAutoMarketConditionsControlEv','',0,'0000-00-00','0000-00-00'),(35,'CVendingMachineBonusEvent','自動售貨機BONUS活動',0,'0000-00-00','0000-00-00'),(36,'CBurnigGoldMonsterEvent','燃燒金怪物活動',0,'0000-00-00','0000-00-00'),(38,'CNoNeedGoldOnGuildCreateEvent','免費創設公會活動',0,'0000-00-00','0000-00-00'),(39,'CDeathTowerWinPointEvent','死亡之塔/迷妄之塔 apc活動|百分比',1,'0000-00-00','0000-00-00'),(40,'CNotApplyBalkeunEvent','未套用COF指數活動',0,'0000-00-00','0000-00-00'),(41,'CCharacterDayEvent','角色日活動|職業號碼（0:鬼劍士,1:格鬥家,2:神槍手,3:魔法師,4:聖職者,5:女神槍手,6:盜賊,7:格鬥家(男),100:Game Script）',1,'0000-00-00','0000-00-00'),(42,'CAssaultOnOffEvent','防止街頭爭霸活動',0,'0000-00-00','0000-00-00'),(43,'CFatigueBuffEvent','疲勞度 Buff活動',0,'0000-00-00','0000-00-00'),(45,'CBloodDungeonRewardFirstEvent','無盡的祭壇中獎金 平時|中獎金',1,'0000-00-00','0000-00-00'),(46,'CBloodDungeonRewardSecondEvent','無盡的祭壇中獎金 活動時|中獎金',1,'0000-00-00','0000-00-00'),(48,'CPCRoomWorldDropEvent2nd','網咖world掉落活動 2nd',0,'0000-00-00','0000-00-00'),(49,'CRestrictCharacCreationEvent','角色伺服器生成限制',1,'0000-00-00','0000-00-00'),(50,'CReduceUpgradeItemPay','強化費用折扣活動',1,'0000-00-00','0000-00-00'),(51,'COnTimeEvent','On Time活動',2,'0000-00-00','0000-00-00'),(52,'CBreakAwayPreventEvent','防止脫離系統',0,'0000-00-00','0000-00-00'),(53,'CPowerWarVictoriousEvent','勢力戰勝利勢力耐久度活動',0,'0000-00-00','0000-00-00'),(54,'CPvPExpPenaltyEvent','決鬥場經驗值處罰 ',0,'0000-00-00','0000-00-00'),(55,'CPvPLiveEvent','Live 統合決鬥場活動',0,'0000-00-00','0000-00-00'),(56,'CIntegratedPvPServerMatchEvent','伺服器對抗戰活動',0,'0000-00-00','0000-00-00'),(57,'COnlinePreliminaryEvent','聯賽線上預選',0,'0000-00-00','0000-00-00'),(58,'CSecretShopEvent','神秘商店活動',0,'0000-00-00','0000-00-00'),(61,'CDnFLeaguePromoteFirstEvent','聯賽宣傳（星期四）',0,'0000-00-00','0000-00-00'),(62,'CDnFLeaguePromoteSecondEvent','聯賽宣傳（星期五）',0,'0000-00-00','0000-00-00'),(64,'CDoubleGoldCardEvent','金卡獎賞2倍活動',0,'0000-00-00','0000-00-00'),(65,'CPremiumGoldCard','優惠金卡活動',0,'0000-00-00','0000-00-00'),(67,'CGmRegistEvent','GM Web manager tool登入',0,'0000-00-00','0000-00-00'),(86,'CFatigueAttendance','出席活動',0,'0000-00-00','0000-00-00'),(87,'CWeekendBonusEvent','周末BONUS活動',0,'0000-00-00','0000-00-00'),(91,'CUXGameLogEvent','UX Game Log 系統',0,'0000-00-00','0000-00-00'),(92,'CPCRoomPlayTimeEvent','網咖遊戲時間活動',0,'0000-00-00','0000-00-00'),(93,'LevelUpBefore70LvEvent','升級活動',0,'0000-00-00','0000-00-00'),(94,'CDimensionActivationEvent','異界地下城活性化活動',0,'0000-00-00','0000-00-00'),(95,'BlueMarbleDungeonEvent','活動地下城',0,'0000-00-00','0000-00-00'),(96,'AttendanceEvent','2012年出席活動',1,'0000-00-00','0000-00-00'),(100,'GrowthEquipEvent','成長型裝備活動',0,'0000-00-00','0000-00-00'),(101,'CFatigueGiveItemEvent','消耗疲勞度分發道具活動',0,'0000-00-00','0000-00-00'),(102,'CStopOverlabExpEvent','成長之秘方禁止效果重複活動',0,'0000-00-00','0000-00-00'),(103,'GiveGrowCreatureEvent','分發成長型道具寵物活動',0,'0000-00-00','0000-00-00'),(104,'NewAccountLevelUpEventToJob','達成職業別等級 分發道具活動',0,'0000-00-00','0000-00-00'),(105,'SeriaRoomAniDecoEvent','布置賽莉亞房活動(動畫)',0,'0000-00-00','0000-00-00'),(106,'BingoEvent','賓果活動',0,'0000-00-00','0000-00-00'),(109,'OneADayItemShopEvent','OneADay商店活動',0,'0000-00-00','0000-00-00'),(113,'CConditionEvent','event_msg_67 == NULL, Etc/Etc.kor.str : ',0,'0000-00-00','0000-00-00'),(116,'CAradRyosikaEvent','event_msg_190 == NULL, Etc/Etc.kor.str : ',2,'0000-00-00','0000-00-00'),(119,'CEventAdvanceAltarOpen','分發成長型道具寵物活動',0,'0000-00-00','0000-00-00'),(155,'Arad_MomijiEvent','event_msg_196 == NULL, Etc/Etc.kor.str : ',4,'0000-00-00','0000-00-00'),(158,'LevelupSupportEvent','event_msg_158 == NULL, Etc/Etc.kor.str : ',0,'0000-00-00','0000-00-00'),(159,'CEventStayTime','event_msg_159 == NULL, Etc/Etc.kor.str : ',2,'0000-00-00','0000-00-00'),(160,'CEventCreateDnf','event_msg_160 == NULL, Etc/Etc.kor.str : ',4,'0000-00-00','0000-00-00'),(161,'CEventCeraShopRewardPoint','Cera Point Event',2,'0000-00-00','0000-00-00'),(162,'EventNewCharacterReward','event_msg_162 == NULL, Etc/Etc.kor.str : ',2,'0000-00-00','0000-00-00'),(163,'LevelupSupport2ndEvent','event_msg_164 == NULL, Etc/Etc.kor.str : ',0,'0000-00-00','0000-00-00'),(164,'HeroMissionEvent','event_msg_163 == NULL, Etc/Etc.kor.str : ',0,'0000-00-00','0000-00-00'),(165,'EventGiveMeBox','event_msg_165 == NULL, Etc/Etc.kor.str : ',0,'0000-00-00','0000-00-00');
/*!40000 ALTER TABLE `dnf_event_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_log`
--

DROP TABLE IF EXISTS `dnf_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` int(11) NOT NULL DEFAULT '0',
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `parameter1` int(10) unsigned NOT NULL DEFAULT '0',
  `parameter2` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `event_flag` tinyint(3) DEFAULT '0',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `expl` varchar(200) NOT NULL DEFAULT '',
  `etc` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE,
  KEY `idx_sever_id` (`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_log`
--

LOCK TABLES `dnf_event_log` WRITE;
/*!40000 ALTER TABLE `dnf_event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_event_prize`
--

DROP TABLE IF EXISTS `dnf_event_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_event_prize` (
  `prize_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `check_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prize_id`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_event_prize`
--

LOCK TABLES `dnf_event_prize` WRITE;
/*!40000 ALTER TABLE `dnf_event_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_event_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_game_message`
--

DROP TABLE IF EXISTS `dnf_game_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_game_message` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `display_type` tinyint(4) NOT NULL DEFAULT '1',
  `start_h` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `end_h` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `display_type` (`display_type`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_game_message`
--

LOCK TABLES `dnf_game_message` WRITE;
/*!40000 ALTER TABLE `dnf_game_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_game_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_gamein_notice`
--

DROP TABLE IF EXISTS `dnf_gamein_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_gamein_notice` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `img_name` varchar(250) NOT NULL DEFAULT '',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `reg_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `open_flag` enum('y','n') DEFAULT 'n',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_server_id` (`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_gamein_notice`
--

LOCK TABLES `dnf_gamein_notice` WRITE;
/*!40000 ALTER TABLE `dnf_gamein_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_gamein_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_master_charac`
--

DROP TABLE IF EXISTS `dnf_master_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_master_charac` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `global_type` tinyint(4) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`global_type`,`server_id`) USING BTREE,
  KEY `server_id` (`server_id`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_master_charac`
--

LOCK TABLES `dnf_master_charac` WRITE;
/*!40000 ALTER TABLE `dnf_master_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_master_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_pcroom`
--

DROP TABLE IF EXISTS `dnf_pcroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_pcroom` (
  `ip_no` int(11) NOT NULL AUTO_INCREMENT,
  `district` varchar(10) NOT NULL DEFAULT '',
  `firm_name` varchar(25) NOT NULL DEFAULT '',
  `telephone` varchar(10) NOT NULL DEFAULT '',
  `address` varchar(75) NOT NULL DEFAULT '',
  `leader` varchar(15) NOT NULL DEFAULT '',
  `start_ip` varchar(7) NOT NULL DEFAULT '',
  `end_ip` varchar(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`ip_no`) USING BTREE,
  UNIQUE KEY `start_ip` (`start_ip`) USING BTREE,
  UNIQUE KEY `end_ip` (`end_ip`) USING BTREE,
  KEY `idx_district` (`district`) USING BTREE,
  KEY `idx_leader` (`leader`) USING BTREE,
  KEY `idx_firm_name` (`firm_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_pcroom`
--

LOCK TABLES `dnf_pcroom` WRITE;
/*!40000 ALTER TABLE `dnf_pcroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_pcroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_restrict_info`
--

DROP TABLE IF EXISTS `dnf_restrict_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_restrict_info` (
  `category` int(11) NOT NULL,
  `restrict_code` int(11) NOT NULL,
  `restrict_str` varchar(45) NOT NULL,
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`category`,`restrict_code`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='서비스 제재 정보 문자열';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_restrict_info`
--

LOCK TABLES `dnf_restrict_info` WRITE;
/*!40000 ALTER TABLE `dnf_restrict_info` DISABLE KEYS */;
INSERT INTO `dnf_restrict_info` VALUES (1,1,'DeleteItem','2013-01-21 20:34:41'),(1,2,'DropGold','2013-01-21 20:34:41'),(1,3,'UseNpc','2013-01-21 20:34:41'),(1,4,'UseMail','2013-01-21 20:34:41'),(1,5,'UseAuction','2013-01-21 20:34:41'),(1,6,'UseTrade','2013-01-21 20:34:41'),(1,7,'UseUpgrade','2013-01-21 20:34:41'),(1,8,'UseEnchant','2013-01-21 20:34:41'),(1,9,'UseCompound','2013-01-21 20:34:41'),(1,10,'UseDisjoint','2013-01-21 20:34:41'),(1,11,'UsePrivateStore','2013-01-21 20:34:41'),(1,12,'UseStackable','2013-01-21 20:34:41'),(1,13,'UseBindSphere','2013-01-21 20:34:41'),(1,14,'UseSeal','2013-01-21 20:34:41'),(1,15,'UseRandomOptionChange','2013-01-21 20:34:41'),(1,16,'UseRandomOptionReGeneration','2013-01-21 20:34:41'),(1,17,'UseCeraShop','2013-01-21 20:34:41'),(1,18,'UseRandomBox','2013-01-21 20:34:41'),(1,19,'UseExportJob','2013-01-21 20:34:41'),(1,20,'UseDisjointAvatar','2013-01-21 20:34:41'),(1,21,'UseEmblemCompound','2013-01-21 20:34:41'),(1,22,'RecoverStamina','2013-01-21 20:34:41'),(1,23,'DeleteCharacter','2013-01-21 20:34:41'),(1,24,'AccountCargo','2013-01-21 20:34:41'),(1,25,'AccountUpgrade','2013-01-21 20:34:41'),(1,26,'AccountMoveGold','2013-01-21 20:34:41'),(1,27,'AccountMoveItem','2013-01-21 20:34:41'),(1,28,'GuildCreate','2013-01-21 20:34:41'),(1,29,'GuildLevelUp','2013-01-21 20:34:41'),(1,30,'GuildSkillUp','2013-01-21 20:34:41'),(1,31,'GuildBreak','2013-01-21 20:34:41'),(1,32,'CreateCharacter','2013-04-25 10:41:21'),(1,33,'LoginChannel','2013-04-25 10:41:21'),(3,1,'DropRate','2013-05-16 12:24:23');
/*!40000 ALTER TABLE `dnf_restrict_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_restrict_state`
--

DROP TABLE IF EXISTS `dnf_restrict_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_restrict_state` (
  `server_group` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `restrict_code` int(11) NOT NULL,
  `restrict_value` char(1) NOT NULL,
  `mod_date` datetime NOT NULL,
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`server_group`,`category`,`restrict_code`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_restrict_state`
--

LOCK TABLES `dnf_restrict_state` WRITE;
/*!40000 ALTER TABLE `dnf_restrict_state` DISABLE KEYS */;
INSERT INTO `dnf_restrict_state` VALUES (1,1,1,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,2,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,3,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,4,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,5,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,6,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,7,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,8,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,9,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,10,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,11,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,12,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,13,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,14,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,15,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,16,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,17,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,18,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,19,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,20,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,21,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,22,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,23,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,24,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,25,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,26,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,27,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,28,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,29,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,30,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,31,'1','2013-03-27 17:42:15','2013-03-27 17:42:15'),(1,1,32,'1','2013-04-25 10:41:21','2013-04-25 10:41:21'),(1,1,33,'1','2013-04-25 10:41:21','2013-04-25 10:41:21'),(1,3,1,'0','2013-05-16 12:24:23','2013-05-16 12:24:23'),(2,1,1,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,2,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,3,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,4,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,5,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,6,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,7,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,8,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,9,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,10,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,11,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,12,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,13,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,14,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,15,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,16,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,17,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,18,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,19,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,20,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,21,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,22,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,23,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,24,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,25,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,26,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,27,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,28,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,29,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,30,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,31,'1','2013-02-14 22:13:16','2013-02-14 22:13:16'),(2,1,32,'1','2013-04-25 10:41:24','2013-04-25 10:41:24'),(2,1,33,'1','2013-04-25 10:41:24','2013-04-25 10:41:24'),(2,3,1,'0','2013-05-16 12:24:43','2013-05-16 12:24:43'),(3,1,1,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,2,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,3,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,4,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,5,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,6,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,7,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,8,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,9,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,10,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,11,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,12,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,13,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,14,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,15,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,16,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,17,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,18,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,19,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,20,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,21,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,22,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,23,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,24,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,25,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,26,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,27,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,28,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,29,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,30,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,31,'1','2013-03-27 17:43:44','2013-03-27 17:43:44'),(3,1,32,'1','2013-04-25 10:41:21','2013-04-25 10:41:21'),(3,1,33,'1','2013-04-25 10:41:21','2013-04-25 10:41:21'),(3,3,1,'0','2013-05-16 12:24:45','2013-05-16 12:24:45');
/*!40000 ALTER TABLE `dnf_restrict_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_story`
--

DROP TABLE IF EXISTS `dnf_story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_story` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `story_type` tinyint(4) NOT NULL DEFAULT '0',
  `notice_flag` tinyint(4) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `reg_id` varchar(12) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `img_name` varchar(30) NOT NULL DEFAULT '',
  `opt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `open_flag` enum('y','n') NOT NULL DEFAULT 'n',
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `reserve_time` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text,
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_mid` (`m_id`) USING BTREE,
  KEY `idx_reg` (`reg_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_story`
--

LOCK TABLES `dnf_story` WRITE;
/*!40000 ALTER TABLE `dnf_story` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_story` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_testr_m_id`
--

DROP TABLE IF EXISTS `dnf_testr_m_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_testr_m_id` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `sex` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_testr_m_id`
--

LOCK TABLES `dnf_testr_m_id` WRITE;
/*!40000 ALTER TABLE `dnf_testr_m_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_testr_m_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_arad_birthday_6th`
--

DROP TABLE IF EXISTS `event_arad_birthday_6th`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_arad_birthday_6th` (
  `server` int(10) unsigned NOT NULL DEFAULT '0',
  `point` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_arad_birthday_6th`
--

LOCK TABLES `event_arad_birthday_6th` WRITE;
/*!40000 ALTER TABLE `event_arad_birthday_6th` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_arad_birthday_6th` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_aradlotto_0809_entry`
--

DROP TABLE IF EXISTS `event_aradlotto_0809_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_aradlotto_0809_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` int(11) NOT NULL DEFAULT '0',
  `lotto_num` char(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx1` (`lotto_num`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_aradlotto_0809_entry`
--

LOCK TABLES `event_aradlotto_0809_entry` WRITE;
/*!40000 ALTER TABLE `event_aradlotto_0809_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_aradlotto_0809_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_charac_mov_1th`
--

DROP TABLE IF EXISTS `event_charac_mov_1th`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_charac_mov_1th` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `move_server_id` tinyint(4) NOT NULL DEFAULT '0',
  `move_charac_no` int(11) NOT NULL DEFAULT '0',
  `move_check` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `m_id` (`m_id`,`server_id`,`charac_no`) USING BTREE,
  KEY `idx_move_charac_no` (`move_charac_no`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_charac_mov_1th`
--

LOCK TABLES `event_charac_mov_1th` WRITE;
/*!40000 ALTER TABLE `event_charac_mov_1th` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_charac_mov_1th` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_charac_mov_1th_entry`
--

DROP TABLE IF EXISTS `event_charac_mov_1th_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_charac_mov_1th_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` int(11) NOT NULL DEFAULT '0',
  `it_no` int(11) NOT NULL DEFAULT '0',
  `item_check` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_charac_mov_1th_entry`
--

LOCK TABLES `event_charac_mov_1th_entry` WRITE;
/*!40000 ALTER TABLE `event_charac_mov_1th_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_charac_mov_1th_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_goldcard_cnt`
--

DROP TABLE IF EXISTS `event_goldcard_cnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_goldcard_cnt` (
  `item_no` int(10) NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `cnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_no`,`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_goldcard_cnt`
--

LOCK TABLES `event_goldcard_cnt` WRITE;
/*!40000 ALTER TABLE `event_goldcard_cnt` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_goldcard_cnt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_goldcard_entry1`
--

DROP TABLE IF EXISTS `event_goldcard_entry1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_goldcard_entry1` (
  `occ_date` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `item_no` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_goldcard_entry1`
--

LOCK TABLES `event_goldcard_entry1` WRITE;
/*!40000 ALTER TABLE `event_goldcard_entry1` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_goldcard_entry1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_goldcard_entry2`
--

DROP TABLE IF EXISTS `event_goldcard_entry2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_goldcard_entry2` (
  `occ_date` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `item_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item_check` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`m_id`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_goldcard_entry2`
--

LOCK TABLES `event_goldcard_entry2` WRITE;
/*!40000 ALTER TABLE `event_goldcard_entry2` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_goldcard_entry2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_goldcard_info`
--

DROP TABLE IF EXISTS `event_goldcard_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_goldcard_info` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `coupon` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_goldcard_info`
--

LOCK TABLES `event_goldcard_info` WRITE;
/*!40000 ALTER TABLE `event_goldcard_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_goldcard_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_hinamatsuri_cnt`
--

DROP TABLE IF EXISTS `event_hinamatsuri_cnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_hinamatsuri_cnt` (
  `cnt` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_hinamatsuri_cnt`
--

LOCK TABLES `event_hinamatsuri_cnt` WRITE;
/*!40000 ALTER TABLE `event_hinamatsuri_cnt` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_hinamatsuri_cnt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_mage_2years`
--

DROP TABLE IF EXISTS `event_mage_2years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_mage_2years` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL AUTO_INCREMENT,
  `charac_name` varchar(100) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`server_info`,`charac_no`) USING BTREE,
  KEY `charac_no` (`charac_no`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_mage_2years`
--

LOCK TABLES `event_mage_2years` WRITE;
/*!40000 ALTER TABLE `event_mage_2years` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_mage_2years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_newmember0709_entry`
--

DROP TABLE IF EXISTS `event_newmember0709_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_newmember0709_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` int(11) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `item1_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item1_check` int(11) unsigned NOT NULL DEFAULT '0',
  `item2_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item2_check` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_occ_date` (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_newmember0709_entry`
--

LOCK TABLES `event_newmember0709_entry` WRITE;
/*!40000 ALTER TABLE `event_newmember0709_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_newmember0709_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_pandora_entry_200905`
--

DROP TABLE IF EXISTS `event_pandora_entry_200905`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_pandora_entry_200905` (
  `m_id` int(11) unsigned NOT NULL DEFAULT '0',
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `server_id` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_date`,`server_id`) USING BTREE,
  KEY `idx_date` (`occ_date`) USING BTREE,
  KEY `idx_charac` (`server_id`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_pandora_entry_200905`
--

LOCK TABLES `event_pandora_entry_200905` WRITE;
/*!40000 ALTER TABLE `event_pandora_entry_200905` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_pandora_entry_200905` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_quest_party_member_web`
--

DROP TABLE IF EXISTS `event_quest_party_member_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_quest_party_member_web` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `quest_no` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `send_charac_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`server_id`,`charac_no`,`quest_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_quest_party_member_web`
--

LOCK TABLES `event_quest_party_member_web` WRITE;
/*!40000 ALTER TABLE `event_quest_party_member_web` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_quest_party_member_web` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_quizquiz_stamp`
--

DROP TABLE IF EXISTS `event_quizquiz_stamp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_quizquiz_stamp` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `degree` tinyint(4) NOT NULL DEFAULT '0',
  `stamp` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`,`degree`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_quizquiz_stamp`
--

LOCK TABLES `event_quizquiz_stamp` WRITE;
/*!40000 ALTER TABLE `event_quizquiz_stamp` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_quizquiz_stamp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_skill2025_entry`
--

DROP TABLE IF EXISTS `event_skill2025_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_skill2025_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_skill2025_entry`
--

LOCK TABLES `event_skill2025_entry` WRITE;
/*!40000 ALTER TABLE `event_skill2025_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_skill2025_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_tower_entry`
--

DROP TABLE IF EXISTS `event_tower_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_tower_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_date` int(11) unsigned NOT NULL DEFAULT '0',
  `occ_check` int(11) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `item1_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item1_check` int(11) unsigned NOT NULL DEFAULT '0',
  `item2_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item2_check` int(11) unsigned NOT NULL DEFAULT '0',
  `item3_no` int(11) unsigned NOT NULL DEFAULT '0',
  `item3_check` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_occ_date` (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_tower_entry`
--

LOCK TABLES `event_tower_entry` WRITE;
/*!40000 ALTER TABLE `event_tower_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tower_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_webmoneystamp_entry`
--

DROP TABLE IF EXISTS `event_webmoneystamp_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_webmoneystamp_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `attend_point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_attend_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `return_flag` tinyint(4) NOT NULL DEFAULT '0',
  `entry_item` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_webmoneystamp_entry`
--

LOCK TABLES `event_webmoneystamp_entry` WRITE;
/*!40000 ALTER TABLE `event_webmoneystamp_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_webmoneystamp_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_webmoneystamp_item`
--

DROP TABLE IF EXISTS `event_webmoneystamp_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_webmoneystamp_item` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` tinyint(4) NOT NULL DEFAULT '0',
  `item_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_check` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`,`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_webmoneystamp_item`
--

LOCK TABLES `event_webmoneystamp_item` WRITE;
/*!40000 ALTER TABLE `event_webmoneystamp_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_webmoneystamp_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_channel`
--

DROP TABLE IF EXISTS `game_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_channel` (
  `gc_no` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gc_now` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_ip` char(32) NOT NULL DEFAULT '',
  `gc_port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_max` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_game` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gc_channel` char(16) NOT NULL DEFAULT '',
  `gc_ch_group` smallint(5) NOT NULL DEFAULT '0',
  `gc_channeltype` char(0) NOT NULL DEFAULT '',
  PRIMARY KEY (`gc_no`) USING BTREE,
  KEY `idxGC_GAME` (`gc_game`) USING BTREE,
  KEY `idxch_group` (`gc_ch_group`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_channel`
--

LOCK TABLES `game_channel` WRITE;
/*!40000 ALTER TABLE `game_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_allow`
--

DROP TABLE IF EXISTS `geo_allow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_allow` (
  `allow_ip` varchar(20) NOT NULL DEFAULT '',
  `allow_c_code` varchar(4) NOT NULL DEFAULT '',
  `allow_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`allow_ip`) USING BTREE,
  KEY `idx_c_code` (`allow_c_code`) USING BTREE,
  KEY `idx_date` (`allow_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_allow`
--

LOCK TABLES `geo_allow` WRITE;
/*!40000 ALTER TABLE `geo_allow` DISABLE KEYS */;
/*!40000 ALTER TABLE `geo_allow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_allow_country`
--

DROP TABLE IF EXISTS `geo_allow_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_allow_country` (
  `server_group` tinyint(4) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`country_code`,`server_group`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_allow_country`
--

LOCK TABLES `geo_allow_country` WRITE;
/*!40000 ALTER TABLE `geo_allow_country` DISABLE KEYS */;
INSERT INTO `geo_allow_country` VALUES (3,'CN','2015-07-09 18:43:04'),(3,'HK','2013-04-08 14:36:28'),(3,'MO','2013-04-08 14:36:36'),(3,'TW','2013-04-08 14:36:40');
/*!40000 ALTER TABLE `geo_allow_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_country_code`
--

DROP TABLE IF EXISTS `geo_country_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_country_code` (
  `code_no` int(11) NOT NULL,
  `country_code_a2` varchar(10) NOT NULL,
  `country_code_a3` varchar(10) NOT NULL,
  `country` varchar(255) NOT NULL,
  PRIMARY KEY (`code_no`) USING BTREE,
  UNIQUE KEY `geo_country_code_unq001` (`country_code_a2`) USING BTREE,
  UNIQUE KEY `geo_country_code_unq002` (`country_code_a3`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_country_code`
--

LOCK TABLES `geo_country_code` WRITE;
/*!40000 ALTER TABLE `geo_country_code` DISABLE KEYS */;
INSERT INTO `geo_country_code` VALUES (4,'AF','AFG','AFGHANISTAN'),(8,'AL','ALB','ALBANIA'),(10,'AQ','ATA','ANTARCTICA'),(12,'DZ','DZA','ALGERIA'),(16,'AS','ASM','AMERICAN SAMOA'),(20,'AD','AND','ANDORRA'),(24,'AO','AGO','ANGOLA'),(28,'AG','ATG','ANTIGUA AND BARBUDA'),(31,'AZ','AZE','AZERBAIJAN'),(32,'AR','ARG','ARGENTINA'),(36,'AU','AUS','AUSTRALIA'),(40,'AT','AUT','AUSTRIA'),(44,'BS','BHS','BAHAMAS'),(48,'BH','BHR','BAHRAIN'),(50,'BD','BGD','BANGLADESH'),(51,'AM','ARM','ARMENIA'),(52,'BB','BRB','BARBADOS'),(56,'BE','BEL','BELGIUM'),(60,'BM','BMU','BERMUDA'),(64,'BT','BTN','BHUTAN'),(68,'BO','BOL','BOLIVIA'),(70,'BA','BIH','BOSNIA AND HERZEGOWINA'),(72,'BW','BWA','BOTSWANA'),(74,'BV','BVT','BOUVET ISLAND'),(76,'BR','BRA','BRAZIL'),(84,'BZ','BLZ','BELIZE'),(86,'IO','IOT','BRITISH INDIAN OCEAN TERRITORY'),(90,'SB','SLB','SOLOMON ISLANDS '),(92,'VG','VGB','VIRGIN ISLANDS (BRITISH)'),(96,'BN','BRN','BRUNEI DARUSSALAM'),(100,'BG','BGR','BULGARIA'),(104,'MM','MMR','MYANMAR '),(108,'BI','BDI','BURUNDI'),(112,'BY','BLR','BELARUS'),(116,'KH','KHM','CAMBODIA'),(120,'CM','CMR','CAMEROON'),(124,'CA','CAN','CANADA'),(132,'CV','CPV','CAPE VERDE'),(136,'KY','CYM','CAYMAN ISLANDS'),(140,'CF','CAF','CENTRAL AFRICAN REPUBLIC'),(144,'LK','LKA','SRI LANKA '),(148,'TD','TCD','CHAD'),(152,'CL','CHL','CHILE '),(156,'CN','CHN','CHINA '),(158,'TW','TWN','TAIWAN'),(162,'CX','CXR','CHRISTMAS ISLAND'),(166,'CC','CCK','COCOS (KEELING) ISLANDS '),(170,'CO','COL','COLOMBIA'),(174,'KM','COM','COMOROS '),(175,'YT','MYT','MAYOTTE '),(178,'CG','COG','CONGO, Republic of'),(180,'CD','COD','CONGO, Democratic Republic of (was Zaire) '),(184,'CK','COK','COOK ISLANDS'),(188,'CR','CRI','COSTA RICA'),(191,'HR','HRV','CROATIA (local name: Hrvatska)'),(192,'CU','CUB','CUBA'),(196,'CY','CYP','CYPRUS'),(203,'CZ','CZE','CZECH REPUBLIC'),(204,'BJ','BEN','BENIN'),(208,'DK','DNK','DENMARK '),(212,'DM','DMA','DOMINICA'),(214,'DO','DOM','DOMINICAN REPUBLIC'),(218,'EC','ECU','ECUADOR '),(222,'SV','SLV','EL SALVADOR '),(226,'GQ','GNQ','EQUATORIAL GUINEA '),(231,'ET','ETH','ETHIOPIA'),(232,'ER','ERI','ERITREA '),(233,'EE','EST','ESTONIA '),(234,'FO','FRO','FAROE ISLANDS '),(238,'FK','FLK','FALKLAND ISLANDS (MALVINAS) '),(239,'GS','SGS','SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS'),(242,'FJ','FJI','FIJI'),(246,'FI','FIN','FINLAND '),(248,'AX','ALA','AALAND ISLANDS'),(250,'FR','FRA','FRANCE'),(254,'GF','GUF','FRENCH GUIANA '),(258,'PF','PYF','FRENCH POLYNESIA'),(260,'TF','ATF','FRENCH SOUTHERN TERRITORIES '),(262,'DJ','DJI','DJIBOUTI'),(266,'GA','GAB','GABON '),(268,'GE','GEO','GEORGIA '),(270,'GM','GMB','GAMBIA'),(275,'PS','PSE','PALESTINIAN TERRITORY, Occupied '),(276,'DE','DEU','GERMANY '),(288,'GH','GHA','GHANA '),(292,'GI','GIB','GIBRALTAR '),(296,'KI','KIR','KIRIBATI'),(300,'GR','GRC','GREECE'),(304,'GL','GRL','GREENLAND '),(308,'GD','GRD','GRENADA '),(312,'GP','GLP','GUADELOUPE'),(316,'GU','GUM','GUAM'),(320,'GT','GTM','GUATEMALA '),(324,'GN','GIN','GUINEA'),(328,'GY','GUY','GUYANA'),(332,'HT','HTI','HAITI '),(334,'HM','HMD','HEARD AND MC DONALD ISLANDS '),(336,'VA','VAT','VATICAN CITY STATE (HOLY SEE) '),(340,'HN','HND','HONDURAS'),(344,'HK','HKG','HONG KONG '),(348,'HU','HUN','HUNGARY '),(352,'IS','ISL','ICELAND '),(356,'IN','IND','INDIA '),(360,'ID','IDN','INDONESIA '),(364,'IR','IRN','IRAN (ISLAMIC REPUBLIC OF)'),(368,'IQ','IRQ','IRAQ'),(372,'IE','IRL','IRELAND '),(376,'IL','ISR','ISRAEL'),(380,'IT','ITA','ITALY '),(384,'CI','CIV','COTE D\'IVOIRE '),(388,'JM','JAM','JAMAICA '),(392,'JP','JPN','JAPAN '),(398,'KZ','KAZ','KAZAKHSTAN'),(400,'JO','JOR','JORDAN'),(404,'KE','KEN','KENYA '),(408,'KP','PRK','KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF'),(410,'KR','KOR','KOREA, REPUBLIC OF'),(414,'KW','KWT','KUWAIT'),(417,'KG','KGZ','KYRGYZSTAN'),(418,'LA','LAO','LAO PEOPLE\'S DEMOCRATIC REPUBLIC'),(422,'LB','LBN','LEBANON '),(426,'LS','LSO','LESOTHO '),(428,'LV','LVA','LATVIA'),(430,'LR','LBR','LIBERIA '),(434,'LY','LBY','LIBYAN ARAB JAMAHIRIYA'),(438,'LI','LIE','LIECHTENSTEIN '),(440,'LT','LTU','LITHUANIA '),(442,'LU','LUX','LUXEMBOURG'),(446,'MO','MAC','MACAU '),(450,'MG','MDG','MADAGASCAR'),(454,'MW','MWI','MALAWI'),(458,'MY','MYS','MALAYSIA'),(462,'MV','MDV','MALDIVES'),(466,'ML','MLI','MALI'),(470,'MT','MLT','MALTA '),(474,'MQ','MTQ','MARTINIQUE'),(478,'MR','MRT','MAURITANIA'),(480,'MU','MUS','MAURITIUS '),(484,'MX','MEX','MEXICO'),(492,'MC','MCO','MONACO'),(496,'MN','MNG','MONGOLIA'),(498,'MD','MDA','MOLDOVA, REPUBLIC OF'),(500,'MS','MSR','MONTSERRAT'),(504,'MA','MAR','MOROCCO '),(508,'MZ','MOZ','MOZAMBIQUE'),(512,'OM','OMN','OMAN'),(516,'NA','NAM','NAMIBIA '),(520,'NR','NRU','NAURU '),(524,'NP','NPL','NEPAL '),(528,'NL','NLD','NETHERLANDS '),(530,'AN','ANT','NETHERLANDS ANTILLES'),(533,'AW','ABW','ARUBA'),(540,'NC','NCL','NEW CALEDONIA '),(548,'VU','VUT','VANUATU '),(554,'NZ','NZL','NEW ZEALAND '),(558,'NI','NIC','NICARAGUA '),(562,'NE','NER','NIGER '),(566,'NG','NGA','NIGERIA '),(570,'NU','NIU','NIUE'),(574,'NF','NFK','NORFOLK ISLAND'),(578,'NO','NOR','NORWAY'),(580,'MP','MNP','NORTHERN MARIANA ISLANDS'),(581,'UM','UMI','UNITED STATES MINOR OUTLYING ISLANDS'),(583,'FM','FSM','MICRONESIA, FEDERATED STATES OF '),(584,'MH','MHL','MARSHALL ISLANDS'),(585,'PW','PLW','PALAU '),(586,'PK','PAK','PAKISTAN'),(591,'PA','PAN','PANAMA'),(598,'PG','PNG','PAPUA NEW GUINEA'),(600,'PY','PRY','PARAGUAY'),(604,'PE','PER','PERU'),(608,'PH','PHL','PHILIPPINES '),(612,'PN','PCN','PITCAIRN'),(616,'PL','POL','POLAND'),(620,'PT','PRT','PORTUGAL'),(624,'GW','GNB','GUINEA-BISSAU '),(626,'TL','TLS','TIMOR-LESTE '),(630,'PR','PRI','PUERTO RICO '),(634,'QA','QAT','QATAR '),(638,'RE','REU','REUNION '),(642,'RO','ROU','ROMANIA '),(643,'RU','RUS','RUSSIAN FEDERATION'),(646,'RW','RWA','RWANDA'),(654,'SH','SHN','SAINT HELENA'),(659,'KN','KNA','SAINT KITTS AND NEVIS '),(660,'AI','AIA','ANGUILLA'),(662,'LC','LCA','SAINT LUCIA '),(666,'PM','SPM','SAINT PIERRE AND MIQUELON '),(670,'VC','VCT','SAINT VINCENT AND THE GRENADINES'),(674,'SM','SMR','SAN MARINO'),(678,'ST','STP','SAO TOME AND PRINCIPE '),(682,'SA','SAU','SAUDI ARABIA'),(686,'SN','SEN','SENEGAL '),(690,'SC','SYC','SEYCHELLES'),(694,'SL','SLE','SIERRA LEONE'),(702,'SG','SGP','SINGAPORE '),(703,'SK','SVK','SLOVAKIA'),(704,'VN','VNM','VIET NAM'),(705,'SI','SVN','SLOVENIA'),(706,'SO','SOM','SOMALIA '),(710,'ZA','ZAF','SOUTH AFRICA'),(716,'ZW','ZWE','ZIMBABWE'),(724,'ES','ESP','SPAIN '),(732,'EH','ESH','WESTERN SAHARA'),(736,'SD','SDN','SUDAN '),(740,'SR','SUR','SURINAME'),(744,'SJ','SJM','SVALBARD AND JAN MAYEN ISLANDS'),(748,'SZ','SWZ','SWAZILAND '),(752,'SE','SWE','SWEDEN'),(756,'CH','CHE','SWITZERLAND '),(760,'SY','SYR','SYRIAN ARAB REPUBLIC'),(762,'TJ','TJK','TAJIKISTAN'),(764,'TH','THA','THAILAND'),(768,'TG','TGO','TOGO'),(772,'TK','TKL','TOKELAU '),(776,'TO','TON','TONGA '),(780,'TT','TTO','TRINIDAD AND TOBAGO '),(784,'AE','ARE','UNITED ARAB EMIRATES'),(788,'TN','TUN','TUNISIA '),(792,'TR','TUR','TURKEY'),(795,'TM','TKM','TURKMENISTAN'),(796,'TC','TCA','TURKS AND CAICOS ISLANDS'),(798,'TV','TUV','TUVALU'),(800,'UG','UGA','UGANDA'),(804,'UA','UKR','UKRAINE '),(807,'MK','MKD','MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF'),(818,'EG','EGY','EGYPT '),(826,'GB','GBR','UNITED KINGDOM'),(834,'TZ','TZA','TANZANIA, UNITED REPUBLIC OF'),(840,'US','USA','UNITED STATES '),(850,'VI','VIR','VIRGIN ISLANDS (U.S.) '),(854,'BF','BFA','BURKINA FASO'),(858,'UY','URY','URUGUAY '),(860,'UZ','UZB','UZBEKISTAN'),(862,'VE','VEN','VENEZUELA '),(876,'WF','WLF','WALLIS AND FUTUNA ISLANDS '),(882,'WS','WSM','SAMOA '),(887,'YE','YEM','YEMEN '),(891,'CS','SCG','SERBIA AND MONTENEGRO '),(894,'ZM','ZMB','ZAMBIA');
/*!40000 ALTER TABLE `geo_country_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_reject`
--

DROP TABLE IF EXISTS `geo_reject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_reject` (
  `rej_ip` varchar(20) NOT NULL DEFAULT '',
  `rej_c_code` varchar(4) NOT NULL DEFAULT '',
  `rej_ip_count` int(11) unsigned NOT NULL DEFAULT '0',
  `rej_last_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rej_chk` char(1) NOT NULL DEFAULT 'N',
  `rej_src` enum('w','g') NOT NULL DEFAULT 'w',
  PRIMARY KEY (`rej_ip`) USING BTREE,
  KEY `idx_c_code` (`rej_c_code`) USING BTREE,
  KEY `idx_date` (`rej_last_date`) USING BTREE,
  KEY `idx_chk` (`rej_chk`) USING BTREE,
  KEY `rej_src` (`rej_src`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_reject`
--

LOCK TABLES `geo_reject` WRITE;
/*!40000 ALTER TABLE `geo_reject` DISABLE KEYS */;
/*!40000 ALTER TABLE `geo_reject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_ticket_entry`
--

DROP TABLE IF EXISTS `gift_ticket_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_ticket_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gift_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `buyer_id` int(10) unsigned NOT NULL DEFAULT '0',
  `buyer_date` int(10) unsigned NOT NULL DEFAULT '0',
  `buyer_code` varchar(21) NOT NULL DEFAULT '',
  `buyer_check` int(10) unsigned NOT NULL DEFAULT '0',
  `other_id` int(10) unsigned NOT NULL DEFAULT '0',
  `other_date` int(10) unsigned NOT NULL DEFAULT '0',
  `other_code` varchar(21) NOT NULL DEFAULT '',
  `other_check` int(10) unsigned NOT NULL DEFAULT '0',
  `message` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_buyer_id` (`buyer_id`) USING BTREE,
  KEY `idx_other_id` (`other_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_ticket_entry`
--

LOCK TABLES `gift_ticket_entry` WRITE;
/*!40000 ALTER TABLE `gift_ticket_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_ticket_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_manifest`
--

DROP TABLE IF EXISTS `gm_manifest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_manifest` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_manifest`
--

LOCK TABLES `gm_manifest` WRITE;
/*!40000 ALTER TABLE `gm_manifest` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_manifest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_manifest_notuse`
--

DROP TABLE IF EXISTS `gm_manifest_notuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_manifest_notuse` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_manifest_notuse`
--

LOCK TABLES `gm_manifest_notuse` WRITE;
/*!40000 ALTER TABLE `gm_manifest_notuse` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_manifest_notuse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bbs`
--

DROP TABLE IF EXISTS `guild_bbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bbs` (
  `gno` int(11) NOT NULL AUTO_INCREMENT,
  `bd_id` tinyint(4) NOT NULL DEFAULT '0',
  `empyn` tinyint(4) NOT NULL DEFAULT '0',
  `mgno` int(11) NOT NULL DEFAULT '0',
  `open` tinyint(1) NOT NULL DEFAULT '1',
  `main` tinyint(4) NOT NULL DEFAULT '0',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `mod_date` int(11) NOT NULL DEFAULT '0',
  `hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `body_type` char(1) NOT NULL DEFAULT '',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `reg_id` varchar(20) NOT NULL DEFAULT '',
  `subject` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`gno`) USING BTREE,
  UNIQUE KEY `uk_bdid_empyn_gno` (`bd_id`,`empyn`,`gno`) USING BTREE,
  UNIQUE KEY `uk_bdid_empyn_mgno` (`bd_id`,`empyn`,`mgno`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bbs`
--

LOCK TABLES `guild_bbs` WRITE;
/*!40000 ALTER TABLE `guild_bbs` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_body`
--

DROP TABLE IF EXISTS `guild_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_body` (
  `gno` int(11) NOT NULL DEFAULT '0',
  `body` text NOT NULL,
  PRIMARY KEY (`gno`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_body`
--

LOCK TABLES `guild_body` WRITE;
/*!40000 ALTER TABLE `guild_body` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_body` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_event`
--

DROP TABLE IF EXISTS `guild_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_event` (
  `gno` int(11) NOT NULL DEFAULT '0',
  `stt_date` date NOT NULL DEFAULT '0000-00-00',
  `end_date` date NOT NULL DEFAULT '0000-00-00',
  `ann_date` date NOT NULL DEFAULT '0000-00-00',
  `page_url` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`gno`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_event`
--

LOCK TABLES `guild_event` WRITE;
/*!40000 ALTER TABLE `guild_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_files`
--

DROP TABLE IF EXISTS `guild_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_files` (
  `gno` int(11) NOT NULL DEFAULT '0',
  `gf_no` tinyint(4) NOT NULL AUTO_INCREMENT,
  `file_server` varchar(50) NOT NULL DEFAULT '',
  `file_location` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`gno`,`gf_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_files`
--

LOCK TABLES `guild_files` WRITE;
/*!40000 ALTER TABLE `guild_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_halloffame`
--

DROP TABLE IF EXISTS `guild_halloffame`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_halloffame` (
  `fame_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `guild_name` varchar(40) NOT NULL DEFAULT '',
  `file_url` varchar(128) NOT NULL DEFAULT '0',
  `open_flag` tinyint(4) NOT NULL DEFAULT '0',
  `main_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fame_id`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_halloffame`
--

LOCK TABLES `guild_halloffame` WRITE;
/*!40000 ALTER TABLE `guild_halloffame` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_halloffame` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_halloffame_html`
--

DROP TABLE IF EXISTS `guild_halloffame_html`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_halloffame_html` (
  `fame_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `html` text NOT NULL,
  PRIMARY KEY (`fame_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_halloffame_html`
--

LOCK TABLES `guild_halloffame_html` WRITE;
/*!40000 ALTER TABLE `guild_halloffame_html` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_halloffame_html` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_info`
--

DROP TABLE IF EXISTS `guild_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_info` (
  `guild_id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `guild_name` varchar(40) NOT NULL DEFAULT '',
  `master_id` int(11) NOT NULL DEFAULT '0',
  `master_no` int(11) NOT NULL DEFAULT '0',
  `master_name` varchar(20) NOT NULL DEFAULT '',
  `guild_url` varchar(40) NOT NULL DEFAULT '',
  `guild_icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lev` int(11) NOT NULL DEFAULT '0',
  `ability` tinyint(4) NOT NULL DEFAULT '0',
  `expire_flag` tinyint(4) NOT NULL DEFAULT '0',
  `expire_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_secede_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_count` int(11) NOT NULL DEFAULT '0',
  `recommend_flag` tinyint(4) NOT NULL DEFAULT '0',
  `recommend_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `guild_point` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_point_acc` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_point_prev` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_rank` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_war_point` int(10) unsigned NOT NULL DEFAULT '0',
  `final_entry` smallint(5) unsigned NOT NULL DEFAULT '0',
  `final_win` smallint(5) unsigned NOT NULL DEFAULT '0',
  `guild_icon_auth` tinyint(4) NOT NULL DEFAULT '0',
  `guild_exp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild_id`) USING BTREE,
  KEY `idx_server_id` (`server_id`) USING BTREE,
  KEY `idx_guild_name` (`guild_name`) USING BTREE,
  KEY `idx_master_no` (`master_no`) USING BTREE,
  KEY `idx_master_name` (`master_name`) USING BTREE,
  KEY `idx_guild_rank` (`guild_rank`) USING BTREE,
  KEY `idx_guild_point_prev` (`guild_point_prev`) USING BTREE,
  KEY `idx_guild_point_acc` (`guild_point_acc`) USING BTREE,
  KEY `idx_member_count` (`member_count`) USING BTREE,
  KEY `idx_expire_flag` (`expire_flag`) USING BTREE,
  KEY `idx_guild_point` (`guild_point`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_info`
--

LOCK TABLES `guild_info` WRITE;
/*!40000 ALTER TABLE `guild_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_introduce`
--

DROP TABLE IF EXISTS `guild_introduce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_introduce` (
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `introduce` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`guild_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_introduce`
--

LOCK TABLES `guild_introduce` WRITE;
/*!40000 ALTER TABLE `guild_introduce` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_introduce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member`
--

DROP TABLE IF EXISTS `guild_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member` (
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `nick_name` varchar(12) NOT NULL DEFAULT '',
  `grade` tinyint(4) NOT NULL DEFAULT '0',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `grow_type` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '0',
  `age` tinyint(4) NOT NULL DEFAULT '0',
  `born_year` varchar(2) NOT NULL DEFAULT '',
  `sex` char(1) NOT NULL DEFAULT '',
  `apply_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_flag` tinyint(4) NOT NULL DEFAULT '0',
  `bbs_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_visit_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `secede_type` tinyint(4) NOT NULL DEFAULT '0',
  `secede_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_point` int(10) unsigned NOT NULL DEFAULT '0',
  `member_point_prev` int(10) unsigned NOT NULL DEFAULT '0',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`guild_id`,`charac_no`) USING BTREE,
  KEY `idx_guild_id` (`guild_id`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE,
  KEY `idx_last_visit_time` (`last_visit_time`) USING BTREE,
  KEY `idx_apply_time` (`apply_time`) USING BTREE,
  KEY `idx_secede_type` (`secede_type`) USING BTREE,
  KEY `idx_secede_time` (`secede_time`) USING BTREE,
  KEY `idx_member_flag` (`member_flag`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_member_time` (`member_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member`
--

LOCK TABLES `guild_member` WRITE;
/*!40000 ALTER TABLE `guild_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member_introduce`
--

DROP TABLE IF EXISTS `guild_member_introduce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member_introduce` (
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `introduce` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`guild_id`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member_introduce`
--

LOCK TABLES `guild_member_introduce` WRITE;
/*!40000 ALTER TABLE `guild_member_introduce` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member_introduce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_rank`
--

DROP TABLE IF EXISTS `guild_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_rank` (
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `guild_name` varchar(40) NOT NULL DEFAULT '0',
  `guild_Rank` smallint(5) unsigned NOT NULL DEFAULT '0',
  `guild_point` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_acc_point` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_acc_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_member` smallint(5) unsigned NOT NULL DEFAULT '0',
  `guild_acc_member` smallint(5) unsigned NOT NULL DEFAULT '0',
  `guild_avg_lev` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`server_id`,`guild_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_rank`
--

LOCK TABLES `guild_rank` WRITE;
/*!40000 ALTER TABLE `guild_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_recommend`
--

DROP TABLE IF EXISTS `guild_recommend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_recommend` (
  `no` int(11) NOT NULL DEFAULT '0',
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `comment` varchar(100) NOT NULL DEFAULT '',
  `recommend_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_guild_id` (`guild_id`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_recommend`
--

LOCK TABLES `guild_recommend` WRITE;
/*!40000 ALTER TABLE `guild_recommend` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_recommend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_stat`
--

DROP TABLE IF EXISTS `guild_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_stat` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `create_no` int(11) NOT NULL DEFAULT '0',
  `acc_create_no` int(11) NOT NULL DEFAULT '0',
  `member_no` int(11) NOT NULL DEFAULT '0',
  `acc_member_no` int(11) NOT NULL DEFAULT '0',
  `avg_lev` float NOT NULL DEFAULT '0',
  `avg_master_lev` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`lev`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_stat`
--

LOCK TABLES `guild_stat` WRITE;
/*!40000 ALTER TABLE `guild_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_stat_month`
--

DROP TABLE IF EXISTS `guild_stat_month`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_stat_month` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `lev` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `avg_guild_point` int(11) NOT NULL DEFAULT '0',
  `avg_guild_point_acc` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_date`,`lev`,`server_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_stat_month`
--

LOCK TABLES `guild_stat_month` WRITE;
/*!40000 ALTER TABLE `guild_stat_month` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_stat_month` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_visit`
--

DROP TABLE IF EXISTS `guild_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_visit` (
  `guild_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `total_visit` int(11) NOT NULL DEFAULT '0',
  `today_visit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guild_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_visit`
--

LOCK TABLES `guild_visit` WRITE;
/*!40000 ALTER TABLE `guild_visit` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limit_create_character`
--

DROP TABLE IF EXISTS `limit_create_character`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limit_create_character` (
  `m_id` int(11) unsigned NOT NULL DEFAULT '0',
  `count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_access_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limit_create_character`
--

LOCK TABLES `limit_create_character` WRITE;
/*!40000 ALTER TABLE `limit_create_character` DISABLE KEYS */;
/*!40000 ALTER TABLE `limit_create_character` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`game`@`%`*/ /*!50003 TRIGGER `update_limit_create_character` BEFORE UPDATE ON `limit_create_character` FOR EACH ROW IF new.count =2 THEN
SET new.count = 0;
END IF */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `limit_create_character_ip`
--

DROP TABLE IF EXISTS `limit_create_character_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limit_create_character_ip` (
  `ip` int(11) unsigned NOT NULL DEFAULT '0',
  `ip_str` char(16) NOT NULL DEFAULT '',
  `last_access_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_access_mid` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limit_create_character_ip`
--

LOCK TABLES `limit_create_character_ip` WRITE;
/*!40000 ALTER TABLE `limit_create_character_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `limit_create_character_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limited_shop_manager`
--

DROP TABLE IF EXISTS `limited_shop_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limited_shop_manager` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ipg_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_no` int(10) unsigned NOT NULL DEFAULT '0',
  `item_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `cera_price` int(10) unsigned NOT NULL DEFAULT '0',
  `gold_price` int(10) unsigned NOT NULL DEFAULT '0',
  `avatar_period_type` tinyint(4) NOT NULL DEFAULT '-1',
  `total_cnt` int(11) NOT NULL DEFAULT '0',
  `sell_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `restrict_no` int(10) unsigned NOT NULL DEFAULT '0',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `real_end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `npc_idx` int(10) unsigned NOT NULL DEFAULT '0',
  `cond_charac_job` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cond_lev_begin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cond_lev_end` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cond_acc_create_time_begin` int(10) unsigned NOT NULL DEFAULT '0',
  `cond_acc_create_time_end` int(10) unsigned NOT NULL DEFAULT '0',
  `cond_cha_create_time_begin` int(10) unsigned NOT NULL DEFAULT '0',
  `cond_cha_create_time_end` int(10) unsigned NOT NULL DEFAULT '0',
  `status_flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `range_section` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reason_etc` varchar(200) NOT NULL DEFAULT '',
  `reason_stop` varchar(200) NOT NULL DEFAULT '',
  `pos_flag` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`,`server_id`,`ipg_no`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE,
  KEY `idx_server_id` (`server_id`) USING BTREE,
  KEY `idx_restrict_no` (`restrict_no`) USING BTREE,
  KEY `idx_status_flag` (`status_flag`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limited_shop_manager`
--

LOCK TABLES `limited_shop_manager` WRITE;
/*!40000 ALTER TABLE `limited_shop_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `limited_shop_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_withdraw`
--

DROP TABLE IF EXISTS `m_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_withdraw` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(6) NOT NULL DEFAULT '',
  `user_name` varchar(5) NOT NULL DEFAULT '',
  `first_ssn` varchar(3) NOT NULL DEFAULT '',
  `second_ssn` varchar(3) NOT NULL DEFAULT '',
  `passwd` varchar(8) NOT NULL DEFAULT '',
  `mobile_no` varchar(7) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(25) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(15) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  `w_type` smallint(6) NOT NULL DEFAULT '0',
  `w_cause` varchar(100) NOT NULL DEFAULT '',
  `w_date` int(11) NOT NULL DEFAULT '0',
  `nickname` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_withdraw`
--

LOCK TABLES `m_withdraw` WRITE;
/*!40000 ALTER TABLE `m_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `m_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `max_count`
--

DROP TABLE IF EXISTS `max_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `max_count` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mc_max` int(11) unsigned NOT NULL DEFAULT '0',
  `mc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `idx_mc_date` (`mc_date`) USING BTREE,
  KEY `idx_server_info` (`server_info`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `max_count`
--

LOCK TABLES `max_count` WRITE;
/*!40000 ALTER TABLE `max_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `max_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `max_count_channel`
--

DROP TABLE IF EXISTS `max_count_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `max_count_channel` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gc_channeltype` varchar(25) NOT NULL DEFAULT '',
  `mc_max` int(11) unsigned NOT NULL DEFAULT '0',
  `mc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `idx_mc_date` (`mc_date`) USING BTREE,
  KEY `idx_server_info` (`server_info`,`gc_channeltype`) USING BTREE,
  KEY `idx_gc_channeltype` (`gc_channeltype`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `max_count_channel`
--

LOCK TABLES `max_count_channel` WRITE;
/*!40000 ALTER TABLE `max_count_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `max_count_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `max_count_pvp`
--

DROP TABLE IF EXISTS `max_count_pvp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `max_count_pvp` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mc_max` int(11) unsigned NOT NULL DEFAULT '0',
  `mc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `idx_mc_date` (`mc_date`) USING BTREE,
  KEY `idx_server_info` (`server_info`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `max_count_pvp`
--

LOCK TABLES `max_count_pvp` WRITE;
/*!40000 ALTER TABLE `max_count_pvp` DISABLE KEYS */;
/*!40000 ALTER TABLE `max_count_pvp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `max_count_v2`
--

DROP TABLE IF EXISTS `max_count_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `max_count_v2` (
  `server_info` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `num_occupations_charscreen` int(10) unsigned NOT NULL DEFAULT '0',
  `num_occupations_seriaroom` int(10) unsigned NOT NULL DEFAULT '0',
  `num_login_per_min` int(10) unsigned NOT NULL DEFAULT '0',
  `num_logout_per_min` int(10) unsigned NOT NULL DEFAULT '0',
  `mc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `mc_date` (`mc_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `max_count_v2`
--

LOCK TABLES `max_count_v2` WRITE;
/*!40000 ALTER TABLE `max_count_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `max_count_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_abnomal`
--

DROP TABLE IF EXISTS `member_abnomal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_abnomal` (
  `user_id` varchar(12) NOT NULL DEFAULT '',
  `overlab_count` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_abnomal`
--

LOCK TABLES `member_abnomal` WRITE;
/*!40000 ALTER TABLE `member_abnomal` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_abnomal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_broadcast`
--

DROP TABLE IF EXISTS `member_broadcast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_broadcast` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`m_id`,`server_id`,`charac_no`,`start_time`) USING BTREE,
  UNIQUE KEY `charac_name` (`charac_name`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_broadcast`
--

LOCK TABLES `member_broadcast` WRITE;
/*!40000 ALTER TABLE `member_broadcast` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_broadcast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_captcha_info`
--

DROP TABLE IF EXISTS `member_captcha_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_captcha_info` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cert_time` int(10) unsigned NOT NULL DEFAULT '0',
  `fail_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_captcha_info`
--

LOCK TABLES `member_captcha_info` WRITE;
/*!40000 ALTER TABLE `member_captcha_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_captcha_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_handicap`
--

DROP TABLE IF EXISTS `member_handicap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_handicap` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `cap_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `server_id` tinyint(4) NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `handicap_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`,`cap_type`,`server_id`,`m_id`,`start_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_handicap`
--

LOCK TABLES `member_handicap` WRITE;
/*!40000 ALTER TABLE `member_handicap` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_handicap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info`
--

DROP TABLE IF EXISTS `member_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) DEFAULT NULL,
  `user_name` varchar(10) NOT NULL DEFAULT '',
  `first_ssn` varchar(6) NOT NULL DEFAULT '',
  `second_ssn` varchar(7) NOT NULL DEFAULT '',
  `passwd` varchar(32) NOT NULL DEFAULT '',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(30) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `nickname` varchar(16) NOT NULL DEFAULT '',
  `email_yn` enum('y','n') NOT NULL DEFAULT 'y',
  `ssn_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(10) unsigned NOT NULL DEFAULT '8',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hangame_flag` tinyint(4) NOT NULL DEFAULT '0',
  `hanmon_flag` tinyint(4) NOT NULL DEFAULT '0',
  `m_type` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE,
  KEY `idx_ssn` (`first_ssn`,`second_ssn`) USING BTREE,
  KEY `idx_nick` (`nickname`) USING BTREE,
  KEY `idx_userid` (`user_id`) USING BTREE,
  KEY `idx_user_name` (`user_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info`
--

LOCK TABLES `member_info` WRITE;
/*!40000 ALTER TABLE `member_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info_detail`
--

DROP TABLE IF EXISTS `member_info_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info_detail` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `zipcode` varchar(7) NOT NULL DEFAULT '',
  `address` varchar(80) NOT NULL DEFAULT '',
  `address_detail` varchar(70) NOT NULL DEFAULT '',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info_detail`
--

LOCK TABLES `member_info_detail` WRITE;
/*!40000 ALTER TABLE `member_info_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info_euckr`
--

DROP TABLE IF EXISTS `member_info_euckr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info_euckr` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) DEFAULT NULL,
  `user_name` varchar(10) NOT NULL DEFAULT '',
  `first_ssn` varchar(6) NOT NULL DEFAULT '',
  `second_ssn` varchar(7) NOT NULL DEFAULT '',
  `passwd` varchar(32) NOT NULL DEFAULT '',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(30) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `nickname` varchar(16) NOT NULL DEFAULT '',
  `email_yn` enum('y','n') NOT NULL DEFAULT 'y',
  `ssn_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(10) unsigned NOT NULL DEFAULT '8',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hangame_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE,
  KEY `idx_ssn` (`first_ssn`,`second_ssn`) USING BTREE,
  KEY `idx_nick` (`nickname`) USING BTREE,
  KEY `idx_userid` (`user_id`) USING BTREE,
  KEY `idx_user_name` (`user_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=euckr ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info_euckr`
--

LOCK TABLES `member_info_euckr` WRITE;
/*!40000 ALTER TABLE `member_info_euckr` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info_euckr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info_mileage`
--

DROP TABLE IF EXISTS `member_info_mileage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info_mileage` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) DEFAULT NULL,
  `user_name` varchar(10) NOT NULL DEFAULT '',
  `first_ssn` varchar(6) NOT NULL DEFAULT '',
  `second_ssn` varchar(7) NOT NULL DEFAULT '',
  `passwd` varchar(32) NOT NULL DEFAULT '',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(30) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `nickname` varchar(16) NOT NULL DEFAULT '',
  `email_yn` enum('y','n') NOT NULL DEFAULT 'y',
  `ssn_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(10) unsigned NOT NULL DEFAULT '8',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hangame_flag` tinyint(4) NOT NULL DEFAULT '0',
  `hanmon_flag` tinyint(4) NOT NULL DEFAULT '0',
  `mileage` int(11) DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE,
  KEY `idx_ssn` (`first_ssn`,`second_ssn`) USING BTREE,
  KEY `idx_nick` (`nickname`) USING BTREE,
  KEY `idx_userid` (`user_id`) USING BTREE,
  KEY `idx_user_name` (`user_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info_mileage`
--

LOCK TABLES `member_info_mileage` WRITE;
/*!40000 ALTER TABLE `member_info_mileage` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info_mileage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info_old`
--

DROP TABLE IF EXISTS `member_info_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info_old` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) DEFAULT NULL,
  `user_name` varchar(5) NOT NULL DEFAULT '',
  `first_ssn` varchar(10) DEFAULT NULL,
  `second_ssn` varchar(10) DEFAULT NULL,
  `passwd` varchar(8) NOT NULL DEFAULT '',
  `mobile_no` varchar(8) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(25) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(15) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `nickname` varchar(8) NOT NULL DEFAULT '',
  `email_yn` enum('y','n') NOT NULL DEFAULT 'y',
  `ssn_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE,
  KEY `idx_ssn` (`first_ssn`,`second_ssn`) USING BTREE,
  KEY `idx_nick` (`nickname`) USING BTREE,
  KEY `idx_userid` (`user_id`) USING BTREE,
  KEY `idx_user_name` (`user_name`) USING BTREE,
  KEY `first_ssn` (`first_ssn`) USING BTREE,
  KEY `second_ssn` (`second_ssn`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info_old`
--

LOCK TABLES `member_info_old` WRITE;
/*!40000 ALTER TABLE `member_info_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info_utf8`
--

DROP TABLE IF EXISTS `member_info_utf8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_info_utf8` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `user_id` varchar(30) DEFAULT NULL,
  `user_name` varchar(10) NOT NULL DEFAULT '',
  `first_ssn` varchar(6) NOT NULL DEFAULT '',
  `second_ssn` varchar(7) NOT NULL DEFAULT '',
  `passwd` varchar(32) NOT NULL DEFAULT '',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_answer` varchar(30) NOT NULL DEFAULT '',
  `updt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `nickname` varchar(16) NOT NULL DEFAULT '',
  `email_yn` enum('y','n') NOT NULL DEFAULT 'y',
  `ssn_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` int(10) unsigned NOT NULL DEFAULT '8',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hangame_flag` tinyint(4) NOT NULL DEFAULT '0',
  `hanmon_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE,
  KEY `idx_ssn` (`first_ssn`,`second_ssn`) USING BTREE,
  KEY `idx_nick` (`nickname`) USING BTREE,
  KEY `idx_userid` (`user_id`) USING BTREE,
  KEY `idx_user_name` (`user_name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info_utf8`
--

LOCK TABLES `member_info_utf8` WRITE;
/*!40000 ALTER TABLE `member_info_utf8` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info_utf8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_join_info`
--

DROP TABLE IF EXISTS `member_join_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_join_info` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `contry_code` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `login_time` int(11) NOT NULL DEFAULT '0',
  `error_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `login_ip` varchar(15) NOT NULL DEFAULT '',
  `game_use_history` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE,
  KEY `idx_reg_date` (`reg_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_join_info`
--

LOCK TABLES `member_join_info` WRITE;
/*!40000 ALTER TABLE `member_join_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_join_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_lioness`
--

DROP TABLE IF EXISTS `member_lioness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_lioness` (
  `user_id` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_lioness`
--

LOCK TABLES `member_lioness` WRITE;
/*!40000 ALTER TABLE `member_lioness` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_lioness` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_miles`
--

DROP TABLE IF EXISTS `member_miles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_miles` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `miles` int(11) NOT NULL DEFAULT '0',
  `daily_miles` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_miles`
--

LOCK TABLES `member_miles` WRITE;
/*!40000 ALTER TABLE `member_miles` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_miles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_mouse_sms`
--

DROP TABLE IF EXISTS `member_mouse_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_mouse_sms` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_mouse_sms`
--

LOCK TABLES `member_mouse_sms` WRITE;
/*!40000 ALTER TABLE `member_mouse_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_mouse_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_passwd_mod`
--

DROP TABLE IF EXISTS `member_passwd_mod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_passwd_mod` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `first_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_passwd_mod`
--

LOCK TABLES `member_passwd_mod` WRITE;
/*!40000 ALTER TABLE `member_passwd_mod` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_passwd_mod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_premium_history`
--

DROP TABLE IF EXISTS `member_premium_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_premium_history` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `pre_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `service_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `service_end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`event_id`,`pre_type`,`m_id`,`service_start`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_premium_history`
--

LOCK TABLES `member_premium_history` WRITE;
/*!40000 ALTER TABLE `member_premium_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_premium_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_premium_notuse`
--

DROP TABLE IF EXISTS `member_premium_notuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_premium_notuse` (
  `event_id` int(11) NOT NULL DEFAULT '0',
  `pre_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `service_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `service_end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`,`pre_type`,`server_id`,`m_id`,`service_start`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_premium_notuse`
--

LOCK TABLES `member_premium_notuse` WRITE;
/*!40000 ALTER TABLE `member_premium_notuse` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_premium_notuse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_punish_hack`
--

DROP TABLE IF EXISTS `member_punish_hack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_punish_hack` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `period` int(10) unsigned NOT NULL DEFAULT '0',
  `now_flag` tinyint(4) NOT NULL DEFAULT '0',
  `auto_flag` tinyint(4) NOT NULL DEFAULT '0',
  `reason` varchar(250) NOT NULL DEFAULT '',
  `hack_ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_punish_hack`
--

LOCK TABLES `member_punish_hack` WRITE;
/*!40000 ALTER TABLE `member_punish_hack` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_punish_hack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_punish_hack_history`
--

DROP TABLE IF EXISTS `member_punish_hack_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_punish_hack_history` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` int(10) unsigned NOT NULL DEFAULT '0',
  `period` int(10) unsigned NOT NULL DEFAULT '0',
  `now_flag` tinyint(4) NOT NULL DEFAULT '0',
  `auto_flag` tinyint(4) NOT NULL DEFAULT '0',
  `reason` varchar(250) NOT NULL DEFAULT '',
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_punish_hack_history`
--

LOCK TABLES `member_punish_hack_history` WRITE;
/*!40000 ALTER TABLE `member_punish_hack_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_punish_hack_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_punish_info`
--

DROP TABLE IF EXISTS `member_punish_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_punish_info` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `punish_type` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `punish_value` int(11) NOT NULL DEFAULT '0',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin_id` varchar(25) NOT NULL DEFAULT '',
  `reason` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`,`punish_type`) USING BTREE,
  KEY `idx1` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_punish_info`
--

LOCK TABLES `member_punish_info` WRITE;
/*!40000 ALTER TABLE `member_punish_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_punish_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_punish_info_history`
--

DROP TABLE IF EXISTS `member_punish_info_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_punish_info_history` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL DEFAULT '0',
  `punish_type` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `punish_value` int(11) NOT NULL DEFAULT '0',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin_id` varchar(25) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `is_kicked` tinyint(4) DEFAULT NULL,
  `first_ssn` varchar(32) DEFAULT NULL,
  `second_ssn` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_punish_info_history`
--

LOCK TABLES `member_punish_info_history` WRITE;
/*!40000 ALTER TABLE `member_punish_info_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_punish_info_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_punish_info_history_2016`
--

DROP TABLE IF EXISTS `member_punish_info_history_2016`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_punish_info_history_2016` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL DEFAULT '0',
  `punish_type` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `punish_value` int(11) NOT NULL DEFAULT '0',
  `apply_flag` tinyint(4) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin_id` varchar(25) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `is_kicked` tinyint(4) DEFAULT NULL,
  `first_ssn` varchar(32) DEFAULT NULL,
  `second_ssn` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_punish_info_history_2016`
--

LOCK TABLES `member_punish_info_history_2016` WRITE;
/*!40000 ALTER TABLE `member_punish_info_history_2016` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_punish_info_history_2016` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_safe_ensure`
--

DROP TABLE IF EXISTS `member_safe_ensure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_safe_ensure` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `service_flag` tinyint(4) NOT NULL DEFAULT '0',
  `type1_flag` tinyint(4) NOT NULL DEFAULT '0',
  `type2_flag` tinyint(4) NOT NULL DEFAULT '0',
  `expire_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `settle_id` varchar(18) NOT NULL DEFAULT '',
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_mobile_no` (`mobile_no`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE,
  KEY `idx_expire_time` (`expire_time`) USING BTREE,
  KEY `idx_settle_id` (`settle_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_safe_ensure`
--

LOCK TABLES `member_safe_ensure` WRITE;
/*!40000 ALTER TABLE `member_safe_ensure` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_safe_ensure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_safe_ensure_history`
--

DROP TABLE IF EXISTS `member_safe_ensure_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_safe_ensure_history` (
  `mod_flag` tinyint(4) NOT NULL DEFAULT '0',
  `mod_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mobile_no` varchar(15) NOT NULL DEFAULT '',
  `service_flag` tinyint(4) NOT NULL DEFAULT '0',
  `type1_flag` tinyint(4) NOT NULL DEFAULT '0',
  `type2_flag` tinyint(4) NOT NULL DEFAULT '0',
  `expire_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `settle_id` varchar(18) NOT NULL DEFAULT '',
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_mobile_no` (`mobile_no`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE,
  KEY `idx_expire_time` (`expire_time`) USING BTREE,
  KEY `idx_mod_time` (`mod_time`) USING BTREE,
  KEY `idx_settle_id` (`settle_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_safe_ensure_history`
--

LOCK TABLES `member_safe_ensure_history` WRITE;
/*!40000 ALTER TABLE `member_safe_ensure_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_safe_ensure_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_security_grade`
--

DROP TABLE IF EXISTS `member_security_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_security_grade` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `last_visit_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pass_fail_cnt` int(11) NOT NULL DEFAULT '0',
  `last_vaccine_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_window_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `goblin_pass_mod` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `goblin_fail_cnt` int(11) NOT NULL DEFAULT '0',
  `security_card_reg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `security_card_fail_cnt` int(11) NOT NULL DEFAULT '0',
  `m_opt_reg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pc_opt_reg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `black_ip_try_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `linear_pass_fail_cnt` int(11) NOT NULL DEFAULT '0',
  `last_pass_fail_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_check_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pass_modify_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_pc_reg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gatekeeper_otp_reg` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `goblin_validity_time` int(11) NOT NULL DEFAULT '0',
  `security_card_validity_time` int(11) NOT NULL DEFAULT '0',
  `validity_ip` varchar(15) NOT NULL DEFAULT '',
  `cargopad_status` tinyint(4) NOT NULL DEFAULT '0',
  `cargopad_mod` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cargopad_validity_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE,
  KEY `idx_pass_check` (`last_pass_fail_time`,`linear_pass_fail_cnt`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_security_grade`
--

LOCK TABLES `member_security_grade` WRITE;
/*!40000 ALTER TABLE `member_security_grade` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_security_grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_white_account`
--

DROP TABLE IF EXISTS `member_white_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_white_account` (
  `m_id` int(10) unsigned NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_white_account`
--

LOCK TABLES `member_white_account` WRITE;
/*!40000 ALTER TABLE `member_white_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_white_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_bbs`
--

DROP TABLE IF EXISTS `news_bbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news_bbs` (
  `bbs_code` tinyint(4) NOT NULL DEFAULT '0',
  `emph_yn` tinyint(1) NOT NULL DEFAULT '0',
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(12) NOT NULL DEFAULT '',
  `reg_date` int(11) NOT NULL DEFAULT '0',
  `html_yn` tinyint(1) DEFAULT '0',
  `subject` varchar(50) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `hits` smallint(6) NOT NULL DEFAULT '0',
  `prev_no` int(11) NOT NULL DEFAULT '0',
  `next_no` int(11) NOT NULL DEFAULT '0',
  `updt_date` int(11) DEFAULT NULL,
  `use_yn` tinyint(1) NOT NULL DEFAULT '1',
  `file_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`bbs_code`,`emph_yn`,`no`) USING BTREE,
  UNIQUE KEY `uk_no` (`no`) USING BTREE,
  KEY `idx_prev` (`prev_no`) USING BTREE,
  KEY `idx_next` (`next_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_bbs`
--

LOCK TABLES `news_bbs` WRITE;
/*!40000 ALTER TABLE `news_bbs` DISABLE KEYS */;
/*!40000 ALTER TABLE `news_bbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice` (
  `bbs_name` varchar(10) NOT NULL DEFAULT '',
  `no` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m_nickname` varchar(12) NOT NULL DEFAULT '',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_user_id` varchar(16) NOT NULL DEFAULT '',
  `m_sex` enum('m','f') NOT NULL DEFAULT 'm',
  `title` varchar(120) NOT NULL DEFAULT '',
  `create_day` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` smallint(5) unsigned NOT NULL DEFAULT '0',
  `view` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `recom` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adorn` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `adorn_color1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `adorn_color2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `depth` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sequence` double unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `content_type` enum('br','text','all') NOT NULL DEFAULT 'br',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `ring` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sms` enum('y','n') NOT NULL DEFAULT 'n',
  KEY `idx1` (`bbs_name`) USING BTREE,
  KEY `idx2` (`no`) USING BTREE,
  KEY `idx3` (`sequence`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passwd_mod_entry`
--

DROP TABLE IF EXISTS `passwd_mod_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passwd_mod_entry` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `pre_passwd` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`,`occ_time`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passwd_mod_entry`
--

LOCK TABLES `passwd_mod_entry` WRITE;
/*!40000 ALTER TABLE `passwd_mod_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `passwd_mod_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pswd_qstion`
--

DROP TABLE IF EXISTS `pswd_qstion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pswd_qstion` (
  `q_no` tinyint(4) NOT NULL DEFAULT '0',
  `q_text` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`q_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pswd_qstion`
--

LOCK TABLES `pswd_qstion` WRITE;
/*!40000 ALTER TABLE `pswd_qstion` DISABLE KEYS */;
/*!40000 ALTER TABLE `pswd_qstion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pswd_qstion_direct`
--

DROP TABLE IF EXISTS `pswd_qstion_direct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pswd_qstion_direct` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `q_text` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pswd_qstion_direct`
--

LOCK TABLES `pswd_qstion_direct` WRITE;
/*!40000 ALTER TABLE `pswd_qstion_direct` DISABLE KEYS */;
/*!40000 ALTER TABLE `pswd_qstion_direct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pu_user_list`
--

DROP TABLE IF EXISTS `pu_user_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pu_user_list` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pu_user_list`
--

LOCK TABLES `pu_user_list` WRITE;
/*!40000 ALTER TABLE `pu_user_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `pu_user_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slang_list`
--

DROP TABLE IF EXISTS `slang_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slang_list` (
  `slang` varchar(153) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`slang`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slang_list`
--

LOCK TABLES `slang_list` WRITE;
/*!40000 ALTER TABLE `slang_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `slang_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slang_list_name`
--

DROP TABLE IF EXISTS `slang_list_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slang_list_name` (
  `slang` varchar(153) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`slang`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slang_list_name`
--

LOCK TABLES `slang_list_name` WRITE;
/*!40000 ALTER TABLE `slang_list_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `slang_list_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tme_charac`
--

DROP TABLE IF EXISTS `tme_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tme_charac` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(10) NOT NULL DEFAULT '',
  `village` tinyint(4) NOT NULL DEFAULT '1',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '1',
  `exp` int(11) NOT NULL DEFAULT '0',
  `grow_type` tinyint(4) NOT NULL DEFAULT '0',
  `HP` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `maxHP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `maxMP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `element_resist` tinyblob NOT NULL,
  `spec_property` tinyblob NOT NULL,
  `inven_weight` int(6) NOT NULL DEFAULT '0',
  `hp_regen` smallint(6) NOT NULL DEFAULT '0',
  `mp_regen` smallint(6) NOT NULL DEFAULT '0',
  `move_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `attack_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cast_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `hit_recovery` smallint(6) NOT NULL DEFAULT '0',
  `jump` smallint(6) NOT NULL DEFAULT '0',
  `charac_weight` int(11) NOT NULL DEFAULT '0',
  `fatigue` smallint(11) NOT NULL DEFAULT '0',
  `max_fatigue` smallint(6) NOT NULL DEFAULT '70',
  `premium_fatigue` smallint(11) NOT NULL DEFAULT '0',
  `max_premium_fatigue` smallint(6) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dungeon_clear_point` int(11) NOT NULL DEFAULT '0',
  `delete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `guild_id` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_right` tinyint(4) NOT NULL DEFAULT '0',
  `member_flag` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tme_charac`
--

LOCK TABLES `tme_charac` WRITE;
/*!40000 ALTER TABLE `tme_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `tme_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_charac`
--

DROP TABLE IF EXISTS `tmp_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_charac` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `charac_name` varchar(10) NOT NULL DEFAULT '',
  `village` tinyint(4) NOT NULL DEFAULT '1',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '1',
  `exp` int(11) NOT NULL DEFAULT '0',
  `grow_type` tinyint(4) NOT NULL DEFAULT '0',
  `HP` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `maxHP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `maxMP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `element_resist` tinyblob NOT NULL,
  `spec_property` tinyblob NOT NULL,
  `inven_weight` int(6) NOT NULL DEFAULT '0',
  `hp_regen` smallint(6) NOT NULL DEFAULT '0',
  `mp_regen` smallint(6) NOT NULL DEFAULT '0',
  `move_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `attack_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cast_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `hit_recovery` smallint(6) NOT NULL DEFAULT '0',
  `jump` smallint(6) NOT NULL DEFAULT '0',
  `charac_weight` int(11) NOT NULL DEFAULT '0',
  `fatigue` smallint(11) NOT NULL DEFAULT '0',
  `max_fatigue` smallint(6) NOT NULL DEFAULT '70',
  `premium_fatigue` smallint(11) NOT NULL DEFAULT '0',
  `max_premium_fatigue` smallint(6) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dungeon_clear_point` int(11) NOT NULL DEFAULT '0',
  `delete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `guild_id` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_right` tinyint(4) NOT NULL DEFAULT '0',
  `member_flag` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_charac`
--

LOCK TABLES `tmp_charac` WRITE;
/*!40000 ALTER TABLE `tmp_charac` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmp_charac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `under_age_consent`
--

DROP TABLE IF EXISTS `under_age_consent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `under_age_consent` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `consent_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `limit_money` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `parent_name` varchar(4) NOT NULL DEFAULT '',
  `parent_jumin` bigint(20) unsigned NOT NULL DEFAULT '0',
  `parent_phone1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `parent_phone2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parent_phone3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parent_email` varchar(25) NOT NULL DEFAULT '',
  `parent_consent_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `notice_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `notice_addr` varchar(50) NOT NULL DEFAULT '',
  `create_date` int(10) unsigned NOT NULL DEFAULT '0',
  `consent_date` int(10) unsigned NOT NULL DEFAULT '0',
  `consent_yn` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `history_yn` tinyint(3) unsigned NOT NULL DEFAULT '0',
  KEY `idxid` (`m_id`,`create_date`) USING BTREE,
  KEY `idx_parent_name` (`parent_name`) USING BTREE,
  KEY `idx_parent_email` (`parent_email`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `under_age_consent`
--

LOCK TABLES `under_age_consent` WRITE;
/*!40000 ALTER TABLE `under_age_consent` DISABLE KEYS */;
/*!40000 ALTER TABLE `under_age_consent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `under_billing_confirm`
--

DROP TABLE IF EXISTS `under_billing_confirm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `under_billing_confirm` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_name` varchar(4) NOT NULL DEFAULT '',
  `parent_jumin` bigint(20) unsigned NOT NULL DEFAULT '0',
  `parent_phone1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `parent_phone2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parent_phone3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parent_email` varchar(25) NOT NULL DEFAULT '',
  `parent_consent_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `create_date` int(10) unsigned NOT NULL DEFAULT '0',
  `consent_date` int(10) unsigned NOT NULL DEFAULT '0',
  `consent_yn` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `under_billing_confirm`
--

LOCK TABLES `under_billing_confirm` WRITE;
/*!40000 ALTER TABLE `under_billing_confirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `under_billing_confirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ban`
--

DROP TABLE IF EXISTS `user_ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ban` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` tinyint(4) NOT NULL DEFAULT '1',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ban_term` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ban_reason` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `detail_reason` text NOT NULL,
  `ban_date` int(10) unsigned NOT NULL DEFAULT '0',
  `cancel_reason` text NOT NULL,
  `cancel_date` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `first_ssn` varchar(6) NOT NULL DEFAULT '',
  `second_ssn` varchar(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `ie_m_id` (`m_id`,`status`) USING BTREE,
  KEY `idx_first_ssn` (`first_ssn`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ban`
--

LOCK TABLES `user_ban` WRITE;
/*!40000 ALTER TABLE `user_ban` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'd_taiwan'
--

--
-- Dumping routines for database 'd_taiwan'
--

--
