-- generated from VMDK full dump
-- source_db=taiwan_siroco

--



--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `BID` int(11) NOT NULL AUTO_INCREMENT,
  `BUID` int(11) NOT NULL,
  `BMac_md5` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`BID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_play_info`
--

DROP TABLE IF EXISTS `member_play_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_play_info` (
  `MID` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL,
  `play_count` int(11) NOT NULL,
  `charac_num` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `mac_addr` varchar(50) NOT NULL,
  `ap_number` varchar(50) NOT NULL,
  `sims` varchar(50) NOT NULL,
  `reg_time` date NOT NULL,
  `charac_no` int(11) NOT NULL,
  `charac_name` varchar(20) NOT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY (`MID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_play_info`
--

LOCK TABLES `member_play_info` WRITE;
/*!40000 ALTER TABLE `member_play_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_play_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_cdk`
--

DROP TABLE IF EXISTS `new_cdk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_cdk` (
  `CID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ç¼–å·',
  `CIMEI` int(11) NOT NULL COMMENT 'CDKç¼–å·',
  `CRenum` int(11) NOT NULL COMMENT 'åŒä¸€ç”¨æˆ·é¢†å–æ¬¡æ•°',
  `CTitle` varchar(50) NOT NULL DEFAULT '' COMMENT 'CDKæ ‡é¢˜',
  `CCdk` varchar(50) NOT NULL COMMENT 'CDKå†…å®¹',
  `CCode` varchar(100) NOT NULL COMMENT 'ç‰©å“ä»£ç ',
  `CNumber` varchar(100) NOT NULL COMMENT 'ç‰©å“æ•°é‡',
  `CStreng` varchar(100) NOT NULL COMMENT 'å¼ºåŒ–',
  `CForging` varchar(100) NOT NULL COMMENT 'é”»é€ ',
  `CRedtype` varchar(100) NOT NULL COMMENT 'çº¢å­—ç±»åž‹',
  `CRednum` varchar(100) NOT NULL COMMENT 'çº¢å­—æ•°å€¼',
  `CLock` varchar(100) NOT NULL COMMENT 'æ˜¯å¦å°è£…',
  `CGold` int(11) NOT NULL COMMENT 'é‡‘å¸',
  `CReward` int(11) NOT NULL COMMENT 'é¢†å–ç¤¼åŒ…çš„UID',
  PRIMARY KEY (`CID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_cdk`
--

LOCK TABLES `new_cdk` WRITE;
/*!40000 ALTER TABLE `new_cdk` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_cdk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waigua_feature`
--

DROP TABLE IF EXISTS `waigua_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waigua_feature` (
  `m_id` int(11) NOT NULL,
  `charac_name` varchar(20) NOT NULL,
  `kaigua_time` datetime NOT NULL,
  `test_method` int(11) NOT NULL,
  `kaigua_feature` varchar(256) NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waigua_feature`
--

LOCK TABLES `waigua_feature` WRITE;
/*!40000 ALTER TABLE `waigua_feature` DISABLE KEYS */;
/*!40000 ALTER TABLE `waigua_feature` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-01  3:30:55
