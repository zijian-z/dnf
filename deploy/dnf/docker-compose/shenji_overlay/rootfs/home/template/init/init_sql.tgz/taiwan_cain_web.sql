-- generated from VMDK full dump
-- source_db=taiwan_cain_web

--



--
-- Table structure for table `avatar_select_ability`
--

DROP TABLE IF EXISTS `avatar_select_ability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avatar_select_ability` (
  `it_no` int(11) NOT NULL DEFAULT '0',
  `ability_no` int(11) NOT NULL DEFAULT '0',
  `ability_type` tinyint(4) NOT NULL DEFAULT '0',
  `rate_change` tinyint(4) NOT NULL DEFAULT '0',
  `value` float NOT NULL DEFAULT '0',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `skill_index` int(11) NOT NULL DEFAULT '0',
  `skill_level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`it_no`,`ability_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_select_ability`
--

LOCK TABLES `avatar_select_ability` WRITE;
/*!40000 ALTER TABLE `avatar_select_ability` DISABLE KEYS */;
/*!40000 ALTER TABLE `avatar_select_ability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_aicharacter_info`
--

DROP TABLE IF EXISTS `dnf_aicharacter_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_aicharacter_info` (
  `idx` int(10) unsigned NOT NULL DEFAULT '0',
  `ai_name_kr` varchar(120) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_aicharacter_info`
--

LOCK TABLES `dnf_aicharacter_info` WRITE;
/*!40000 ALTER TABLE `dnf_aicharacter_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_aicharacter_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_artifact_info`
--

DROP TABLE IF EXISTS `dnf_artifact_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_artifact_info` (
  `it_id` int(11) NOT NULL DEFAULT '0',
  `creature_min_level` int(11) NOT NULL DEFAULT '0',
  `physical_attack` int(11) NOT NULL DEFAULT '0',
  `magical_attack` int(11) NOT NULL DEFAULT '0',
  `skill_consume_mp_rate` float NOT NULL DEFAULT '0',
  `skill_charge_time_rate` float NOT NULL DEFAULT '0',
  `skill_overcharge_time_rate` float NOT NULL DEFAULT '0',
  `experience_amount` float NOT NULL DEFAULT '0',
  `physical_critical_hit` float NOT NULL DEFAULT '0',
  `magical_critical_hit` float NOT NULL DEFAULT '0',
  `stuck` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`it_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_artifact_info`
--

LOCK TABLES `dnf_artifact_info` WRITE;
/*!40000 ALTER TABLE `dnf_artifact_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_artifact_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_creature_info`
--

DROP TABLE IF EXISTS `dnf_creature_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_creature_info` (
  `it_id` int(11) NOT NULL DEFAULT '0',
  `creature_id` smallint(6) NOT NULL DEFAULT '0',
  `creature_name` varchar(64) NOT NULL DEFAULT '',
  `skill_recovery_time` int(11) NOT NULL DEFAULT '0',
  `overskill_recovery_time` int(11) NOT NULL DEFAULT '0',
  `artifact_slot` varchar(3) NOT NULL DEFAULT '',
  `learn_overskill_level` smallint(6) NOT NULL DEFAULT '0',
  `skill_info` varchar(32) NOT NULL DEFAULT '',
  `overskill_info` varchar(32) NOT NULL DEFAULT '',
  `piercing` varchar(32) NOT NULL DEFAULT '',
  `skill_name` varchar(32) NOT NULL DEFAULT '',
  `skill_desc` varchar(255) NOT NULL DEFAULT '',
  `overskill_name` varchar(32) NOT NULL DEFAULT '',
  `overskill_desc` varchar(255) NOT NULL DEFAULT '',
  `skill_level_values` varchar(48) NOT NULL DEFAULT '',
  `overskill_level_values` varchar(48) NOT NULL DEFAULT '',
  `evolution_creature_id` smallint(6) NOT NULL DEFAULT '0',
  `evolution_level` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`it_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_creature_info`
--

LOCK TABLES `dnf_creature_info` WRITE;
/*!40000 ALTER TABLE `dnf_creature_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_creature_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_item_info`
--

DROP TABLE IF EXISTS `dnf_item_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_item_info` (
  `it_no` int(10) unsigned NOT NULL DEFAULT '0',
  `it_name` varchar(120) NOT NULL DEFAULT '',
  `it_eng_name` varchar(120) NOT NULL DEFAULT '',
  `it_explain` text NOT NULL,
  `master_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sub_type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `job` varchar(25) NOT NULL DEFAULT '',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `revert` varchar(10) NOT NULL DEFAULT '',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `skill` smallint(5) unsigned NOT NULL DEFAULT '0',
  `create_ratio` float NOT NULL DEFAULT '0',
  `rarity` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `price` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cash` smallint(5) unsigned NOT NULL DEFAULT '0',
  `medal` smallint(5) unsigned NOT NULL DEFAULT '0',
  `durability` smallint(6) NOT NULL DEFAULT '0',
  `cooltime` smallint(6) NOT NULL DEFAULT '0',
  `hp_max` smallint(6) NOT NULL DEFAULT '0',
  `mp_max` smallint(6) NOT NULL DEFAULT '0',
  `phy_att` smallint(6) NOT NULL DEFAULT '0',
  `phy_def` smallint(6) NOT NULL DEFAULT '0',
  `mag_att` smallint(6) NOT NULL DEFAULT '0',
  `mag_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_def` smallint(6) NOT NULL DEFAULT '0',
  `ref_fire` tinyint(4) NOT NULL DEFAULT '0',
  `ref_water` tinyint(4) NOT NULL DEFAULT '0',
  `ref_dark` tinyint(4) NOT NULL DEFAULT '0',
  `ref_light` tinyint(4) NOT NULL DEFAULT '0',
  `ref_all` tinyint(4) NOT NULL DEFAULT '0',
  `ref_slow` tinyint(4) NOT NULL DEFAULT '0',
  `ref_freeze` tinyint(4) NOT NULL DEFAULT '0',
  `ref_poison` tinyint(4) NOT NULL DEFAULT '0',
  `ref_stun` tinyint(4) NOT NULL DEFAULT '0',
  `ref_cus` tinyint(4) NOT NULL DEFAULT '0',
  `ref_blind` tinyint(4) NOT NULL DEFAULT '0',
  `ref_lite` tinyint(4) NOT NULL DEFAULT '0',
  `ref_ston` tinyint(4) NOT NULL DEFAULT '0',
  `ref_sleep` tinyint(4) NOT NULL DEFAULT '0',
  `ref_deekement` tinyint(4) NOT NULL DEFAULT '0',
  `ref_deadlystrike` tinyint(4) NOT NULL DEFAULT '0',
  `ref_bleeding` tinyint(4) NOT NULL DEFAULT '0',
  `ref_confuse` tinyint(4) NOT NULL DEFAULT '0',
  `ref_hold` tinyint(4) NOT NULL DEFAULT '0',
  `ref_all_stat` tinyint(4) NOT NULL DEFAULT '0',
  `ref_pierce` smallint(6) NOT NULL DEFAULT '0',
  `ref_stuck` smallint(6) NOT NULL DEFAULT '0',
  `inven_max` smallint(6) NOT NULL DEFAULT '0',
  `hp_regenrate` smallint(6) NOT NULL DEFAULT '0',
  `mp_regenrate` smallint(6) NOT NULL DEFAULT '0',
  `mov_speed` smallint(6) NOT NULL DEFAULT '0',
  `att_speed` smallint(6) NOT NULL DEFAULT '0',
  `quest` smallint(6) NOT NULL DEFAULT '0',
  `hit_recovery` smallint(6) NOT NULL DEFAULT '0',
  `jump` smallint(6) NOT NULL DEFAULT '0',
  `att_element` enum('','','','','') NOT NULL DEFAULT '',
  `att_active_status` smallint(6) NOT NULL DEFAULT '0',
  `att_active_status_ratio` float NOT NULL DEFAULT '0',
  `att_active_status_pow` smallint(6) NOT NULL DEFAULT '0',
  `att_backforce` smallint(6) NOT NULL DEFAULT '0',
  `att_upforce` smallint(6) NOT NULL DEFAULT '0',
  `att_hp_drain` tinyint(4) NOT NULL DEFAULT '0',
  `att_mp_drain` tinyint(4) NOT NULL DEFAULT '0',
  `criticalhit_rate` float NOT NULL DEFAULT '0',
  `stuck_rate` float NOT NULL DEFAULT '0',
  `att_defenseIgnore` tinyint(4) NOT NULL DEFAULT '0',
  `skill_levelup` varchar(120) NOT NULL DEFAULT '',
  `set_type` enum('n','y') NOT NULL DEFAULT 'n',
  `url` varchar(128) NOT NULL DEFAULT '',
  `jewel_type` varchar(5) NOT NULL DEFAULT '',
  `detail_explain` varchar(255) NOT NULL DEFAULT '',
  `flavor_text` varchar(255) NOT NULL DEFAULT '',
  `anti_evil` int(11) NOT NULL DEFAULT '0',
  `value` int(11) NOT NULL DEFAULT '0',
  `required_skill` int(11) NOT NULL DEFAULT '-1',
  `need_material` varchar(255) NOT NULL DEFAULT '',
  `physical_absolute_damage` int(11) NOT NULL DEFAULT '0',
  `physical_damage_reduce` int(11) NOT NULL DEFAULT '0',
  `physical_absolute_defense` int(11) NOT NULL DEFAULT '0',
  `magical_absolute_damage` int(11) NOT NULL DEFAULT '0',
  `magical_damage_reduce` int(11) NOT NULL DEFAULT '0',
  `magical_absolute_defense` int(11) NOT NULL DEFAULT '0',
  `fire_attack` int(11) NOT NULL DEFAULT '0',
  `water_attack` int(11) NOT NULL DEFAULT '0',
  `dark_attack` int(11) NOT NULL DEFAULT '0',
  `light_attack` int(11) NOT NULL DEFAULT '0',
  `weapon_break_resistance` int(11) NOT NULL DEFAULT '0',
  `armor_break_resistance` int(11) NOT NULL DEFAULT '0',
  `all_activestatus_resistance` int(11) NOT NULL DEFAULT '0',
  `rigidity` int(11) NOT NULL DEFAULT '0',
  `item_aura` varchar(255) NOT NULL DEFAULT '',
  `magical_critical_hit` float NOT NULL DEFAULT '0',
  `set_name` varchar(255) NOT NULL DEFAULT '',
  `set_item` varchar(255) NOT NULL DEFAULT '',
  `fullset_basic_explain` varchar(255) NOT NULL DEFAULT '',
  `fullset_detail_explain` text NOT NULL,
  `parameter_basic_explain` varchar(255) NOT NULL DEFAULT '',
  `parameter_detail_explain` varchar(255) NOT NULL DEFAULT '',
  `part_set_index` int(11) NOT NULL DEFAULT '0',
  `skill_data_up` varchar(255) NOT NULL DEFAULT '',
  `hide_equipment` varchar(33) NOT NULL DEFAULT '',
  `db_piece_count` tinyint(4) NOT NULL DEFAULT '0',
  `set_item_master` int(11) NOT NULL DEFAULT '0',
  `it_set_no` int(10) unsigned NOT NULL DEFAULT '0',
  `ani_variation` text NOT NULL,
  `ani_variation_expand` text NOT NULL,
  `ani_variation2` text NOT NULL,
  `ani_variation_expand2` text NOT NULL,
  `hide_growtype_avatar` varchar(5) NOT NULL DEFAULT '',
  `room_list_move_speed_rate` float NOT NULL DEFAULT '0',
  `icon_mark_number` tinyint(4) NOT NULL DEFAULT '0',
  `extra_icon_idx_list` varchar(8) NOT NULL DEFAULT '',
  `hp_max_rate` float NOT NULL DEFAULT '0',
  `mp_max_rate` float NOT NULL DEFAULT '0',
  `all_attack` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`it_no`,`it_set_no`,`db_piece_count`) USING BTREE,
  KEY `idx_type` (`master_type`,`sub_type`) USING BTREE,
  KEY `idx_rarity` (`rarity`) USING BTREE,
  KEY `idx_level` (`level`) USING BTREE,
  KEY `idx_phy_att` (`phy_att`) USING BTREE,
  KEY `idx_phy_def` (`phy_def`) USING BTREE,
  KEY `idx_mag_att` (`mag_att`) USING BTREE,
  KEY `idx_mag_def` (`mag_def`) USING BTREE,
  KEY `idx_mov_speed` (`mov_speed`) USING BTREE,
  KEY `idx_att_speed` (`att_speed`) USING BTREE,
  KEY `idx_quest` (`quest`) USING BTREE,
  KEY `idx_att_element` (`att_element`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_item_info`
--

LOCK TABLES `dnf_item_info` WRITE;
/*!40000 ALTER TABLE `dnf_item_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_item_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_item_info_master`
--

DROP TABLE IF EXISTS `dnf_item_info_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_item_info_master` (
  `master_no` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sub_no` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `master_explain` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`master_no`,`sub_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_item_info_master`
--

LOCK TABLES `dnf_item_info_master` WRITE;
/*!40000 ALTER TABLE `dnf_item_info_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_item_info_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_item_price`
--

DROP TABLE IF EXISTS `dnf_item_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_item_price` (
  `it_no` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `it_cnt` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cera_price` int(10) unsigned NOT NULL DEFAULT '0',
  `ipg_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipg_no`) USING BTREE,
  KEY `idx1` (`it_no`,`it_cnt`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_item_price`
--

LOCK TABLES `dnf_item_price` WRITE;
/*!40000 ALTER TABLE `dnf_item_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_item_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_monster_info`
--

DROP TABLE IF EXISTS `dnf_monster_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_monster_info` (
  `idx` int(10) unsigned NOT NULL DEFAULT '0',
  `mon_name_kr` varchar(120) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_monster_info`
--

LOCK TABLES `dnf_monster_info` WRITE;
/*!40000 ALTER TABLE `dnf_monster_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_monster_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_old_equip_info`
--

DROP TABLE IF EXISTS `dnf_old_equip_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_old_equip_info` (
  `it_id` int(11) NOT NULL DEFAULT '0',
  `hp_max` smallint(6) NOT NULL DEFAULT '0',
  `mp_max` smallint(6) NOT NULL DEFAULT '0',
  `phy_att` smallint(6) NOT NULL DEFAULT '0',
  `phy_def` smallint(6) NOT NULL DEFAULT '0',
  `mag_att` smallint(6) NOT NULL DEFAULT '0',
  `mag_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_phy_def` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_att` smallint(6) NOT NULL DEFAULT '0',
  `equip_mag_def` smallint(6) NOT NULL DEFAULT '0',
  `ref_fire` smallint(6) NOT NULL DEFAULT '0',
  `ref_water` smallint(6) NOT NULL DEFAULT '0',
  `ref_dark` smallint(6) NOT NULL DEFAULT '0',
  `ref_light` smallint(6) NOT NULL DEFAULT '0',
  `ref_all_elements` smallint(6) NOT NULL DEFAULT '0',
  `ref_slow` smallint(6) NOT NULL DEFAULT '0',
  `ref_freeze` smallint(6) NOT NULL DEFAULT '0',
  `ref_poison` smallint(6) NOT NULL DEFAULT '0',
  `ref_stun` smallint(6) NOT NULL DEFAULT '0',
  `ref_curse` smallint(6) NOT NULL DEFAULT '0',
  `ref_blind` smallint(6) NOT NULL DEFAULT '0',
  `ref_lightning` smallint(6) NOT NULL DEFAULT '0',
  `ref_stone` smallint(6) NOT NULL DEFAULT '0',
  `ref_sleep` smallint(6) NOT NULL DEFAULT '0',
  `ref_burn` smallint(6) NOT NULL DEFAULT '0',
  `ref_weapon_break` smallint(6) NOT NULL DEFAULT '0',
  `ref_bleeding` smallint(6) NOT NULL DEFAULT '0',
  `ref_pierce` smallint(6) NOT NULL DEFAULT '0',
  `ref_stuck` smallint(6) NOT NULL DEFAULT '0',
  `ref_confuse` smallint(6) NOT NULL DEFAULT '0',
  `ref_hold` smallint(6) NOT NULL DEFAULT '0',
  `ref_armor_break` smallint(6) NOT NULL DEFAULT '0',
  `ref_all_state` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`it_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_old_equip_info`
--

LOCK TABLES `dnf_old_equip_info` WRITE;
/*!40000 ALTER TABLE `dnf_old_equip_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_old_equip_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_town_info`
--

DROP TABLE IF EXISTS `dnf_town_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_town_info` (
  `idx` int(10) unsigned NOT NULL DEFAULT '0',
  `town_name_kr` varchar(120) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_town_info`
--

LOCK TABLES `dnf_town_info` WRITE;
/*!40000 ALTER TABLE `dnf_town_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_town_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equip_mapping_info`
--

DROP TABLE IF EXISTS `equip_mapping_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equip_mapping_info` (
  `equip_idx` int(10) unsigned NOT NULL DEFAULT '0',
  `mapping_idx` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`equip_idx`) USING BTREE,
  KEY `mapping_idx` (`mapping_idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equip_mapping_info`
--

LOCK TABLES `equip_mapping_info` WRITE;
/*!40000 ALTER TABLE `equip_mapping_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `equip_mapping_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_level_ref`
--

DROP TABLE IF EXISTS `exp_level_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_level_ref` (
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`exp`) USING BTREE,
  KEY `idx_lev` (`lev`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_level_ref`
--

LOCK TABLES `exp_level_ref` WRITE;
/*!40000 ALTER TABLE `exp_level_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_level_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_board_info`
--

DROP TABLE IF EXISTS `guild_board_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_board_info` (
  `board_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL DEFAULT '0',
  `board_type` tinyint(4) NOT NULL DEFAULT '0',
  `board_name` varchar(50) NOT NULL DEFAULT '',
  `create_day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `seq` tinyint(4) NOT NULL DEFAULT '0',
  `modify_day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_day` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_auth` tinyint(4) NOT NULL DEFAULT '0',
  `content_auth` tinyint(4) NOT NULL DEFAULT '0',
  `write_auth` tinyint(4) NOT NULL DEFAULT '0',
  `comment_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`board_id`) USING BTREE,
  KEY `idx_guild_id` (`guild_id`) USING BTREE,
  KEY `idx_seq` (`seq`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_board_info`
--

LOCK TABLES `guild_board_info` WRITE;
/*!40000 ALTER TABLE `guild_board_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_board_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_memo`
--

DROP TABLE IF EXISTS `guild_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_memo` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guild_id` int(10) unsigned NOT NULL DEFAULT '0',
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `nick_name` varchar(12) NOT NULL DEFAULT '',
  `memo` varchar(120) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `job` tinyint(4) DEFAULT '0',
  `grow_type` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  KEY `idx_guild_id` (`guild_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_memo`
--

LOCK TABLES `guild_memo` WRITE;
/*!40000 ALTER TABLE `guild_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_part_set`
--

DROP TABLE IF EXISTS `item_part_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_part_set` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `part_set_index` int(11) NOT NULL DEFAULT '0',
  `part_name` varchar(255) NOT NULL DEFAULT '',
  `part_type` int(11) NOT NULL DEFAULT '0',
  `part_grade` int(11) NOT NULL DEFAULT '0',
  `part_rarity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idx`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1979 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_part_set`
--

LOCK TABLES `item_part_set` WRITE;
/*!40000 ALTER TABLE `item_part_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_part_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `random_option_ref`
--

DROP TABLE IF EXISTS `random_option_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `random_option_ref` (
  `random_option_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `random_option_value` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `random_option_name` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`random_option_index`,`random_option_value`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `random_option_ref`
--

LOCK TABLES `random_option_ref` WRITE;
/*!40000 ALTER TABLE `random_option_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `random_option_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill_info`
--

DROP TABLE IF EXISTS `skill_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_info` (
  `job_index` int(11) NOT NULL DEFAULT '0',
  `skill_index` int(11) NOT NULL DEFAULT '0',
  `module_type` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `name2` varchar(255) NOT NULL DEFAULT '',
  `basic_explain` varchar(255) NOT NULL DEFAULT '',
  `skill_explain` varchar(255) NOT NULL DEFAULT '',
  `purchase_cost` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `skill_class` int(11) NOT NULL DEFAULT '0',
  `growtype_maximum_level` varchar(255) NOT NULL DEFAULT '',
  `second_growtype_maximum_level` varchar(255) NOT NULL DEFAULT '',
  `skill_fitness_growtype` varchar(255) NOT NULL DEFAULT '',
  `skill_fitness_second_growtype` varchar(255) NOT NULL DEFAULT '',
  `consume_item` varchar(255) NOT NULL DEFAULT '',
  `required_level` tinyint(4) NOT NULL DEFAULT '0',
  `required_level_range` tinyint(4) NOT NULL DEFAULT '0',
  `pre_required_skill` varchar(255) NOT NULL DEFAULT '',
  `consume_mp` varchar(255) NOT NULL DEFAULT '',
  `cool_time` varchar(255) NOT NULL DEFAULT '',
  `casting_time` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `command_key_explain` varchar(255) NOT NULL DEFAULT '',
  `skill_command_advantage` varchar(255) NOT NULL DEFAULT '',
  `static_data` varchar(255) NOT NULL DEFAULT '',
  `level_info` text NOT NULL,
  `start_cool_time` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`job_index`,`skill_index`,`module_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill_info`
--

LOCK TABLES `skill_info` WRITE;
/*!40000 ALTER TABLE `skill_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `skill_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'taiwan_cain_web'
--

--
-- Dumping routines for database 'taiwan_cain_web'
--

--
