-- generated from VMDK full dump
-- source_db=taiwan_cain

--



--
-- Table structure for table `account_cargo`
--

DROP TABLE IF EXISTS `account_cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_cargo` (
  `m_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `money` int(11) unsigned NOT NULL DEFAULT '0',
  `capacity` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cargo` blob NOT NULL,
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_cargo`
--

LOCK TABLES `account_cargo` WRITE;
/*!40000 ALTER TABLE `account_cargo` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_history`
--

DROP TABLE IF EXISTS `auction_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history` (
  `auction_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `occ_time` datetime DEFAULT NULL,
  `event_type` tinyint(4) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `buyer_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seal_flag` tinyint(4) DEFAULT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `add_info` int(11) DEFAULT NULL,
  `upgrade` tinyint(3) unsigned DEFAULT NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `amplify_value` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `seal_cnt` tinyint(3) unsigned DEFAULT NULL,
  `endurance` smallint(5) unsigned DEFAULT NULL,
  `extend_info` int(10) unsigned DEFAULT NULL,
  `owner_postal_id` int(10) unsigned DEFAULT NULL,
  `buyer_postal_id` int(10) unsigned DEFAULT NULL,
  `unit_price` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`auction_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_history`
--

LOCK TABLES `auction_history` WRITE;
/*!40000 ALTER TABLE `auction_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aura_avatar_option`
--

DROP TABLE IF EXISTS `aura_avatar_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aura_avatar_option` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `option_type` tinyint(4) NOT NULL DEFAULT '0',
  `value_1` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`option_type`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aura_avatar_option`
--

LOCK TABLES `aura_avatar_option` WRITE;
/*!40000 ALTER TABLE `aura_avatar_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `aura_avatar_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_market_condition_ctrl`
--

DROP TABLE IF EXISTS `auto_market_condition_ctrl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_market_condition_ctrl` (
  `optimum_gold_supply` bigint(20) unsigned NOT NULL DEFAULT '0',
  `over_gold` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_market_condition_ctrl`
--

LOCK TABLES `auto_market_condition_ctrl` WRITE;
/*!40000 ALTER TABLE `auto_market_condition_ctrl` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_market_condition_ctrl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_market_condition_ctrl_change`
--

DROP TABLE IF EXISTS `auto_market_condition_ctrl_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_market_condition_ctrl_change` (
  `occ_time` date NOT NULL DEFAULT '0000-00-00',
  `total_gold_old` bigint(20) unsigned NOT NULL DEFAULT '0',
  `over_gold_old` bigint(20) unsigned NOT NULL DEFAULT '0',
  `total_gold_new` bigint(20) unsigned NOT NULL DEFAULT '0',
  `over_gold_new` bigint(20) unsigned NOT NULL DEFAULT '0',
  `MNG_user_id` varchar(30) NOT NULL DEFAULT '',
  `memo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_market_condition_ctrl_change`
--

LOCK TABLES `auto_market_condition_ctrl_change` WRITE;
/*!40000 ALTER TABLE `auto_market_condition_ctrl_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_market_condition_ctrl_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_market_condition_ctrl_daily`
--

DROP TABLE IF EXISTS `auto_market_condition_ctrl_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_market_condition_ctrl_daily` (
  `occ_time` date NOT NULL DEFAULT '0000-00-00',
  `total_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `auction_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `over_gold` bigint(20) unsigned NOT NULL DEFAULT '0',
  `optimum_gold_supply` bigint(20) unsigned NOT NULL DEFAULT '0',
  `gold_phase` int(11) NOT NULL DEFAULT '0',
  `item_phase` int(11) NOT NULL DEFAULT '0',
  `durability_phase` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_market_condition_ctrl_daily`
--

LOCK TABLES `auto_market_condition_ctrl_daily` WRITE;
/*!40000 ALTER TABLE `auto_market_condition_ctrl_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_market_condition_ctrl_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blood_dungeon_rank_select`
--

DROP TABLE IF EXISTS `blood_dungeon_rank_select`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blood_dungeon_rank_select` (
  `min_amount` bigint(20) NOT NULL DEFAULT '0',
  `max_amount` bigint(20) NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reward_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `winner_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`min_amount`,`max_amount`,`rank`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blood_dungeon_rank_select`
--

LOCK TABLES `blood_dungeon_rank_select` WRITE;
/*!40000 ALTER TABLE `blood_dungeon_rank_select` DISABLE KEYS */;
/*!40000 ALTER TABLE `blood_dungeon_rank_select` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_occ_info`
--

DROP TABLE IF EXISTS `channel_occ_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_occ_info` (
  `gc_no` int(10) unsigned NOT NULL DEFAULT '0',
  `age` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_num` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gc_no`,`age`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_occ_info`
--

LOCK TABLES `channel_occ_info` WRITE;
/*!40000 ALTER TABLE `channel_occ_info` DISABLE KEYS */;
INSERT INTO `channel_occ_info` VALUES (1052,1,0),(1052,2,0),(1052,3,0),(1052,4,0),(1052,5,0),(1052,6,0),(1052,7,0),(1052,8,0),(1052,9,0),(1052,10,0),(1052,11,0),(1052,12,0),(1052,13,0),(1052,14,0),(1052,15,0),(1052,16,0),(1052,17,0),(1052,18,0),(1052,19,0),(1052,20,0),(1052,21,0),(1052,22,0),(1052,23,0),(1052,24,0),(1052,25,0),(1052,26,0),(1052,27,0),(1052,28,0),(1052,29,0),(1052,30,0),(1052,31,0),(1052,32,0),(1052,33,0),(1052,34,0),(1052,35,0),(1052,36,0),(1052,37,0),(1052,38,0),(1052,39,0),(1052,40,0),(1052,41,0),(1052,42,0),(1052,43,0),(1052,44,0),(1052,45,0),(1052,46,0),(1052,47,0),(1052,48,0),(1052,49,0),(1052,50,0),(1052,51,0),(1052,52,0),(1052,53,0),(1052,54,0),(1052,55,0),(1052,56,0),(1052,57,0),(1052,58,0),(1052,59,0),(1052,60,0),(1052,61,0),(1052,62,0),(1052,63,0),(1052,64,0),(1052,65,0),(1052,66,0),(1052,67,0),(1052,68,0),(1052,69,0),(1052,70,0),(1052,71,0),(1052,72,0),(1052,73,0),(1052,74,0),(1052,75,0),(1052,76,0),(1052,77,0),(1052,78,0),(1052,79,0),(1052,80,0),(1052,81,0),(1052,82,0),(1052,83,0),(1052,84,0),(1052,85,0),(1052,86,0),(1052,87,0),(1052,88,0),(1052,89,0),(1052,90,0),(1052,91,0),(1052,92,0),(1052,93,0),(1052,94,0),(1052,95,0),(1052,96,0),(1052,97,0),(1052,98,0),(1052,99,0),(1052,100,0),(3001,1,0),(3001,2,0),(3001,3,0),(3001,4,0),(3001,5,0),(3001,6,0),(3001,7,0),(3001,8,0),(3001,9,0),(3001,10,0),(3001,11,0),(3001,12,0),(3001,13,0),(3001,14,0),(3001,15,0),(3001,16,0),(3001,17,0),(3001,18,0),(3001,19,0),(3001,20,0),(3001,21,0),(3001,22,0),(3001,23,0),(3001,24,0),(3001,25,0),(3001,26,0),(3001,27,0),(3001,28,0),(3001,29,0),(3001,30,0),(3001,31,0),(3001,32,0),(3001,33,0),(3001,34,0),(3001,35,0),(3001,36,0),(3001,37,0),(3001,38,0),(3001,39,0),(3001,40,0),(3001,41,0),(3001,42,0),(3001,43,0),(3001,44,0),(3001,45,0),(3001,46,0),(3001,47,0),(3001,48,0),(3001,49,0),(3001,50,0),(3001,51,0),(3001,52,0),(3001,53,0),(3001,54,0),(3001,55,0),(3001,56,0),(3001,57,0),(3001,58,0),(3001,59,0),(3001,60,0),(3001,61,0),(3001,62,0),(3001,63,0),(3001,64,0),(3001,65,0),(3001,66,0),(3001,67,0),(3001,68,0),(3001,69,0),(3001,70,0),(3001,71,0),(3001,72,0),(3001,73,0),(3001,74,0),(3001,75,0),(3001,76,0),(3001,77,0),(3001,78,0),(3001,79,0),(3001,80,0),(3001,81,0),(3001,82,0),(3001,83,0),(3001,84,0),(3001,85,0),(3001,86,0),(3001,87,0),(3001,88,0),(3001,89,0),(3001,90,0),(3001,91,0),(3001,92,0),(3001,93,0),(3001,94,0),(3001,95,0),(3001,96,0),(3001,97,0),(3001,98,0),(3001,99,0),(3001,100,0),(3006,1,0),(3006,2,0),(3006,3,0),(3006,4,0),(3006,5,0),(3006,6,0),(3006,7,0),(3006,8,0),(3006,9,0),(3006,10,0),(3006,11,0),(3006,12,0),(3006,13,0),(3006,14,0),(3006,15,0),(3006,16,0),(3006,17,0),(3006,18,0),(3006,19,0),(3006,20,0),(3006,21,0),(3006,22,0),(3006,23,0),(3006,24,0),(3006,25,0),(3006,26,0),(3006,27,0),(3006,28,0),(3006,29,0),(3006,30,0),(3006,31,0),(3006,32,0),(3006,33,0),(3006,34,0),(3006,35,0),(3006,36,0),(3006,37,0),(3006,38,0),(3006,39,0),(3006,40,0),(3006,41,0),(3006,42,0),(3006,43,0),(3006,44,0),(3006,45,0),(3006,46,0),(3006,47,0),(3006,48,0),(3006,49,0),(3006,50,0),(3006,51,0),(3006,52,0),(3006,53,0),(3006,54,0),(3006,55,0),(3006,56,0),(3006,57,0),(3006,58,0),(3006,59,0),(3006,60,0),(3006,61,0),(3006,62,0),(3006,63,0),(3006,64,0),(3006,65,0),(3006,66,0),(3006,67,0),(3006,68,0),(3006,69,0),(3006,70,0),(3006,71,0),(3006,72,0),(3006,73,0),(3006,74,0),(3006,75,0),(3006,76,0),(3006,77,0),(3006,78,0),(3006,79,0),(3006,80,0),(3006,81,0),(3006,82,0),(3006,83,0),(3006,84,0),(3006,85,0),(3006,86,0),(3006,87,0),(3006,88,0),(3006,89,0),(3006,90,0),(3006,91,0),(3006,92,0),(3006,93,0),(3006,94,0),(3006,95,0),(3006,96,0),(3006,97,0),(3006,98,0),(3006,99,0),(3006,100,0),(3011,1,0),(3011,2,0),(3011,3,0),(3011,4,0),(3011,5,0),(3011,6,0),(3011,7,0),(3011,8,0),(3011,9,0),(3011,10,0),(3011,11,0),(3011,12,0),(3011,13,0),(3011,14,0),(3011,15,0),(3011,16,0),(3011,17,0),(3011,18,0),(3011,19,0),(3011,20,0),(3011,21,0),(3011,22,0),(3011,23,0),(3011,24,0),(3011,25,0),(3011,26,0),(3011,27,0),(3011,28,0),(3011,29,0),(3011,30,0),(3011,31,0),(3011,32,0),(3011,33,0),(3011,34,0),(3011,35,0),(3011,36,0),(3011,37,0),(3011,38,0),(3011,39,0),(3011,40,0),(3011,41,0),(3011,42,0),(3011,43,0),(3011,44,0),(3011,45,0),(3011,46,0),(3011,47,0),(3011,48,0),(3011,49,0),(3011,50,0),(3011,51,0),(3011,52,0),(3011,53,0),(3011,54,0),(3011,55,0),(3011,56,0),(3011,57,0),(3011,58,0),(3011,59,0),(3011,60,0),(3011,61,0),(3011,62,0),(3011,63,0),(3011,64,0),(3011,65,0),(3011,66,0),(3011,67,0),(3011,68,0),(3011,69,0),(3011,70,0),(3011,71,0),(3011,72,0),(3011,73,0),(3011,74,0),(3011,75,0),(3011,76,0),(3011,77,0),(3011,78,0),(3011,79,0),(3011,80,0),(3011,81,0),(3011,82,0),(3011,83,0),(3011,84,0),(3011,85,0),(3011,86,0),(3011,87,0),(3011,88,0),(3011,89,0),(3011,90,0),(3011,91,0),(3011,92,0),(3011,93,0),(3011,94,0),(3011,95,0),(3011,96,0),(3011,97,0),(3011,98,0),(3011,99,0),(3011,100,0),(3012,1,0),(3012,2,0),(3012,3,0),(3012,4,0),(3012,5,0),(3012,6,0),(3012,7,0),(3012,8,0),(3012,9,0),(3012,10,0),(3012,11,0),(3012,12,0),(3012,13,0),(3012,14,0),(3012,15,0),(3012,16,0),(3012,17,0),(3012,18,0),(3012,19,0),(3012,20,0),(3012,21,0),(3012,22,0),(3012,23,0),(3012,24,0),(3012,25,0),(3012,26,0),(3012,27,0),(3012,28,0),(3012,29,0),(3012,30,0),(3012,31,0),(3012,32,0),(3012,33,0),(3012,34,0),(3012,35,0),(3012,36,0),(3012,37,0),(3012,38,0),(3012,39,0),(3012,40,0),(3012,41,0),(3012,42,0),(3012,43,0),(3012,44,0),(3012,45,0),(3012,46,0),(3012,47,0),(3012,48,0),(3012,49,0),(3012,50,0),(3012,51,0),(3012,52,0),(3012,53,0),(3012,54,0),(3012,55,0),(3012,56,0),(3012,57,0),(3012,58,0),(3012,59,0),(3012,60,0),(3012,61,0),(3012,62,0),(3012,63,0),(3012,64,0),(3012,65,0),(3012,66,0),(3012,67,0),(3012,68,0),(3012,69,0),(3012,70,0),(3012,71,0),(3012,72,0),(3012,73,0),(3012,74,0),(3012,75,0),(3012,76,0),(3012,77,0),(3012,78,0),(3012,79,0),(3012,80,0),(3012,81,0),(3012,82,0),(3012,83,0),(3012,84,0),(3012,85,0),(3012,86,0),(3012,87,0),(3012,88,0),(3012,89,0),(3012,90,0),(3012,91,0),(3012,92,0),(3012,93,0),(3012,94,0),(3012,95,0),(3012,96,0),(3012,97,0),(3012,98,0),(3012,99,0),(3012,100,0),(3013,1,0),(3013,2,0),(3013,3,0),(3013,4,0),(3013,5,0),(3013,6,0),(3013,7,0),(3013,8,0),(3013,9,0),(3013,10,0),(3013,11,0),(3013,12,0),(3013,13,0),(3013,14,0),(3013,15,0),(3013,16,0),(3013,17,0),(3013,18,0),(3013,19,0),(3013,20,0),(3013,21,0),(3013,22,0),(3013,23,0),(3013,24,0),(3013,25,0),(3013,26,0),(3013,27,0),(3013,28,0),(3013,29,0),(3013,30,0),(3013,31,0),(3013,32,0),(3013,33,0),(3013,34,0),(3013,35,0),(3013,36,0),(3013,37,0),(3013,38,0),(3013,39,0),(3013,40,0),(3013,41,0),(3013,42,0),(3013,43,0),(3013,44,0),(3013,45,0),(3013,46,0),(3013,47,0),(3013,48,0),(3013,49,0),(3013,50,0),(3013,51,0),(3013,52,0),(3013,53,0),(3013,54,0),(3013,55,0),(3013,56,0),(3013,57,0),(3013,58,0),(3013,59,0),(3013,60,0),(3013,61,0),(3013,62,0),(3013,63,0),(3013,64,0),(3013,65,0),(3013,66,0),(3013,67,0),(3013,68,0),(3013,69,0),(3013,70,0),(3013,71,0),(3013,72,0),(3013,73,0),(3013,74,0),(3013,75,0),(3013,76,0),(3013,77,0),(3013,78,0),(3013,79,0),(3013,80,0),(3013,81,0),(3013,82,0),(3013,83,0),(3013,84,0),(3013,85,0),(3013,86,0),(3013,87,0),(3013,88,0),(3013,89,0),(3013,90,0),(3013,91,0),(3013,92,0),(3013,93,0),(3013,94,0),(3013,95,0),(3013,96,0),(3013,97,0),(3013,98,0),(3013,99,0),(3013,100,0),(3016,1,0),(3016,2,0),(3016,3,0),(3016,4,0),(3016,5,0),(3016,6,0),(3016,7,0),(3016,8,0),(3016,9,0),(3016,10,0),(3016,11,0),(3016,12,0),(3016,13,0),(3016,14,0),(3016,15,0),(3016,16,0),(3016,17,0),(3016,18,0),(3016,19,0),(3016,20,0),(3016,21,0),(3016,22,0),(3016,23,0),(3016,24,0),(3016,25,0),(3016,26,0),(3016,27,0),(3016,28,0),(3016,29,0),(3016,30,0),(3016,31,0),(3016,32,0),(3016,33,0),(3016,34,0),(3016,35,0),(3016,36,0),(3016,37,0),(3016,38,0),(3016,39,0),(3016,40,0),(3016,41,0),(3016,42,0),(3016,43,0),(3016,44,0),(3016,45,0),(3016,46,0),(3016,47,0),(3016,48,0),(3016,49,0),(3016,50,0),(3016,51,0),(3016,52,0),(3016,53,0),(3016,54,0),(3016,55,0),(3016,56,0),(3016,57,0),(3016,58,0),(3016,59,0),(3016,60,0),(3016,61,0),(3016,62,0),(3016,63,0),(3016,64,0),(3016,65,0),(3016,66,0),(3016,67,0),(3016,68,0),(3016,69,0),(3016,70,0),(3016,71,0),(3016,72,0),(3016,73,0),(3016,74,0),(3016,75,0),(3016,76,0),(3016,77,0),(3016,78,0),(3016,79,0),(3016,80,0),(3016,81,0),(3016,82,0),(3016,83,0),(3016,84,0),(3016,85,0),(3016,86,0),(3016,87,0),(3016,88,0),(3016,89,0),(3016,90,0),(3016,91,0),(3016,92,0),(3016,93,0),(3016,94,0),(3016,95,0),(3016,96,0),(3016,97,0),(3016,98,0),(3016,99,0),(3016,100,0),(3020,1,0),(3020,2,0),(3020,3,0),(3020,4,0),(3020,5,0),(3020,6,0),(3020,7,0),(3020,8,0),(3020,9,0),(3020,10,0),(3020,11,0),(3020,12,0),(3020,13,0),(3020,14,0),(3020,15,0),(3020,16,0),(3020,17,0),(3020,18,0),(3020,19,0),(3020,20,0),(3020,21,0),(3020,22,0),(3020,23,0),(3020,24,0),(3020,25,0),(3020,26,0),(3020,27,0),(3020,28,0),(3020,29,0),(3020,30,0),(3020,31,0),(3020,32,0),(3020,33,0),(3020,34,0),(3020,35,0),(3020,36,0),(3020,37,0),(3020,38,0),(3020,39,0),(3020,40,0),(3020,41,0),(3020,42,0),(3020,43,0),(3020,44,0),(3020,45,0),(3020,46,0),(3020,47,0),(3020,48,0),(3020,49,0),(3020,50,0),(3020,51,0),(3020,52,0),(3020,53,0),(3020,54,0),(3020,55,0),(3020,56,0),(3020,57,0),(3020,58,0),(3020,59,0),(3020,60,0),(3020,61,0),(3020,62,0),(3020,63,0),(3020,64,0),(3020,65,0),(3020,66,0),(3020,67,0),(3020,68,0),(3020,69,0),(3020,70,0),(3020,71,0),(3020,72,0),(3020,73,0),(3020,74,0),(3020,75,0),(3020,76,0),(3020,77,0),(3020,78,0),(3020,79,0),(3020,80,0),(3020,81,0),(3020,82,0),(3020,83,0),(3020,84,0),(3020,85,0),(3020,86,0),(3020,87,0),(3020,88,0),(3020,89,0),(3020,90,0),(3020,91,0),(3020,92,0),(3020,93,0),(3020,94,0),(3020,95,0),(3020,96,0),(3020,97,0),(3020,98,0),(3020,99,0),(3020,100,0),(3021,1,0),(3021,2,0),(3021,3,0),(3021,4,0),(3021,5,0),(3021,6,0),(3021,7,0),(3021,8,0),(3021,9,0),(3021,10,0),(3021,11,0),(3021,12,0),(3021,13,0),(3021,14,0),(3021,15,0),(3021,16,0),(3021,17,0),(3021,18,0),(3021,19,0),(3021,20,0),(3021,21,0),(3021,22,0),(3021,23,0),(3021,24,0),(3021,25,0),(3021,26,0),(3021,27,0),(3021,28,0),(3021,29,0),(3021,30,0),(3021,31,0),(3021,32,0),(3021,33,0),(3021,34,0),(3021,35,0),(3021,36,0),(3021,37,0),(3021,38,0),(3021,39,0),(3021,40,0),(3021,41,0),(3021,42,0),(3021,43,0),(3021,44,0),(3021,45,0),(3021,46,0),(3021,47,0),(3021,48,0),(3021,49,0),(3021,50,0),(3021,51,0),(3021,52,0),(3021,53,0),(3021,54,0),(3021,55,0),(3021,56,0),(3021,57,0),(3021,58,0),(3021,59,0),(3021,60,0),(3021,61,0),(3021,62,0),(3021,63,0),(3021,64,0),(3021,65,0),(3021,66,0),(3021,67,0),(3021,68,0),(3021,69,0),(3021,70,0),(3021,71,0),(3021,72,0),(3021,73,0),(3021,74,0),(3021,75,0),(3021,76,0),(3021,77,0),(3021,78,0),(3021,79,0),(3021,80,0),(3021,81,0),(3021,82,0),(3021,83,0),(3021,84,0),(3021,85,0),(3021,86,0),(3021,87,0),(3021,88,0),(3021,89,0),(3021,90,0),(3021,91,0),(3021,92,0),(3021,93,0),(3021,94,0),(3021,95,0),(3021,96,0),(3021,97,0),(3021,98,0),(3021,99,0),(3021,100,0),(3024,1,0),(3024,2,0),(3024,3,0),(3024,4,0),(3024,5,0),(3024,6,0),(3024,7,0),(3024,8,0),(3024,9,0),(3024,10,0),(3024,11,0),(3024,12,0),(3024,13,0),(3024,14,0),(3024,15,0),(3024,16,0),(3024,17,0),(3024,18,0),(3024,19,0),(3024,20,0),(3024,21,0),(3024,22,0),(3024,23,0),(3024,24,0),(3024,25,0),(3024,26,0),(3024,27,0),(3024,28,0),(3024,29,0),(3024,30,0),(3024,31,0),(3024,32,0),(3024,33,0),(3024,34,0),(3024,35,0),(3024,36,0),(3024,37,0),(3024,38,0),(3024,39,0),(3024,40,0),(3024,41,0),(3024,42,0),(3024,43,0),(3024,44,0),(3024,45,0),(3024,46,0),(3024,47,0),(3024,48,0),(3024,49,0),(3024,50,0),(3024,51,0),(3024,52,0),(3024,53,0),(3024,54,0),(3024,55,0),(3024,56,0),(3024,57,0),(3024,58,0),(3024,59,0),(3024,60,0),(3024,61,0),(3024,62,0),(3024,63,0),(3024,64,0),(3024,65,0),(3024,66,0),(3024,67,0),(3024,68,0),(3024,69,0),(3024,70,0),(3024,71,0),(3024,72,0),(3024,73,0),(3024,74,0),(3024,75,0),(3024,76,0),(3024,77,0),(3024,78,0),(3024,79,0),(3024,80,0),(3024,81,0),(3024,82,0),(3024,83,0),(3024,84,0),(3024,85,0),(3024,86,0),(3024,87,0),(3024,88,0),(3024,89,0),(3024,90,0),(3024,91,0),(3024,92,0),(3024,93,0),(3024,94,0),(3024,95,0),(3024,96,0),(3024,97,0),(3024,98,0),(3024,99,0),(3024,100,0),(3027,1,0),(3027,2,0),(3027,3,0),(3027,4,0),(3027,5,0),(3027,6,0),(3027,7,0),(3027,8,0),(3027,9,0),(3027,10,0),(3027,11,0),(3027,12,0),(3027,13,0),(3027,14,0),(3027,15,0),(3027,16,0),(3027,17,0),(3027,18,0),(3027,19,0),(3027,20,0),(3027,21,0),(3027,22,0),(3027,23,0),(3027,24,0),(3027,25,0),(3027,26,0),(3027,27,0),(3027,28,0),(3027,29,0),(3027,30,0),(3027,31,0),(3027,32,0),(3027,33,0),(3027,34,0),(3027,35,0),(3027,36,0),(3027,37,0),(3027,38,0),(3027,39,0),(3027,40,0),(3027,41,0),(3027,42,0),(3027,43,0),(3027,44,0),(3027,45,0),(3027,46,0),(3027,47,0),(3027,48,0),(3027,49,0),(3027,50,0),(3027,51,0),(3027,52,0),(3027,53,0),(3027,54,0),(3027,55,0),(3027,56,0),(3027,57,0),(3027,58,0),(3027,59,0),(3027,60,0),(3027,61,0),(3027,62,0),(3027,63,0),(3027,64,0),(3027,65,0),(3027,66,0),(3027,67,0),(3027,68,0),(3027,69,0),(3027,70,0),(3027,71,0),(3027,72,0),(3027,73,0),(3027,74,0),(3027,75,0),(3027,76,0),(3027,77,0),(3027,78,0),(3027,79,0),(3027,80,0),(3027,81,0),(3027,82,0),(3027,83,0),(3027,84,0),(3027,85,0),(3027,86,0),(3027,87,0),(3027,88,0),(3027,89,0),(3027,90,0),(3027,91,0),(3027,92,0),(3027,93,0),(3027,94,0),(3027,95,0),(3027,96,0),(3027,97,0),(3027,98,0),(3027,99,0),(3027,100,0),(3031,1,0),(3031,2,0),(3031,3,0),(3031,4,0),(3031,5,0),(3031,6,0),(3031,7,0),(3031,8,0),(3031,9,0),(3031,10,0),(3031,11,0),(3031,12,0),(3031,13,0),(3031,14,0),(3031,15,0),(3031,16,0),(3031,17,0),(3031,18,0),(3031,19,0),(3031,20,0),(3031,21,0),(3031,22,0),(3031,23,0),(3031,24,0),(3031,25,0),(3031,26,0),(3031,27,0),(3031,28,0),(3031,29,0),(3031,30,0),(3031,31,0),(3031,32,0),(3031,33,0),(3031,34,0),(3031,35,0),(3031,36,0),(3031,37,0),(3031,38,0),(3031,39,0),(3031,40,0),(3031,41,0),(3031,42,0),(3031,43,0),(3031,44,0),(3031,45,0),(3031,46,0),(3031,47,0),(3031,48,0),(3031,49,0),(3031,50,0),(3031,51,0),(3031,52,0),(3031,53,0),(3031,54,0),(3031,55,0),(3031,56,0),(3031,57,0),(3031,58,0),(3031,59,0),(3031,60,0),(3031,61,0),(3031,62,0),(3031,63,0),(3031,64,0),(3031,65,0),(3031,66,0),(3031,67,0),(3031,68,0),(3031,69,0),(3031,70,0),(3031,71,0),(3031,72,0),(3031,73,0),(3031,74,0),(3031,75,0),(3031,76,0),(3031,77,0),(3031,78,0),(3031,79,0),(3031,80,0),(3031,81,0),(3031,82,0),(3031,83,0),(3031,84,0),(3031,85,0),(3031,86,0),(3031,87,0),(3031,88,0),(3031,89,0),(3031,90,0),(3031,91,0),(3031,92,0),(3031,93,0),(3031,94,0),(3031,95,0),(3031,96,0),(3031,97,0),(3031,98,0),(3031,99,0),(3031,100,0),(3033,1,0),(3033,2,0),(3033,3,0),(3033,4,0),(3033,5,0),(3033,6,0),(3033,7,0),(3033,8,0),(3033,9,0),(3033,10,0),(3033,11,0),(3033,12,0),(3033,13,0),(3033,14,0),(3033,15,0),(3033,16,0),(3033,17,0),(3033,18,0),(3033,19,0),(3033,20,0),(3033,21,0),(3033,22,0),(3033,23,0),(3033,24,0),(3033,25,0),(3033,26,0),(3033,27,0),(3033,28,0),(3033,29,0),(3033,30,0),(3033,31,0),(3033,32,0),(3033,33,0),(3033,34,0),(3033,35,0),(3033,36,0),(3033,37,0),(3033,38,0),(3033,39,0),(3033,40,0),(3033,41,0),(3033,42,0),(3033,43,0),(3033,44,0),(3033,45,0),(3033,46,0),(3033,47,0),(3033,48,0),(3033,49,0),(3033,50,0),(3033,51,0),(3033,52,0),(3033,53,0),(3033,54,0),(3033,55,0),(3033,56,0),(3033,57,0),(3033,58,0),(3033,59,0),(3033,60,0),(3033,61,0),(3033,62,0),(3033,63,0),(3033,64,0),(3033,65,0),(3033,66,0),(3033,67,0),(3033,68,0),(3033,69,0),(3033,70,0),(3033,71,0),(3033,72,0),(3033,73,0),(3033,74,0),(3033,75,0),(3033,76,0),(3033,77,0),(3033,78,0),(3033,79,0),(3033,80,0),(3033,81,0),(3033,82,0),(3033,83,0),(3033,84,0),(3033,85,0),(3033,86,0),(3033,87,0),(3033,88,0),(3033,89,0),(3033,90,0),(3033,91,0),(3033,92,0),(3033,93,0),(3033,94,0),(3033,95,0),(3033,96,0),(3033,97,0),(3033,98,0),(3033,99,0),(3033,100,0),(3035,1,0),(3035,2,0),(3035,3,0),(3035,4,0),(3035,5,0),(3035,6,0),(3035,7,0),(3035,8,0),(3035,9,0),(3035,10,0),(3035,11,0),(3035,12,0),(3035,13,0),(3035,14,0),(3035,15,0),(3035,16,0),(3035,17,0),(3035,18,0),(3035,19,0),(3035,20,0),(3035,21,0),(3035,22,0),(3035,23,0),(3035,24,0),(3035,25,0),(3035,26,0),(3035,27,0),(3035,28,0),(3035,29,0),(3035,30,0),(3035,31,0),(3035,32,0),(3035,33,0),(3035,34,0),(3035,35,0),(3035,36,0),(3035,37,0),(3035,38,0),(3035,39,0),(3035,40,0),(3035,41,0),(3035,42,0),(3035,43,0),(3035,44,0),(3035,45,0),(3035,46,0),(3035,47,0),(3035,48,0),(3035,49,0),(3035,50,0),(3035,51,0),(3035,52,0),(3035,53,0),(3035,54,0),(3035,55,0),(3035,56,0),(3035,57,0),(3035,58,0),(3035,59,0),(3035,60,0),(3035,61,0),(3035,62,0),(3035,63,0),(3035,64,0),(3035,65,0),(3035,66,0),(3035,67,0),(3035,68,0),(3035,69,0),(3035,70,0),(3035,71,0),(3035,72,0),(3035,73,0),(3035,74,0),(3035,75,0),(3035,76,0),(3035,77,0),(3035,78,0),(3035,79,0),(3035,80,0),(3035,81,0),(3035,82,0),(3035,83,0),(3035,84,0),(3035,85,0),(3035,86,0),(3035,87,0),(3035,88,0),(3035,89,0),(3035,90,0),(3035,91,0),(3035,92,0),(3035,93,0),(3035,94,0),(3035,95,0),(3035,96,0),(3035,97,0),(3035,98,0),(3035,99,0),(3035,100,0),(3037,1,0),(3037,2,0),(3037,3,0),(3037,4,0),(3037,5,0),(3037,6,0),(3037,7,0),(3037,8,0),(3037,9,0),(3037,10,0),(3037,11,0),(3037,12,0),(3037,13,0),(3037,14,0),(3037,15,0),(3037,16,0),(3037,17,0),(3037,18,0),(3037,19,0),(3037,20,0),(3037,21,0),(3037,22,0),(3037,23,0),(3037,24,0),(3037,25,0),(3037,26,0),(3037,27,0),(3037,28,0),(3037,29,0),(3037,30,0),(3037,31,0),(3037,32,0),(3037,33,0),(3037,34,0),(3037,35,0),(3037,36,0),(3037,37,0),(3037,38,0),(3037,39,0),(3037,40,0),(3037,41,0),(3037,42,0),(3037,43,0),(3037,44,0),(3037,45,0),(3037,46,0),(3037,47,0),(3037,48,0),(3037,49,0),(3037,50,0),(3037,51,0),(3037,52,0),(3037,53,0),(3037,54,0),(3037,55,0),(3037,56,0),(3037,57,0),(3037,58,0),(3037,59,0),(3037,60,0),(3037,61,0),(3037,62,0),(3037,63,0),(3037,64,0),(3037,65,0),(3037,66,0),(3037,67,0),(3037,68,0),(3037,69,0),(3037,70,0),(3037,71,0),(3037,72,0),(3037,73,0),(3037,74,0),(3037,75,0),(3037,76,0),(3037,77,0),(3037,78,0),(3037,79,0),(3037,80,0),(3037,81,0),(3037,82,0),(3037,83,0),(3037,84,0),(3037,85,0),(3037,86,0),(3037,87,0),(3037,88,0),(3037,89,0),(3037,90,0),(3037,91,0),(3037,92,0),(3037,93,0),(3037,94,0),(3037,95,0),(3037,96,0),(3037,97,0),(3037,98,0),(3037,99,0),(3037,100,0),(3039,1,0),(3039,2,0),(3039,3,0),(3039,4,0),(3039,5,0),(3039,6,0),(3039,7,0),(3039,8,0),(3039,9,0),(3039,10,0),(3039,11,0),(3039,12,0),(3039,13,0),(3039,14,0),(3039,15,0),(3039,16,0),(3039,17,0),(3039,18,0),(3039,19,0),(3039,20,0),(3039,21,0),(3039,22,0),(3039,23,0),(3039,24,0),(3039,25,0),(3039,26,0),(3039,27,0),(3039,28,0),(3039,29,0),(3039,30,0),(3039,31,0),(3039,32,0),(3039,33,0),(3039,34,0),(3039,35,0),(3039,36,0),(3039,37,0),(3039,38,0),(3039,39,0),(3039,40,0),(3039,41,0),(3039,42,0),(3039,43,0),(3039,44,0),(3039,45,0),(3039,46,0),(3039,47,0),(3039,48,0),(3039,49,0),(3039,50,0),(3039,51,0),(3039,52,0),(3039,53,0),(3039,54,0),(3039,55,0),(3039,56,0),(3039,57,0),(3039,58,0),(3039,59,0),(3039,60,0),(3039,61,0),(3039,62,0),(3039,63,0),(3039,64,0),(3039,65,0),(3039,66,0),(3039,67,0),(3039,68,0),(3039,69,0),(3039,70,0),(3039,71,0),(3039,72,0),(3039,73,0),(3039,74,0),(3039,75,0),(3039,76,0),(3039,77,0),(3039,78,0),(3039,79,0),(3039,80,0),(3039,81,0),(3039,82,0),(3039,83,0),(3039,84,0),(3039,85,0),(3039,86,0),(3039,87,0),(3039,88,0),(3039,89,0),(3039,90,0),(3039,91,0),(3039,92,0),(3039,93,0),(3039,94,0),(3039,95,0),(3039,96,0),(3039,97,0),(3039,98,0),(3039,99,0),(3039,100,0),(3052,1,0),(3052,2,0),(3052,3,0),(3052,4,0),(3052,5,0),(3052,6,0),(3052,7,0),(3052,8,0),(3052,9,0),(3052,10,0),(3052,11,0),(3052,12,0),(3052,13,0),(3052,14,0),(3052,15,0),(3052,16,0),(3052,17,0),(3052,18,0),(3052,19,0),(3052,20,0),(3052,21,0),(3052,22,0),(3052,23,0),(3052,24,0),(3052,25,0),(3052,26,0),(3052,27,0),(3052,28,0),(3052,29,0),(3052,30,0),(3052,31,0),(3052,32,0),(3052,33,0),(3052,34,0),(3052,35,0),(3052,36,0),(3052,37,0),(3052,38,0),(3052,39,0),(3052,40,0),(3052,41,0),(3052,42,0),(3052,43,0),(3052,44,0),(3052,45,0),(3052,46,0),(3052,47,0),(3052,48,0),(3052,49,0),(3052,50,0),(3052,51,0),(3052,52,0),(3052,53,0),(3052,54,0),(3052,55,0),(3052,56,0),(3052,57,0),(3052,58,0),(3052,59,0),(3052,60,0),(3052,61,0),(3052,62,0),(3052,63,0),(3052,64,0),(3052,65,0),(3052,66,0),(3052,67,0),(3052,68,0),(3052,69,0),(3052,70,0),(3052,71,0),(3052,72,0),(3052,73,0),(3052,74,0),(3052,75,0),(3052,76,0),(3052,77,0),(3052,78,0),(3052,79,0),(3052,80,0),(3052,81,0),(3052,82,0),(3052,83,0),(3052,84,0),(3052,85,0),(3052,86,0),(3052,87,0),(3052,88,0),(3052,89,0),(3052,90,0),(3052,91,0),(3052,92,0),(3052,93,0),(3052,94,0),(3052,95,0),(3052,96,0),(3052,97,0),(3052,98,0),(3052,99,0),(3052,100,0),(3056,1,0),(3056,2,0),(3056,3,0),(3056,4,0),(3056,5,0),(3056,6,0),(3056,7,0),(3056,8,0),(3056,9,0),(3056,10,0),(3056,11,0),(3056,12,0),(3056,13,0),(3056,14,0),(3056,15,0),(3056,16,0),(3056,17,0),(3056,18,0),(3056,19,0),(3056,20,0),(3056,21,0),(3056,22,0),(3056,23,0),(3056,24,0),(3056,25,0),(3056,26,0),(3056,27,0),(3056,28,0),(3056,29,0),(3056,30,0),(3056,31,0),(3056,32,0),(3056,33,0),(3056,34,0),(3056,35,0),(3056,36,0),(3056,37,0),(3056,38,0),(3056,39,0),(3056,40,0),(3056,41,0),(3056,42,0),(3056,43,0),(3056,44,0),(3056,45,0),(3056,46,0),(3056,47,0),(3056,48,0),(3056,49,0),(3056,50,0),(3056,51,0),(3056,52,0),(3056,53,0),(3056,54,0),(3056,55,0),(3056,56,0),(3056,57,0),(3056,58,0),(3056,59,0),(3056,60,0),(3056,61,0),(3056,62,0),(3056,63,0),(3056,64,0),(3056,65,0),(3056,66,0),(3056,67,0),(3056,68,0),(3056,69,0),(3056,70,0),(3056,71,0),(3056,72,0),(3056,73,0),(3056,74,0),(3056,75,0),(3056,76,0),(3056,77,0),(3056,78,0),(3056,79,0),(3056,80,0),(3056,81,0),(3056,82,0),(3056,83,0),(3056,84,0),(3056,85,0),(3056,86,0),(3056,87,0),(3056,88,0),(3056,89,0),(3056,90,0),(3056,91,0),(3056,92,0),(3056,93,0),(3056,94,0),(3056,95,0),(3056,96,0),(3056,97,0),(3056,98,0),(3056,99,0),(3056,100,0);
/*!40000 ALTER TABLE `channel_occ_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_achievement`
--

DROP TABLE IF EXISTS `charac_achievement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_achievement` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `achievement` blob NOT NULL,
  `last_update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_achievement`
--

LOCK TABLES `charac_achievement` WRITE;
/*!40000 ALTER TABLE `charac_achievement` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_achievement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_action_point`
--

DROP TABLE IF EXISTS `charac_action_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_action_point` (
  `occ_date` date NOT NULL DEFAULT '0000-00-00',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `ap_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `is_reward_medal` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reward_item_1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reward_item_2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reward_item_3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_reward_item_4` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ap_clear_state` blob NOT NULL,
  PRIMARY KEY (`charac_no`,`occ_date`) USING BTREE,
  KEY `idx_occ_date` (`occ_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_action_point`
--

LOCK TABLES `charac_action_point` WRITE;
/*!40000 ALTER TABLE `charac_action_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_action_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_action_point_desc`
--

DROP TABLE IF EXISTS `charac_action_point_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_action_point_desc` (
  `action_group_index` int(11) NOT NULL DEFAULT '0',
  `action_index` int(11) NOT NULL DEFAULT '0',
  `action_group_name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`action_group_index`,`action_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_action_point_desc`
--

LOCK TABLES `charac_action_point_desc` WRITE;
/*!40000 ALTER TABLE `charac_action_point_desc` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_action_point_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_best_record`
--

DROP TABLE IF EXISTS `charac_best_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_best_record` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `dungeon_no` smallint(6) NOT NULL DEFAULT '0',
  `difficulty` smallint(6) NOT NULL DEFAULT '0',
  `style` int(11) NOT NULL DEFAULT '0',
  `technic` int(11) NOT NULL DEFAULT '0',
  `attacked` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`dungeon_no`,`difficulty`) USING BTREE,
  KEY `idx_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_best_record`
--

LOCK TABLES `charac_best_record` WRITE;
/*!40000 ALTER TABLE `charac_best_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_best_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_blood_best_record`
--

DROP TABLE IF EXISTS `charac_blood_best_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_blood_best_record` (
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  `dungeon_index` int(11) unsigned NOT NULL DEFAULT '0',
  `best_round` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `best_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`dungeon_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_blood_best_record`
--

LOCK TABLES `charac_blood_best_record` WRITE;
/*!40000 ALTER TABLE `charac_blood_best_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_blood_best_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_blood_dungeon_reward`
--

DROP TABLE IF EXISTS `charac_blood_dungeon_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_blood_dungeon_reward` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `week_occ_date` date NOT NULL DEFAULT '0000-00-00',
  `week_point` int(10) unsigned NOT NULL DEFAULT '0',
  `week_enter_count` int(10) unsigned NOT NULL DEFAULT '0',
  `week_use_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `last_play_date` date NOT NULL DEFAULT '0000-00-00',
  `enter_count` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `reward_gold` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`week_occ_date`) USING BTREE,
  KEY `idx_week_occ_date` (`week_occ_date`) USING BTREE,
  KEY `idx_last_play_date` (`last_play_date`) USING BTREE,
  KEY `idx_reward` (`reward`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_blood_dungeon_reward`
--

LOCK TABLES `charac_blood_dungeon_reward` WRITE;
/*!40000 ALTER TABLE `charac_blood_dungeon_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_blood_dungeon_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_blood_inout`
--

DROP TABLE IF EXISTS `charac_blood_inout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_blood_inout` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `dungeon1` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon2` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon3` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon4` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon5` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon6` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon7` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon8` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon9` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon10` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_blood_inout`
--

LOCK TABLES `charac_blood_inout` WRITE;
/*!40000 ALTER TABLE `charac_blood_inout` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_blood_inout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_cerashop_restrict`
--

DROP TABLE IF EXISTS `charac_cerashop_restrict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_cerashop_restrict` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `ipg_no` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  `next_date` int(10) unsigned NOT NULL DEFAULT '0',
  `end_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_access_date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`ipg_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_cerashop_restrict`
--

LOCK TABLES `charac_cerashop_restrict` WRITE;
/*!40000 ALTER TABLE `charac_cerashop_restrict` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_cerashop_restrict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_dimension_inout`
--

DROP TABLE IF EXISTS `charac_dimension_inout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_dimension_inout` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `dungeon1` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon2` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon3` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon4` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon5` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon6` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon7` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon8` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon9` tinyint(4) NOT NULL DEFAULT '0',
  `dungeon10` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_dimension_inout`
--

LOCK TABLES `charac_dimension_inout` WRITE;
/*!40000 ALTER TABLE `charac_dimension_inout` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_dimension_inout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_dungeon`
--

DROP TABLE IF EXISTS `charac_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_dungeon` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `dungeon` blob NOT NULL,
  `best_clear_time` blob NOT NULL,
  `blue_marble_enter_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_inform_notice` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_dungeon`
--

LOCK TABLES `charac_dungeon` WRITE;
/*!40000 ALTER TABLE `charac_dungeon` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_dungeon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_dungeon_test`
--

DROP TABLE IF EXISTS `charac_dungeon_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_dungeon_test` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `dungeon` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_dungeon_test`
--

LOCK TABLES `charac_dungeon_test` WRITE;
/*!40000 ALTER TABLE `charac_dungeon_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_dungeon_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_expert_job`
--

DROP TABLE IF EXISTS `charac_expert_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_expert_job` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `expert_job_giveup_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expert_job_info` int(11) NOT NULL DEFAULT '0',
  `expert_job_info_ex` int(11) NOT NULL DEFAULT '0',
  `recipe` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_expert_job`
--

LOCK TABLES `charac_expert_job` WRITE;
/*!40000 ALTER TABLE `charac_expert_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_expert_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_friends`
--

DROP TABLE IF EXISTS `charac_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_friends` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `friend_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`,`friend_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_friends`
--

LOCK TABLES `charac_friends` WRITE;
/*!40000 ALTER TABLE `charac_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_housing_info`
--

DROP TABLE IF EXISTS `charac_housing_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_housing_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `installed` smallint(5) unsigned NOT NULL DEFAULT '0',
  `decoration_inven` binary(144) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `version` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_housing_info`
--

LOCK TABLES `charac_housing_info` WRITE;
/*!40000 ALTER TABLE `charac_housing_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_housing_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_housing_tree_info`
--

DROP TABLE IF EXISTS `charac_housing_tree_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_housing_tree_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `tree_id` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `current_point` smallint(6) NOT NULL DEFAULT '0',
  `leaf_point` smallint(6) NOT NULL DEFAULT '0',
  `day_water_count` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_housing_tree_info`
--

LOCK TABLES `charac_housing_tree_info` WRITE;
/*!40000 ALTER TABLE `charac_housing_tree_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_housing_tree_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_housing_water_history`
--

DROP TABLE IF EXISTS `charac_housing_water_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_housing_water_history` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `give_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `give_charac_name` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`charac_no`,`give_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_housing_water_history`
--

LOCK TABLES `charac_housing_water_history` WRITE;
/*!40000 ALTER TABLE `charac_housing_water_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_housing_water_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_info`
--

DROP TABLE IF EXISTS `charac_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_info` (
  `m_id` int(11) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL AUTO_INCREMENT,
  `charac_name` varchar(20) NOT NULL DEFAULT '',
  `village` tinyint(4) NOT NULL DEFAULT '1',
  `job` tinyint(4) NOT NULL DEFAULT '0',
  `lev` tinyint(4) NOT NULL DEFAULT '1',
  `exp` int(11) NOT NULL DEFAULT '0',
  `grow_type` tinyint(4) NOT NULL DEFAULT '0',
  `HP` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `maxHP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `maxMP` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `phy_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_attack` smallint(6) unsigned NOT NULL DEFAULT '0',
  `mag_defense` smallint(6) unsigned NOT NULL DEFAULT '0',
  `element_resist` tinyblob NOT NULL,
  `spec_property` tinyblob NOT NULL,
  `inven_weight` int(6) NOT NULL DEFAULT '0',
  `hp_regen` smallint(6) NOT NULL DEFAULT '0',
  `mp_regen` smallint(6) NOT NULL DEFAULT '0',
  `move_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `attack_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cast_speed` smallint(6) unsigned NOT NULL DEFAULT '0',
  `hit_recovery` smallint(6) NOT NULL DEFAULT '0',
  `jump` smallint(6) NOT NULL DEFAULT '0',
  `charac_weight` int(11) NOT NULL DEFAULT '0',
  `fatigue` smallint(6) NOT NULL DEFAULT '0',
  `max_fatigue` smallint(6) NOT NULL DEFAULT '70',
  `premium_fatigue` smallint(6) NOT NULL DEFAULT '0',
  `max_premium_fatigue` smallint(6) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dungeon_clear_point` int(11) NOT NULL DEFAULT '0',
  `delete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0',
  `guild_id` int(10) unsigned NOT NULL DEFAULT '0',
  `guild_right` tinyint(4) NOT NULL DEFAULT '0',
  `member_flag` tinyint(4) NOT NULL DEFAULT '0',
  `sex` tinyint(4) NOT NULL DEFAULT '1',
  `expert_job` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `skill_tree_index` tinyint(4) NOT NULL DEFAULT '-1',
  `link_charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `event_charac_level` tinyint(4) NOT NULL DEFAULT '0',
  `guild_secede` tinyint(2) NOT NULL DEFAULT '0',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `finish_time` int(11) NOT NULL DEFAULT '0',
  `competition_area` tinyint(2) NOT NULL DEFAULT '-1',
  `competition_period` tinyint(2) NOT NULL DEFAULT '-1',
  `mercenary_start_time` int(11) NOT NULL DEFAULT '0',
  `mercenary_finish_time` int(11) NOT NULL DEFAULT '0',
  `mercenary_area` tinyint(4) NOT NULL DEFAULT '-1',
  `mercenary_period` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`charac_no`) USING BTREE,
  UNIQUE KEY `charac_name` (`charac_name`) USING BTREE,
  KEY `charac_info_idx1` (`m_id`) USING BTREE,
  KEY `charac_info_idx2` (`exp`) USING BTREE,
  KEY `idx_guild_id` (`guild_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_info`
--

LOCK TABLES `charac_info` WRITE;
/*!40000 ALTER TABLE `charac_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_item_stat`
--

DROP TABLE IF EXISTS `charac_item_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_item_stat` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `cooltime_item` blob NOT NULL,
  `effect_item` blob NOT NULL,
  `check_flag` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_item_stat`
--

LOCK TABLES `charac_item_stat` WRITE;
/*!40000 ALTER TABLE `charac_item_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_item_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_kill_monster_info`
--

DROP TABLE IF EXISTS `charac_kill_monster_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_kill_monster_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `boss_info` blob NOT NULL,
  `named_info` blob NOT NULL,
  `apc_boss_info` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE,
  KEY `pk_charac_no` (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_kill_monster_info`
--

LOCK TABLES `charac_kill_monster_info` WRITE;
/*!40000 ALTER TABLE `charac_kill_monster_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_kill_monster_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_link_bonus`
--

DROP TABLE IF EXISTS `charac_link_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_link_bonus` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `gold` int(10) unsigned NOT NULL DEFAULT '0',
  `mercenary_start_time` int(11) NOT NULL DEFAULT '0',
  `mercenary_finish_time` int(11) NOT NULL DEFAULT '0',
  `mercenary_area` tinyint(4) NOT NULL DEFAULT '-1',
  `mercenary_period` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_link_bonus`
--

LOCK TABLES `charac_link_bonus` WRITE;
/*!40000 ALTER TABLE `charac_link_bonus` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_link_bonus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_link_message`
--

DROP TABLE IF EXISTS `charac_link_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_link_message` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_flag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_link_message`
--

LOCK TABLES `charac_link_message` WRITE;
/*!40000 ALTER TABLE `charac_link_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_link_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_manage_info`
--

DROP TABLE IF EXISTS `charac_manage_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_manage_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `tag_charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `striker_skill_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `max_equip_level` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_manage_info`
--

LOCK TABLES `charac_manage_info` WRITE;
/*!40000 ALTER TABLE `charac_manage_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_manage_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_members`
--

DROP TABLE IF EXISTS `charac_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_members` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `master_no` int(11) NOT NULL DEFAULT '0',
  `exp` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delete_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_members`
--

LOCK TABLES `charac_members` WRITE;
/*!40000 ALTER TABLE `charac_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_npc`
--

DROP TABLE IF EXISTS `charac_npc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_npc` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `npc_cnt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `npc_data` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_npc`
--

LOCK TABLES `charac_npc` WRITE;
/*!40000 ALTER TABLE `charac_npc` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_npc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_option`
--

DROP TABLE IF EXISTS `charac_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_option` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `options` blob NOT NULL,
  `best_clear_time` blob NOT NULL,
  `blue_marble_enter_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `charac_inform_notice` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_option`
--

LOCK TABLES `charac_option` WRITE;
/*!40000 ALTER TABLE `charac_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_quest`
--

DROP TABLE IF EXISTS `charac_quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_quest` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `quest_10` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_15` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_20` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_30` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_40` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_40_ext` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_50` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_60` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_70` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_etc` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `play_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_1_trigger` int(11) NOT NULL DEFAULT '0',
  `play_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_2_trigger` int(11) NOT NULL DEFAULT '0',
  `play_3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_3_trigger` int(11) NOT NULL DEFAULT '0',
  `play_4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_4_trigger` int(11) NOT NULL DEFAULT '0',
  `play_5` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_5_trigger` int(11) NOT NULL DEFAULT '0',
  `play_6` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_6_trigger` int(11) NOT NULL DEFAULT '0',
  `play_7` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_7_trigger` int(11) NOT NULL DEFAULT '0',
  `play_8` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_8_trigger` int(11) NOT NULL DEFAULT '0',
  `play_9` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_9_trigger` int(11) NOT NULL DEFAULT '0',
  `play_10` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_10_trigger` int(11) NOT NULL DEFAULT '0',
  `quest_50_ext` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_60_ext` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_etc_ext` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `quest_60_ext_2nd` binary(64) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_quest`
--

LOCK TABLES `charac_quest` WRITE;
/*!40000 ALTER TABLE `charac_quest` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_quest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_quest_ref`
--

DROP TABLE IF EXISTS `charac_quest_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_quest_ref` (
  `origin_idx` int(11) NOT NULL DEFAULT '0',
  `mapped_idx` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`origin_idx`) USING BTREE,
  UNIQUE KEY `mapped_idx` (`mapped_idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_quest_ref`
--

LOCK TABLES `charac_quest_ref` WRITE;
/*!40000 ALTER TABLE `charac_quest_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_quest_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_quest_shop`
--

DROP TABLE IF EXISTS `charac_quest_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_quest_shop` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `qp` int(10) unsigned NOT NULL DEFAULT '0',
  `max_hp` smallint(5) unsigned NOT NULL DEFAULT '0',
  `max_mp` smallint(5) unsigned NOT NULL DEFAULT '0',
  `psy_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `psy_defense` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mag_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mag_defence` smallint(5) unsigned NOT NULL DEFAULT '0',
  `move_speed` smallint(5) unsigned NOT NULL DEFAULT '0',
  `attack_speed` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hp_regen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mp_regen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `all_element_resist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `fire_element_resist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `water_element_resist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `light_element_resist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dark_element_resist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `all_element_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `fire_element_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `water_element_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `light_element_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `dark_element_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `psy_critical` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mag_critical` smallint(5) unsigned NOT NULL DEFAULT '0',
  `good_hit` smallint(5) unsigned NOT NULL DEFAULT '0',
  `evasion` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hit_recovery` smallint(5) unsigned NOT NULL DEFAULT '0',
  `init_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `separate_psy_mag_attack` smallint(5) unsigned NOT NULL DEFAULT '0',
  `quest_piece` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_quest_shop`
--

LOCK TABLES `charac_quest_shop` WRITE;
/*!40000 ALTER TABLE `charac_quest_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_quest_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_ridable_stat`
--

DROP TABLE IF EXISTS `charac_ridable_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_ridable_stat` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `cooltime` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_ridable_stat`
--

LOCK TABLES `charac_ridable_stat` WRITE;
/*!40000 ALTER TABLE `charac_ridable_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_ridable_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_stat`
--

DROP TABLE IF EXISTS `charac_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_stat` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `village` tinyint(4) NOT NULL DEFAULT '1',
  `exp` int(11) NOT NULL DEFAULT '0',
  `HP` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `fatigue` smallint(11) NOT NULL DEFAULT '0',
  `used_fatigue` smallint(11) NOT NULL DEFAULT '0',
  `premium_fatigue` smallint(11) NOT NULL DEFAULT '0',
  `dungeon_clear_point` int(11) NOT NULL DEFAULT '0',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `forbidden_to_play` char(1) NOT NULL DEFAULT '',
  `forbidden_due_to` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tutorial_flag` int(11) NOT NULL DEFAULT '0',
  `trade_gold_total` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_gold_total_billion` smallint(5) unsigned NOT NULL DEFAULT '0',
  `trade_gold_daily` int(10) unsigned NOT NULL DEFAULT '0',
  `dungeon_map_pass_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `dungeon_map_help_pass_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `help_abuse_point` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_point` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_exp` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_mode_count` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_kill_count` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_die_count` int(10) unsigned NOT NULL DEFAULT '0',
  `chaos_die_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `chaos_kill_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `assault_count` int(10) unsigned NOT NULL DEFAULT '0',
  `luck_point` int(11) NOT NULL DEFAULT '5000',
  `dungeon_play_count` int(10) unsigned NOT NULL DEFAULT '0',
  `help_abuse_ratio` int(10) NOT NULL DEFAULT '0',
  `help_abuse_exp` int(10) NOT NULL DEFAULT '0',
  `expert_job_exp` int(11) NOT NULL DEFAULT '0',
  `fatigue_battery_charging` int(11) NOT NULL DEFAULT '0',
  `escalade_tutorial_flag` varchar(32) NOT NULL DEFAULT '',
  `power_war_point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `power_war_assault_count` int(10) unsigned NOT NULL DEFAULT '0',
  `power_war_assault_victory_count` int(10) unsigned NOT NULL DEFAULT '0',
  `fatigue_grownup_buff` int(10) unsigned NOT NULL DEFAULT '0',
  `village_prev` tinyint(4) NOT NULL DEFAULT '1',
  `last_play_time_powerwar` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `emotion` smallint(5) unsigned NOT NULL DEFAULT '0',
  `add_slot_flag` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `member_dungeon_flag` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `open_flag` tinyint(4) NOT NULL DEFAULT '0',
  `member_bonus_fatigue` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `birthday_effect_time` datetime DEFAULT '0000-00-00 00:00:00',
  `visible_flags` tinyint(4) unsigned NOT NULL DEFAULT '2',
  `add_equipslot_flag` tinyint(4) NOT NULL DEFAULT '0',
  `channel_equipslot_switch` tinyint(4) NOT NULL DEFAULT '0',
  `expand_equipslot_switch` tinyint(4) NOT NULL DEFAULT '0',
  `growth_power_reward` tinyint(4) NOT NULL DEFAULT '0',
  `chaos_respon_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_play_dungeon_index` int(10) unsigned NOT NULL DEFAULT '0',
  `total_play_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE,
  KEY `idx_exp` (`exp`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_stat`
--

LOCK TABLES `charac_stat` WRITE;
/*!40000 ALTER TABLE `charac_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_titlebook`
--

DROP TABLE IF EXISTS `charac_titlebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_titlebook` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `specific_section` blob NOT NULL,
  `general_section` blob NOT NULL,
  `despair` blob NOT NULL,
  `event` blob NOT NULL,
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_titlebook`
--

LOCK TABLES `charac_titlebook` WRITE;
/*!40000 ALTER TABLE `charac_titlebook` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_titlebook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_tower_despair`
--

DROP TABLE IF EXISTS `charac_tower_despair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_tower_despair` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `first_layer_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `today_enter_count` tinyint(4) NOT NULL DEFAULT '0',
  `last_clear_layer` tinyint(4) NOT NULL DEFAULT '0',
  `enter_count_by_week` int(11) NOT NULL DEFAULT '0',
  `m_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_clear_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE,
  KEY `m_date` (`m_date`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_tower_despair`
--

LOCK TABLES `charac_tower_despair` WRITE;
/*!40000 ALTER TABLE `charac_tower_despair` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_tower_despair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_tower_despair_apc`
--

DROP TABLE IF EXISTS `charac_tower_despair_apc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_tower_despair_apc` (
  `reg_date` date NOT NULL DEFAULT '0000-00-00',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `seq` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reg_date`,`seq`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_tower_despair_apc`
--

LOCK TABLES `charac_tower_despair_apc` WRITE;
/*!40000 ALTER TABLE `charac_tower_despair_apc` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_tower_despair_apc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_tower_rank`
--

DROP TABLE IF EXISTS `charac_tower_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_tower_rank` (
  `tower_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `part_type` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `member_info` char(128) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tower_index`,`part_type`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_tower_rank`
--

LOCK TABLES `charac_tower_rank` WRITE;
/*!40000 ALTER TABLE `charac_tower_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_tower_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_tower_rank_top5`
--

DROP TABLE IF EXISTS `charac_tower_rank_top5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_tower_rank_top5` (
  `tower_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `part_type` tinyint(4) NOT NULL DEFAULT '0',
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `member_info` char(128) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tower_index`,`part_type`,`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_tower_rank_top5`
--

LOCK TABLES `charac_tower_rank_top5` WRITE;
/*!40000 ALTER TABLE `charac_tower_rank_top5` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_tower_rank_top5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_tower_record`
--

DROP TABLE IF EXISTS `charac_tower_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_tower_record` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `tower_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `member_info_1` char(32) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `stage_1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_time_1` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time_1` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_info_2` char(64) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `stage_2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_time_2` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time_2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_info_3` char(96) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `stage_3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_time_3` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time_3` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `member_info_4` char(128) CHARACTER SET sjis COLLATE sjis_bin NOT NULL DEFAULT '',
  `stage_4` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_time_4` int(10) unsigned NOT NULL DEFAULT '0',
  `occ_time_4` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_tower_record`
--

LOCK TABLES `charac_tower_record` WRITE;
/*!40000 ALTER TABLE `charac_tower_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_tower_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_trade_limit_info`
--

DROP TABLE IF EXISTS `charac_trade_limit_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_trade_limit_info` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `last_trade_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_trade_gold` int(10) unsigned NOT NULL DEFAULT '0',
  `trade_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nexon_user` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE,
  KEY `idx_mid` (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_trade_limit_info`
--

LOCK TABLES `charac_trade_limit_info` WRITE;
/*!40000 ALTER TABLE `charac_trade_limit_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_trade_limit_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_view`
--

DROP TABLE IF EXISTS `charac_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_view` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `info` blob NOT NULL,
  `slot_effect_count` tinyint(3) unsigned NOT NULL DEFAULT '18',
  `charac_slot_limit` tinyint(3) unsigned NOT NULL DEFAULT '18',
  `hash_key` varchar(32) NOT NULL DEFAULT '',
  `charac_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_view`
--

LOCK TABLES `charac_view` WRITE;
/*!40000 ALTER TABLE `charac_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charac_view_act8`
--

DROP TABLE IF EXISTS `charac_view_act8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_view_act8` (
  `m_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `info` blob NOT NULL,
  `slot_effect_count` tinyint(3) unsigned NOT NULL DEFAULT '18',
  `charac_slot_limit` tinyint(3) unsigned NOT NULL DEFAULT '18',
  `hash_key` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charac_view_act8`
--

LOCK TABLES `charac_view_act8` WRITE;
/*!40000 ALTER TABLE `charac_view_act8` DISABLE KEYS */;
/*!40000 ALTER TABLE `charac_view_act8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cs_table2`
--

DROP TABLE IF EXISTS `cs_table2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cs_table2` (
  `account_id` char(30) NOT NULL,
  `charac_id` char(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cs_table2`
--

LOCK TABLES `cs_table2` WRITE;
/*!40000 ALTER TABLE `cs_table2` DISABLE KEYS */;
/*!40000 ALTER TABLE `cs_table2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cube_premium`
--

DROP TABLE IF EXISTS `cube_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cube_premium` (
  `charac_no` int(11) DEFAULT NULL,
  `selected` tinyint(4) DEFAULT NULL,
  `cube_type` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cube_premium`
--

LOCK TABLES `cube_premium` WRITE;
/*!40000 ALTER TABLE `cube_premium` DISABLE KEYS */;
/*!40000 ALTER TABLE `cube_premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnf_pcroom`
--

DROP TABLE IF EXISTS `dnf_pcroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnf_pcroom` (
  `ip_no` int(11) NOT NULL AUTO_INCREMENT,
  `district` varchar(20) NOT NULL DEFAULT '',
  `firm_name` varchar(50) NOT NULL DEFAULT '',
  `telephone` varchar(20) NOT NULL DEFAULT '',
  `address` varchar(150) NOT NULL DEFAULT '',
  `leader` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(11) NOT NULL DEFAULT '',
  `start_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `end_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip_no`) USING BTREE,
  UNIQUE KEY `start_ip` (`ip`,`start_ip`) USING BTREE,
  UNIQUE KEY `end_ip` (`ip`,`end_ip`) USING BTREE,
  KEY `idx_district` (`district`) USING BTREE,
  KEY `idx_leader` (`leader`) USING BTREE,
  KEY `idx_firm_name` (`firm_name`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnf_pcroom`
--

LOCK TABLES `dnf_pcroom` WRITE;
/*!40000 ALTER TABLE `dnf_pcroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnf_pcroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eco_point`
--

DROP TABLE IF EXISTS `eco_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eco_point` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `eco_point` int(10) unsigned NOT NULL DEFAULT '0',
  `point_500` tinyint(4) NOT NULL DEFAULT '0',
  `point_300` tinyint(4) NOT NULL DEFAULT '0',
  `point_100` tinyint(4) NOT NULL DEFAULT '0',
  `point_50` tinyint(4) NOT NULL DEFAULT '0',
  `point_20` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eco_point`
--

LOCK TABLES `eco_point` WRITE;
/*!40000 ALTER TABLE `eco_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `eco_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_1106_idol_bring_up`
--

DROP TABLE IF EXISTS `event_1106_idol_bring_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_1106_idol_bring_up` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `pot_type` tinyint(4) NOT NULL DEFAULT '0',
  `water_cnt` tinyint(4) NOT NULL DEFAULT '0',
  `give_title_flag` tinyint(4) NOT NULL DEFAULT '0',
  `occ_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `give_title_flag2` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_1106_idol_bring_up`
--

LOCK TABLES `event_1106_idol_bring_up` WRITE;
/*!40000 ALTER TABLE `event_1106_idol_bring_up` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_1106_idol_bring_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_additional_condition_info`
--

DROP TABLE IF EXISTS `event_additional_condition_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_additional_condition_info` (
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  `current_step` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `reward_step` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_additional_condition_info`
--

LOCK TABLES `event_additional_condition_info` WRITE;
/*!40000 ALTER TABLE `event_additional_condition_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_additional_condition_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_condition_info`
--

DROP TABLE IF EXISTS `event_condition_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_condition_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `current_step` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_step` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_condition_info`
--

LOCK TABLES `event_condition_info` WRITE;
/*!40000 ALTER TABLE `event_condition_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_condition_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_conditionable_info`
--

DROP TABLE IF EXISTS `event_conditionable_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_conditionable_info` (
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  `current_step` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `reward_step` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_conditionable_info`
--

LOCK TABLES `event_conditionable_info` WRITE;
/*!40000 ALTER TABLE `event_conditionable_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_conditionable_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_detective_goblin`
--

DROP TABLE IF EXISTS `event_detective_goblin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_detective_goblin` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `point` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_detective_goblin`
--

LOCK TABLES `event_detective_goblin` WRITE;
/*!40000 ALTER TABLE `event_detective_goblin` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_detective_goblin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_dungeon_clear`
--

DROP TABLE IF EXISTS `event_dungeon_clear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_dungeon_clear` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `clear_cnt` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_dungeon_clear`
--

LOCK TABLES `event_dungeon_clear` WRITE;
/*!40000 ALTER TABLE `event_dungeon_clear` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_dungeon_clear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_levelup_support`
--

DROP TABLE IF EXISTS `event_levelup_support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_levelup_support` (
  `charac_no` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `state` int(11) DEFAULT NULL,
  PRIMARY KEY (`charac_no`,`level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_levelup_support`
--

LOCK TABLES `event_levelup_support` WRITE;
/*!40000 ALTER TABLE `event_levelup_support` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_levelup_support` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_used_fatigue_at_mage`
--

DROP TABLE IF EXISTS `event_used_fatigue_at_mage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_used_fatigue_at_mage` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `fatigue_quantity` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_used_fatigue_at_mage`
--

LOCK TABLES `event_used_fatigue_at_mage` WRITE;
/*!40000 ALTER TABLE `event_used_fatigue_at_mage` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_used_fatigue_at_mage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_visit_room_info`
--

DROP TABLE IF EXISTS `event_visit_room_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_visit_room_info` (
  `charac_no` int(11) unsigned NOT NULL DEFAULT '0',
  `visit_cnt` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `visit_charac_no` blob,
  `update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_visit_room_info`
--

LOCK TABLES `event_visit_room_info` WRITE;
/*!40000 ALTER TABLE `event_visit_room_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_visit_room_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exp_level_ref`
--

DROP TABLE IF EXISTS `exp_level_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exp_level_ref` (
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `lev` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exp_level_ref`
--

LOCK TABLES `exp_level_ref` WRITE;
/*!40000 ALTER TABLE `exp_level_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `exp_level_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_channel`
--

DROP TABLE IF EXISTS `game_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_channel` (
  `gc_no` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gc_now` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_ip` varchar(64) NOT NULL DEFAULT '',
  `gc_port` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_max` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_game` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gc_channel` varchar(32) NOT NULL DEFAULT '',
  `gc_ch_group` smallint(5) NOT NULL DEFAULT '0',
  `gc_channeltype` varchar(25) NOT NULL DEFAULT '',
  `gc_up_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gc_swordman_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_fighter_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_gunner_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_mage_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_priest_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_at_gunner_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_thief_cnt` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_hangame` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_nexon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gc_type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gc_no`) USING BTREE,
  KEY `idxGC_GAME` (`gc_game`) USING BTREE,
  KEY `idxch_group` (`gc_ch_group`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3012 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_channel`
--

LOCK TABLES `game_channel` WRITE;
/*!40000 ALTER TABLE `game_channel` DISABLE KEYS */;
INSERT INTO `game_channel` VALUES (3011,0,'192.168.200.131',10011,600,3,'ch.11',11,'[granfloris]','2026-03-10 11:37:39',0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `game_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_info`
--

DROP TABLE IF EXISTS `ip_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_info` (
  `no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(11) NOT NULL DEFAULT '',
  `start_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `end_ip` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_check` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vendor_no` int(10) unsigned NOT NULL DEFAULT '0',
  `speed_no` int(10) unsigned NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `charge_flag` tinyint(4) NOT NULL DEFAULT '0',
  `settle_no` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`) USING BTREE,
  UNIQUE KEY `ip` (`ip`,`start_ip`,`end_ip`) USING BTREE,
  KEY `idx_m_id` (`m_id`) USING BTREE,
  KEY `idx_ip` (`ip`) USING BTREE,
  KEY `idx_start_ip` (`start_ip`) USING BTREE,
  KEY `idx_end_ip` (`end_ip`) USING BTREE,
  KEY `idx_occ_time` (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_info`
--

LOCK TABLES `ip_info` WRITE;
/*!40000 ALTER TABLE `ip_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_gen_ref`
--

DROP TABLE IF EXISTS `item_gen_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_gen_ref` (
  `item_grade` tinyint(4) NOT NULL DEFAULT '0',
  `rate_type` tinyint(4) NOT NULL DEFAULT '0',
  `money_rate` smallint(6) NOT NULL DEFAULT '0',
  `item_rate` smallint(6) NOT NULL DEFAULT '0',
  `free_rate` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_gen_ref`
--

LOCK TABLES `item_gen_ref` WRITE;
/*!40000 ALTER TABLE `item_gen_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_gen_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_making_skill_info`
--

DROP TABLE IF EXISTS `item_making_skill_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_making_skill_info` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `weapon` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cloth` smallint(5) unsigned NOT NULL DEFAULT '0',
  `leather` smallint(5) unsigned NOT NULL DEFAULT '0',
  `light_armor` smallint(5) unsigned NOT NULL DEFAULT '0',
  `heavy_armor` smallint(5) unsigned NOT NULL DEFAULT '0',
  `plate` smallint(5) unsigned NOT NULL DEFAULT '0',
  `amulet` smallint(5) unsigned NOT NULL DEFAULT '0',
  `wrist` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ring` smallint(5) unsigned NOT NULL DEFAULT '0',
  `support` smallint(5) unsigned NOT NULL DEFAULT '0',
  `magic_stone` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_making_skill_info`
--

LOCK TABLES `item_making_skill_info` WRITE;
/*!40000 ALTER TABLE `item_making_skill_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_making_skill_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_select_std`
--

DROP TABLE IF EXISTS `item_select_std`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_select_std` (
  `item_grade` int(11) NOT NULL DEFAULT '0',
  `top` int(11) NOT NULL DEFAULT '0',
  `bottom` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_select_std`
--

LOCK TABLES `item_select_std` WRITE;
/*!40000 ALTER TABLE `item_select_std` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_select_std` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limit_npc_item`
--

DROP TABLE IF EXISTS `limit_npc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limit_npc_item` (
  `item_index` int(10) unsigned NOT NULL DEFAULT '0',
  `max_count` int(10) unsigned NOT NULL DEFAULT '0',
  `sell_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_index`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limit_npc_item`
--

LOCK TABLES `limit_npc_item` WRITE;
/*!40000 ALTER TABLE `limit_npc_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `limit_npc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_num_occupations`
--

DROP TABLE IF EXISTS `log_num_occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_num_occupations` (
  `occ_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_occupations_charscreen` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_occupations_seriaroom` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_login_per_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_logout_per_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`occ_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_num_occupations`
--

LOCK TABLES `log_num_occupations` WRITE;
/*!40000 ALTER TABLE `log_num_occupations` DISABLE KEYS */;
INSERT INTO `log_num_occupations` VALUES ('2015-11-07 22:09:34',0,0,0,0),('2026-01-30 09:47:52',0,0,16777215,16777215),('2026-02-28 14:35:56',0,0,16777215,16777215),('2026-02-28 14:36:56',0,0,0,0),('2026-02-28 14:37:56',0,0,0,0),('2026-02-28 14:38:56',0,0,0,0),('2026-02-28 14:39:56',0,0,0,0),('2026-02-28 14:40:56',0,0,0,0),('2026-02-28 14:41:56',0,0,0,0),('2026-02-28 14:42:55',0,0,0,0),('2026-02-28 14:43:55',0,0,0,0),('2026-02-28 14:44:55',0,0,0,0),('2026-02-28 14:45:55',0,0,0,0),('2026-02-28 14:46:55',0,0,0,0),('2026-02-28 14:47:55',0,0,0,0),('2026-02-28 15:07:37',0,0,16777215,16777215),('2026-02-28 15:08:37',0,0,0,0),('2026-03-10 11:03:05',0,0,16777215,16777215),('2026-03-10 11:04:05',0,0,0,0),('2026-03-10 11:05:05',0,0,0,0),('2026-03-10 11:06:05',0,0,0,0),('2026-03-10 11:07:05',0,0,0,0),('2026-03-10 11:08:05',0,0,0,0),('2026-03-10 11:09:05',0,0,0,0),('2026-03-10 11:10:05',0,0,0,0),('2026-03-10 11:11:05',0,0,0,0),('2026-03-10 11:12:05',0,0,0,0),('2026-03-10 11:13:05',0,0,0,0),('2026-03-10 11:14:05',0,0,0,0),('2026-03-10 11:15:05',0,0,0,0),('2026-03-10 11:16:05',0,0,0,0),('2026-03-10 11:17:05',0,0,0,0),('2026-03-10 11:18:05',0,0,0,0),('2026-03-10 11:19:05',0,0,0,0),('2026-03-10 11:20:05',0,0,0,0),('2026-03-10 11:21:05',0,0,0,0),('2026-03-10 11:22:05',0,0,0,0),('2026-03-10 11:23:05',0,0,0,0),('2026-03-10 11:24:05',0,0,0,0),('2026-03-10 11:25:05',0,0,0,0),('2026-03-10 11:26:05',0,0,0,0),('2026-03-10 11:27:05',0,0,0,0),('2026-03-10 11:28:05',0,0,0,0),('2026-03-10 11:29:05',0,0,0,0),('2026-03-10 11:30:05',0,0,0,0),('2026-03-10 11:31:05',0,0,0,0),('2026-03-10 11:32:05',0,0,0,0),('2026-03-10 11:33:05',0,0,0,0),('2026-03-10 11:34:05',0,0,0,0),('2026-03-10 11:35:05',0,0,0,0),('2026-03-10 11:36:05',0,0,0,0),('2026-03-10 11:37:05',0,0,0,0);
/*!40000 ALTER TABLE `log_num_occupations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_booster_gage`
--

DROP TABLE IF EXISTS `member_booster_gage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_booster_gage` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gage` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_booster_gage`
--

LOCK TABLES `member_booster_gage` WRITE;
/*!40000 ALTER TABLE `member_booster_gage` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_booster_gage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_dungeon`
--

DROP TABLE IF EXISTS `member_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_dungeon` (
  `m_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dungeon` text NOT NULL,
  PRIMARY KEY (`m_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_dungeon`
--

LOCK TABLES `member_dungeon` WRITE;
/*!40000 ALTER TABLE `member_dungeon` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_dungeon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `money_gen_ref`
--

DROP TABLE IF EXISTS `money_gen_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `money_gen_ref` (
  `grade` int(11) NOT NULL DEFAULT '0',
  `bottom_grade` int(11) NOT NULL DEFAULT '0',
  `money` int(11) NOT NULL DEFAULT '0',
  `random_value` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money_gen_ref`
--

LOCK TABLES `money_gen_ref` WRITE;
/*!40000 ALTER TABLE `money_gen_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `money_gen_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monster_reward_ref`
--

DROP TABLE IF EXISTS `monster_reward_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monster_reward_ref` (
  `level` smallint(11) NOT NULL DEFAULT '0',
  `exp` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monster_reward_ref`
--

LOCK TABLES `monster_reward_ref` WRITE;
/*!40000 ALTER TABLE `monster_reward_ref` DISABLE KEYS */;
INSERT INTO `monster_reward_ref` VALUES (1,30),(2,40),(3,50),(4,60),(5,70),(6,80),(7,90),(8,100),(9,110),(10,120),(11,130),(12,140),(13,150),(14,160),(15,170),(16,185),(17,201),(18,218),(19,235),(20,253),(21,271),(22,290),(23,310),(24,330),(25,351),(26,372),(27,394),(28,417),(29,440),(30,464),(31,488),(32,513),(33,539),(34,565),(35,592),(36,619),(37,647),(38,676),(39,705),(40,735),(41,765),(42,796),(43,828),(44,860),(45,893),(46,926),(47,960),(48,995),(49,1030),(50,1066),(51,1102),(52,1139),(53,1177),(54,1215),(55,1254),(56,1293),(57,1333),(58,1374),(59,1415),(60,1457),(61,1499),(62,1542),(63,1586),(64,1630),(65,1675),(66,1720),(67,1766),(68,1813),(69,1860),(70,1908),(71,1956),(72,2005),(73,2055),(74,2105),(75,2156),(76,2207),(77,2259),(78,2312),(79,2365),(80,2419),(81,2473),(82,2528),(83,2584),(84,2640),(85,2697),(86,2754),(87,2812),(88,2871),(89,2930),(90,2990),(91,3050),(92,3111),(93,3173),(94,3235),(95,3298),(96,3361),(97,3425),(98,3490),(99,3555);
/*!40000 ALTER TABLE `monster_reward_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_charac_quest`
--

DROP TABLE IF EXISTS `new_charac_quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_charac_quest` (
  `charac_no` int(10) unsigned NOT NULL DEFAULT '0',
  `clear_quest` blob NOT NULL,
  `quest_notify` blob NOT NULL,
  `play_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_1_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_2_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_3_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_4_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_5` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_5_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_6` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_6_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_7` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_7_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_8` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_8_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_9` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_9_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_10` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_10_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `auto_clear` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `play_11` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_11_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_12` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_12_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_13` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_13_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_14` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_14_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_15` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_15_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_16` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_16_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_17` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_17_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_18` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_18_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_19` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_19_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `play_20` smallint(5) unsigned NOT NULL DEFAULT '0',
  `play_20_trigger` int(10) unsigned NOT NULL DEFAULT '0',
  `urgentQuestIndex` smallint(6) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_charac_quest`
--

LOCK TABLES `new_charac_quest` WRITE;
/*!40000 ALTER TABLE `new_charac_quest` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_charac_quest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_rank_avg`
--

DROP TABLE IF EXISTS `party_rank_avg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_rank_avg` (
  `dungeon_index` smallint(6) NOT NULL DEFAULT '0',
  `party_level` smallint(6) NOT NULL DEFAULT '0',
  `clear_count` bigint(20) NOT NULL DEFAULT '0',
  `average` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dungeon_index`,`party_level`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_rank_avg`
--

LOCK TABLES `party_rank_avg` WRITE;
/*!40000 ALTER TABLE `party_rank_avg` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_rank_avg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvp_grade_expand`
--

DROP TABLE IF EXISTS `pvp_grade_expand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvp_grade_expand` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `pvp_grade` int(11) NOT NULL DEFAULT '0',
  `pvp_point` int(11) NOT NULL DEFAULT '0',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE,
  KEY `idx_pvp_grade` (`pvp_grade`) USING BTREE,
  KEY `idx_pvp_point` (`pvp_point`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvp_grade_expand`
--

LOCK TABLES `pvp_grade_expand` WRITE;
/*!40000 ALTER TABLE `pvp_grade_expand` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvp_grade_expand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvp_grade_ref`
--

DROP TABLE IF EXISTS `pvp_grade_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvp_grade_ref` (
  `grade` int(11) NOT NULL DEFAULT '0',
  `limit_pts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`grade`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvp_grade_ref`
--

LOCK TABLES `pvp_grade_ref` WRITE;
/*!40000 ALTER TABLE `pvp_grade_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvp_grade_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvp_result`
--

DROP TABLE IF EXISTS `pvp_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvp_result` (
  `charac_no` int(11) NOT NULL DEFAULT '0',
  `win` int(11) NOT NULL DEFAULT '0',
  `lose` int(11) NOT NULL DEFAULT '0',
  `pvp_point` int(11) NOT NULL DEFAULT '0',
  `pvp_grade` int(11) NOT NULL DEFAULT '0',
  `pvp_grade_ext` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `avg_kill_count` int(11) NOT NULL DEFAULT '0',
  `avg_buf_count` int(11) NOT NULL DEFAULT '0',
  `avg_debuf_count` int(11) NOT NULL DEFAULT '0',
  `avg_heal_count` int(11) NOT NULL DEFAULT '0',
  `avg_counter_count` int(11) NOT NULL DEFAULT '0',
  `avg_back_atk_count` int(11) NOT NULL DEFAULT '0',
  `avg_union_hit_count` int(11) NOT NULL DEFAULT '0',
  `avg_overkill_count` int(11) NOT NULL DEFAULT '0',
  `avg_aerial_count` int(11) NOT NULL DEFAULT '0',
  `avg_combo_count` int(11) NOT NULL DEFAULT '0',
  `avg_attacked_count` int(11) NOT NULL DEFAULT '0',
  `avg_deal_damage` int(11) NOT NULL DEFAULT '0',
  `avg_technic` int(11) NOT NULL DEFAULT '0',
  `avg_style` int(11) NOT NULL DEFAULT '0',
  `avg_hit_penalty` int(11) NOT NULL DEFAULT '0',
  `pvp_count` int(11) NOT NULL DEFAULT '0',
  `win_point` int(11) NOT NULL DEFAULT '0',
  `last_play_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `play_count` int(10) unsigned NOT NULL DEFAULT '0',
  `play_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pvp_grade_ext_update_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`charac_no`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvp_result`
--

LOCK TABLES `pvp_result` WRITE;
/*!40000 ALTER TABLE `pvp_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvp_result` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`game`@`%`*/ /*!50003 TRIGGER check_play_count
BEFORE UPDATE ON taiwan_cain.pvp_result
FOR EACH ROW
BEGIN
    IF NEW.play_count < OLD.play_count THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot decrease play_count value.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `quest_category`
--

DROP TABLE IF EXISTS `quest_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_category` (
  `quest_idx` int(11) NOT NULL DEFAULT '0',
  `quest_name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`quest_idx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_category`
--

LOCK TABLES `quest_category` WRITE;
/*!40000 ALTER TABLE `quest_category` DISABLE KEYS */;
INSERT INTO `quest_category` VALUES (1,'神聖的守護者'),(2,'天空之城開拓者'),(3,'烈焰征服者'),(4,'精靈的魔法陣'),(5,'人偶的誘惑'),(6,'石巨人終結者'),(7,'前往天空之城'),(8,'精靈的魔法陣'),(9,'屠龍勇士'),(10,'巨人獵殺者'),(11,'冰心之魂'),(12,'毛皮搜集專家'),(13,'融化的冰雪'),(14,'正義的使者'),(15,'索西雅的災星'),(16,'光之城主 - 賽格哈特'),(17,'不滅的賽格哈特'),(18,'光之城主的誕生'),(19,'巴卡爾的遺言'),(20,'盛載記憶的水晶球'),(21,'向暗黑城進軍'),(22,'調查GBL神殿'),(23,'預言家赫亞西斯的預言'),(24,'異能之奧秘'),(25,'AT-5T 駕駛達人'),(26,'雜技愛好者'),(27,'赫亞西斯的預言'),(28,'製作干擾發射器 1'),(29,'製作干擾發射器 2'),(30,'製作干擾發射器 3'),(31,'製作干擾發射器 4'),(32,'製作干擾發射器 5'),(33,'製作干擾發射器 6'),(34,'製作干擾發射器 完'),(35,'緊急任務'),(36,'以復仇的名義'),(37,'羅特斯的記憶'),(38,'存在的使徒'),(39,'前往阿法利亞臨時營地'),(40,'戰爭的危機'),(41,'加爾的測試'),(42,'布萊斯的託付'),(43,'拿去給諾頓'),(44,'傳染病研究'),(45,'傳達解毒藥'),(46,'還沒太晚'),(47,'阻止戰爭！'),(48,'通向暗黑城之路'),(49,'強悍的證明'),(50,'預言家赫亞西斯的預言'),(51,'預言家赫亞西斯的預言'),(52,'預言家赫亞西斯的預言'),(53,'散播傳染病的村裝'),(54,'正式的調查'),(55,'犬人哈多'),(56,'盜賊團的頭目'),(57,'與暗精靈相同的處境'),(58,'後勤補給隊長'),(59,'光明守護者'),(60,'無情的伐木工'),(61,'章魚捕手'),(62,'亡者峽谷'),(63,'預言家希莫娜'),(64,'迷妄之塔'),(65,'被遺忘者之塔'),(66,'迷亂之村哈穆林'),(67,'追查笛子聲'),(68,'鼠頭人'),(69,'魔笛使者皮特'),(70,'調查暗黑城'),(71,'謹慎的汀高'),(72,'沉默的亨普利'),(73,'無頭騎士'),(74,'該前往暗黑城…'),(75,'敵友難分'),(76,'疑惑'),(77,'為了暗精靈的未來'),(78,'緊急任務'),(79,'緊急任務'),(80,'緊急任務'),(81,'緊急任務'),(82,'緊急任務'),(83,'緊急任務'),(84,'緊急任務'),(85,'緊急任務'),(86,'緊急任務'),(87,'緊急任務'),(88,'緊急任務'),(89,'緊急任務'),(90,'緊急任務'),(92,'多個的塔'),(93,'卡勒特追擊者'),(94,'懸賞令 - 波羅丁'),(95,'亡者們'),(96,'黑暗的記憶'),(97,'毀滅的痕跡'),(98,'緊急任務'),(99,'緊急任務'),(100,'緊急任務'),(101,'林納斯大叔'),(102,'冒險開始'),(103,'噪音公害'),(104,'流動的叢林 格蘭之森'),(105,'牛頭獸的狂暴'),(106,'讓人感到頭痛的貓妖群'),(107,'呼喚閃電的哥布林'),(108,'凱諾哥布林的傳說'),(109,'去過叢林深處的人'),(110,'毒的香氣'),(111,'牛頭王薩烏塔'),(112,'邪惡氣息的前兆'),(113,'灰色結晶碎片'),(114,'邪惡氣息的來歷'),(115,'緊急任務'),(116,'瘋掉的魔法師克拉赫'),(117,'調查力量減弱的魔法陣'),(118,'通緝令 - 波羅丁 (2/2)'),(119,'水落石出'),(120,'人偶之王道格裡'),(121,'石巨人塔'),(122,'黃金石巨人'),(123,'研究石巨人'),(124,'除掉普拉塔尼的方法'),(125,'城的存在'),(126,'光之城主的宮殿'),(127,'移動的迷宮'),(128,'封印石'),(129,'揭開神秘面紗'),(130,'懸賞令 - 牛頭械王'),(131,'暗精靈的刀法'),(132,'迷宮中的劍士'),(133,'所有的路聚為一…'),(134,'緊急任務'),(135,'通緝令 - 牛頭械王 (2/2)'),(136,'懸賞令 - 蟲王戮蠱'),(137,'通緝令 - 蟲王戮蠱 (2/2)'),(138,'懸賞令 - 狄瑞吉的幻影'),(139,'通緝令 - 狄瑞吉的幻影'),(144,'智慧與金錢'),(145,'波迪爾的指令書'),(146,'掃描機器人'),(147,'目標藍影馬薩喬'),(148,'尋找叛徒'),(149,'完美的演技'),(150,'豐厚的獎勵'),(151,'合理分配'),(152,'緊急任務'),(153,'緊急任務'),(154,'光之舞手鐲'),(155,'獲得干擾發射器'),(156,'覺醒 - 末日守護者 1'),(157,'覺醒 - 末日守護者 2'),(158,'覺醒 - 末日守護者 3'),(159,'覺醒 - 末日守護者 4'),(160,'緊急任務'),(161,'緊急任務'),(162,'緊急任務'),(163,'緊急任務'),(164,''),(165,'雪山的報答 (2/2)'),(166,'異次元碎片(重複)'),(172,'強化武器'),(173,'專門職業 - 收集無色小'),(174,'專門職業 - 收集藍色小'),(175,'專門職業 - 收集黑色小'),(176,'專門職業 - 收集紅色小'),(177,'專門職業 - 收集白色小'),(178,'專門職業 - 兌換下級元'),(179,'專門職業 - 兌換上級元'),(180,'專門職業 - 兌換平凡的'),(181,'專門職業 - 兌換淬煉的'),(182,'緊急任務'),(183,'緊急任務'),(184,'緊急任務'),(185,'緊急任務'),(186,'緊急任務'),(187,'緊急任務'),(188,'緊急任務'),(189,'緊急任務'),(190,'緊急任務'),(191,'緊急任務'),(192,'緊急任務'),(193,'緊急任務'),(194,'緊急任務'),(195,'緊急任務'),(196,'緊急任務'),(197,'緊急任務'),(198,'緊急任務'),(199,'緊急任務'),(200,'緊急任務'),(201,'辛達遺失的槌子'),(202,'奇怪石頭'),(203,'暗黑雷鳴廢墟'),(204,'緊急任務'),(205,'緊急任務'),(206,'專門職業 - 兌換強韌的'),(207,'緊急任務'),(208,'緊急任務'),(209,'緊急任務'),(210,'緊急任務'),(211,'學習技能 2'),(212,'村民的委託 - 一般任務'),(213,'稱號簿 1'),(214,'稱號簿 2'),(215,'魔法封印道具'),(216,'解除魔法封印'),(217,'獲得無色小晶塊碎片'),(218,'再生魔法封印'),(219,'魔法封印變換'),(220,'緊急任務'),(221,'緊急任務'),(222,'緊急任務'),(223,'緊急任務'),(224,'緊急任務'),(225,'緊急任務'),(226,'緊急任務'),(227,'緊急任務'),(228,'緊急任務'),(229,'緊急任務'),(230,'緊急任務'),(231,'緊急任務'),(232,'緊急任務'),(233,'緊急任務'),(234,'緊急任務'),(235,'緊急任務'),(236,'緊急任務'),(237,'緊急任務'),(238,'緊急任務'),(239,'緊急任務'),(240,'緊急任務'),(241,'緊急任務'),(242,'緊急任務'),(243,'緊急任務'),(244,'緊急任務'),(245,'緊急任務'),(246,'緊急任務'),(247,'緊急任務'),(248,'緊急任務'),(249,'緊急任務'),(250,'緊急任務'),(251,'緊急任務'),(252,'緊急任務'),(253,'緊急任務'),(254,'緊急任務'),(255,'緊急任務'),(256,'緊急任務'),(257,'緊急任務'),(258,'緊急任務'),(259,'緊急任務'),(260,'緊急任務'),(261,'緊急任務'),(262,'緊急任務'),(263,'緊急任務'),(264,'緊急任務'),(265,'緊急任務'),(266,'緊急任務'),(267,'緊急任務'),(268,'緊急任務'),(269,'緊急任務'),(270,'緊急任務'),(271,'緊急任務'),(272,'緊急任務'),(273,'緊急任務'),(274,'緊急任務'),(275,'緊急任務'),(276,'緊急任務'),(277,'緊急任務'),(278,'緊急任務'),(279,'緊急任務'),(280,'緊急任務'),(281,'緊急任務'),(282,'緊急任務'),(283,'緊急任務'),(284,'緊急任務'),(285,'緊急任務'),(286,'緊急任務'),(287,'緊急任務'),(288,'緊急任務'),(289,'緊急任務'),(290,'精煉炭'),(291,'天空之海的純淨水'),(292,'緊急任務'),(293,'緊急任務'),(294,'緊急任務'),(295,'緊急任務'),(296,'緊急任務'),(297,'緊急任務'),(298,'失眠症'),(299,'緊急任務'),(300,'緊急任務'),(301,'緊急任務'),(302,'緊急任務'),(303,'緊急任務'),(304,'緊急任務'),(305,'緊急任務'),(306,'緊急任務'),(307,'緊急任務'),(308,'緊急任務'),(309,'緊急任務'),(310,'緊急任務'),(311,'緊急任務'),(312,'緊急任務'),(313,'緊急任務'),(314,'緊急任務'),(315,'緊急任務'),(316,'緊急任務'),(317,'緊急任務'),(318,'緊急任務'),(319,'緊急任務'),(320,'緊急任務'),(321,'緊急任務'),(322,'緊急任務'),(323,'緊急任務'),(324,'緊急任務'),(325,'緊急任務'),(326,'緊急任務'),(327,'緊急任務'),(328,'緊急任務'),(329,'緊急任務'),(330,'緊急任務'),(331,'緊急任務'),(332,'緊急任務'),(333,'緊急任務'),(334,'緊急任務'),(335,'緊急任務'),(336,'緊急任務'),(337,'緊急任務'),(338,'緊急任務'),(339,'緊急任務'),(340,'緊急任務'),(341,'緊急任務'),(342,'緊急任務'),(343,'緊急任務'),(344,'緊急任務'),(345,'靈魂的悲傷吶喊'),(346,'製作鎮魂香'),(347,'傳遞鎮魂香'),(348,'緊急任務'),(349,'向阿貝爾特學習技能 1'),(350,'緊急任務'),(351,'緊急任務'),(352,'緊急任務'),(353,'緊急任務'),(354,'緊急任務'),(355,'向阿貝爾特學習技能 2'),(356,'沒有送出的信'),(357,'委託解讀信件'),(358,'夏洛克的條件'),(359,'傳達被解讀的信件'),(360,'未被修復的魔法陣'),(361,'變強的天空之城氣息'),(362,'懸空城的存在'),(363,'懸空城的第一個關口'),(364,'懸空城的第二個關口'),(365,'懸空城的第三個關口'),(366,'緊急任務'),(367,'懸空城的最後關口'),(368,'緊急任務'),(369,'緊急任務'),(370,'緊急任務'),(371,'緊急任務'),(372,'緊急任務'),(373,'緊急任務'),(374,'緊急任務'),(375,'緊急任務'),(376,'緊急任務'),(377,'緊急任務'),(378,'緊急任務'),(379,'緊急任務'),(380,'緊急任務'),(381,'緊急任務'),(382,'緊急任務'),(383,'緊急任務'),(384,'緊急任務'),(385,'緊急任務'),(386,'緊急任務'),(387,'緊急任務'),(388,'[古代地下城] 誰的戰爭'),(389,'[古代地下城] 加爾的惱'),(390,'[古代地下城] 被詛咒的'),(391,'[古代地下城] 被詛咒的'),(392,'[古代地下城] 詢問賽莉'),(393,'[古代地下城] 曾經輝煌'),(394,'[古代地下城] 為了受苦'),(395,'緊急任務'),(396,'[古代地下城] 再找賽莉'),(397,'[古代地下城] 王的五騎'),(398,'[古代地下城] 偉大的波'),(399,'[古代地下城] 風之渦蘇'),(400,'[古代地下城] 守護之邁'),(401,'[古代地下城] 冰之埃斯'),(402,'[古代地下城] 炎之古拉'),(403,'[古代地下城] 光之沃德'),(404,'緊急任務'),(408,'[古代地下城] 再探王的'),(409,'緊急任務'),(410,'緊急任務'),(411,'緊急任務'),(412,'戰爭的修練'),(413,'熔岩穴的修練'),(414,'布萊斯也無法達到的階'),(415,'林納斯的幫助'),(416,'夏洛克的託付'),(417,'原諒？ 報仇？'),(418,'緊急任務'),(419,'[古代地下城] 帝國間諜'),(420,'[古代地下城] 詢問卡妮'),(421,'[古代地下城] 向土罐諮'),(422,'[古代地下城] 運氣試驗'),(423,'[古代地下城] 土罐人偶'),(424,'[古代地下城] 博肯人偶'),(425,'[古老]嗯？ 土罐？'),(426,'[古代地下城] 博肯的劍'),(427,'[古代地下城] 再次抽選'),(428,'[古代地下城] 調查比爾'),(429,'[古老]帝國的實驗… 還'),(430,'[古代地下城] 免疫膠囊'),(431,'[古代地下城] 收購泰拉'),(432,'[古代地下城] 不能倒流'),(433,'緊急任務'),(434,'緊急任務'),(435,'緊急任務'),(436,'緊急任務'),(437,'緊急任務'),(438,'大使的下落'),(439,'緊急任務'),(440,'緊急任務'),(441,'被搶走的鑰匙'),(442,'與邪龍對決'),(443,'邪念體'),(444,'肢解的邪龍身體'),(445,'邪龍的封印'),(446,'解救悲傷的靈魂'),(447,'審判者馬塞爾的日記 - '),(448,'馬塞爾留下的線索'),(449,'血腥淨化的紋章'),(450,'血腥伊恩'),(451,'可疑的信息'),(452,'我在大陸的肚子裡'),(453,'審判者馬塞爾的日記 - '),(454,'現在你可以安心的走了'),(455,'緊急任務'),(456,'緊急任務'),(457,'緊急任務'),(458,'緊急任務'),(459,'緊急任務'),(460,'緊急任務'),(461,'緊急任務'),(462,'緊急任務'),(487,'緊急任務'),(488,'緊急任務'),(489,'緊急任務'),(490,'緊急任務'),(491,'緊急任務'),(492,'緊急任務'),(493,'緊急任務'),(494,'緊急任務'),(495,'緊急任務'),(496,'緊急任務'),(497,'緊急任務'),(498,'緊急任務'),(499,'緊急任務'),(500,'緊急任務'),(501,'鬼劍士之路 - 赫頓瑪爾'),(502,'鬼劍士之路 - 所謂的轉'),(503,'更強的敵人'),(504,'G.S.D的試驗'),(505,'新武器的威力'),(506,'鬼劍士之路 - G.S.D'),(507,'鬼劍士之路 - 任務商店'),(508,'緊急任務'),(509,'緊急任務'),(510,'緊急任務'),(511,'格鬥家之路 - 赫頓瑪爾'),(512,'格鬥家之路 - 所謂的轉'),(513,'更強的敵人'),(514,'G.S.D的試驗'),(515,'新武器的威力'),(516,'格鬥家之路 - 風震'),(517,'格鬥家之路 - 任務商店'),(518,'緊急任務'),(519,'緊急任務'),(520,'緊急任務'),(521,'神槍之路 - 赫頓瑪爾的'),(522,'神槍之路 - 所謂的轉職'),(523,'更強的敵人'),(524,'G.S.D的試驗'),(525,'新武器的威力'),(526,'神槍之路 - 凱莉'),(527,'神槍手之路 - 任務商店'),(528,'緊急任務'),(529,'緊急任務'),(530,'緊急任務'),(531,'魔法師之路 - 赫頓瑪爾'),(532,'魔法師之路 - 所謂的轉'),(533,'更強的敵人'),(534,'G.S.D的試驗'),(535,'新武器的威力'),(536,'魔法師之路 - 莎蘭'),(537,'魔法師之路 - 任務商店'),(538,'緊急任務'),(539,'緊急任務'),(540,'緊急任務'),(541,'聖職者之路 - 赫頓瑪爾'),(542,'聖職者之路 - 所謂的轉'),(543,'更強的敵人'),(544,'G.S.D的試驗'),(545,'新武器的威力'),(546,'聖職者之路 - 歌蘭蒂斯'),(547,'聖職者之路 - 任務商店'),(548,'緊急任務'),(549,'減輕信徒的痛苦'),(550,'請寬恕我'),(551,'叢林探險'),(552,'變異的樹精'),(553,'緊急任務'),(554,'黑暗的煉獄'),(555,'向無盡的黑暗前進'),(556,'緊急任務'),(557,'宿敵'),(558,'天帷巨獸上的最高點'),(559,'破壞信徒的武器'),(560,'緊急任務'),(561,'懸賞令: 寶藏獵人紮卡�'),(562,'前往第一脊椎'),(563,'解放靈魂'),(564,'緊急任務'),(565,'緊急任務'),(566,'緊急任務'),(567,'緊急任務'),(568,'緊急任務'),(569,'緊急任務'),(570,'緊急任務'),(571,'緊急任務'),(572,'緊急任務'),(573,'初見使徒'),(574,'緊急任務'),(575,'緊急任務'),(576,'緊急任務'),(577,'緊急任務'),(578,'緊急任務'),(579,'緊急任務'),(580,'緊急任務'),(581,'緊急任務'),(582,'緊急任務'),(583,'緊急任務'),(584,'緊急任務'),(585,'緊急任務'),(586,'緊急任務'),(587,'緊急任務'),(588,'緊急任務'),(589,'緊急任務'),(590,'緊急任務'),(591,'緊急任務'),(592,'緊急任務'),(593,'緊急任務'),(594,'緊急任務'),(595,'緊急任務'),(596,'緊急任務'),(597,'緊急任務'),(598,'緊急任務'),(599,'緊急任務'),(600,'緊急任務'),(601,'緊急任務'),(602,'緊急任務'),(603,'緊急任務'),(604,'緊急任務'),(605,'緊急任務'),(606,'緊急任務'),(607,'緊急任務'),(608,'緊急任務'),(609,'緊急任務'),(610,'緊急任務'),(611,'緊急任務'),(612,'緊急任務'),(613,'緊急任務'),(614,'緊急任務'),(615,'緊急任務'),(616,'緊急任務'),(617,'緊急任務'),(618,'緊急任務'),(619,'神槍之路 - 赫頓瑪爾的'),(620,'神槍之路 - 所謂的轉職'),(621,'更強的敵人'),(622,'G.S.D的試驗'),(623,'新武器的威力'),(624,'神槍之路 - 凱莉'),(625,'神槍手之路 - 任務商店'),(626,'緊急任務'),(627,'讓流浪的的靈魂得到安'),(628,'緊急任務'),(629,'緊急任務'),(630,'[古代地下城] 波羅丁的'),(631,'盜賊之路 - 赫頓瑪爾的'),(632,'盜賊之路 - 所謂的轉職'),(633,'更強的敵人'),(634,'G.S.D的試驗'),(635,'新武器的威力'),(636,'盜賊之路 - 米奈特'),(637,'盜賊之路 - 任務商店'),(638,'[古代地下城] 突然來襲'),(639,'[古代地下城] 加爾的惱'),(640,'[古代地下城] 被詛咒的'),(641,'[古代地下城] 被詛咒的'),(642,'[古代地下城] 詢問賽莉'),(643,'[古代地下城] 曾經輝煌'),(644,'[古代地下城] 為了受苦'),(645,'[古代地下城] 再找賽莉'),(646,'[古代地下城] 王的五騎'),(647,'[古代地下城] 偉大的波'),(648,'緊急任務'),(649,'穿戴輔助裝備 (2/2)'),(650,'佩戴魔法石 (2/2)'),(651,'緊急任務'),(652,'緊急任務'),(653,'緊急任務'),(654,'緊急任務'),(655,'緊急任務'),(656,'緊急任務'),(657,'緊急任務'),(658,'緊急任務'),(659,'緊急任務'),(660,'緊急任務'),(661,'緊急任務'),(662,'緊急任務'),(663,'緊急任務'),(664,'緊急任務'),(665,'緊急任務'),(666,'緊急任務'),(667,'緊急任務'),(668,'緊急任務'),(669,'緊急任務'),(670,'緊急任務'),(671,'緊急任務'),(672,'緊急任務'),(673,'緊急任務'),(674,'穿戴輔助裝備 (1/2)'),(675,'佩戴魔法石 (1/2)'),(676,'穿戴輔助裝備'),(677,'佩戴魔法石'),(678,'緊急任務'),(679,'晶塊的秘密'),(680,'緊急任務'),(681,'緊急任務'),(682,'緊急任務'),(683,'緊急任務'),(684,'緊急任務'),(685,'緊急任務'),(686,'緊急任務'),(687,'緊急任務'),(688,'緊急任務'),(689,'緊急任務'),(690,'緊急任務'),(691,'緊急任務'),(692,'緊急任務'),(693,'緊急任務'),(694,'緊急任務'),(695,'緊急任務'),(696,'緊急任務'),(697,'緊急任務'),(698,'緊急任務'),(699,'緊急任務'),(700,'緊急任務'),(701,'緊急任務'),(702,'緊急任務'),(703,'緊急任務'),(704,'緊急任務'),(705,'緊急任務'),(706,'緊急任務'),(707,'緊急任務'),(708,'緊急任務'),(709,'緊急任務'),(710,'緊急任務'),(711,'緊急任務'),(712,'緊急任務'),(713,'緊急任務'),(714,'緊急任務'),(715,'緊急任務'),(716,'緊急任務'),(717,'緊急任務'),(718,'緊急任務'),(719,'緊急任務'),(720,'緊急任務'),(721,'緊急任務'),(722,'緊急任務'),(723,'緊急任務'),(724,'緊急任務'),(725,'緊急任務'),(726,'緊急任務'),(727,'緊急任務'),(728,'緊急任務'),(729,'緊急任務'),(730,'緊急任務'),(731,'緊急任務'),(732,'緊急任務'),(733,'緊急任務'),(734,'緊急任務'),(735,'緊急任務'),(736,'緊急任務'),(737,'緊急任務'),(738,'緊急任務'),(739,'緊急任務'),(740,'緊急任務'),(741,'緊急任務'),(742,'緊急任務'),(743,'緊急任務'),(744,'緊急任務'),(745,'緊急任務'),(746,'緊急任務'),(747,'緊急任務'),(748,'緊急任務'),(749,'緊急任務'),(750,'緊急任務'),(751,'緊急任務'),(752,'緊急任務'),(753,'緊急任務'),(754,'緊急任務'),(755,'緊急任務'),(756,'緊急任務'),(757,'緊急任務'),(758,'緊急任務'),(759,'緊急任務'),(760,'緊急任務'),(761,'緊急任務'),(762,'緊急任務'),(763,'緊急任務'),(764,'緊急任務'),(765,'緊急任務'),(766,'緊急任務'),(767,'緊急任務'),(768,'緊急任務'),(769,'緊急任務'),(770,'緊急任務'),(771,'緊急任務'),(772,'緊急任務'),(773,'緊急任務'),(774,'緊急任務'),(775,'緊急任務'),(776,'緊急任務'),(777,'緊急任務'),(778,'緊急任務'),(779,'緊急任務'),(780,'緊急任務'),(781,'緊急任務'),(782,'緊急任務'),(783,'緊急任務'),(784,'緊急任務'),(785,'緊急任務'),(786,'緊急任務'),(787,'緊急任務'),(788,'緊急任務'),(789,'緊急任務'),(790,'緊急任務'),(791,'緊急任務'),(792,'緊急任務'),(793,'緊急任務'),(794,'緊急任務'),(795,'緊急任務'),(796,'緊急任務'),(797,'緊急任務'),(798,'緊急任務'),(799,'緊急任務'),(800,'緊急任務'),(801,'緊急任務'),(802,'緊急任務'),(803,'緊急任務'),(804,'緊急任務'),(805,'緊急任務'),(806,'緊急任務'),(807,'緊急任務'),(808,'緊急任務'),(809,'緊急任務'),(810,'緊急任務'),(811,'緊急任務'),(812,'緊急任務'),(813,'緊急任務'),(814,'緊急任務'),(815,'緊急任務'),(816,'緊急任務'),(817,'緊急任務'),(818,'緊急任務'),(819,'緊急任務'),(820,'緊急任務'),(821,'緊急任務'),(822,'緊急任務'),(823,'緊急任務'),(824,'緊急任務'),(825,'緊急任務'),(826,'緊急任務'),(827,'緊急任務'),(828,'緊急任務'),(829,'緊急任務'),(830,'緊急任務'),(831,'緊急任務'),(832,'緊急任務'),(833,'緊急任務'),(834,'緊急任務'),(835,'緊急任務'),(836,'緊急任務'),(837,'緊急任務'),(838,'緊急任務'),(839,'緊急任務'),(840,'緊急任務'),(841,'緊急任務'),(842,'緊急任務'),(843,'緊急任務'),(844,'緊急任務'),(845,'緊急任務'),(846,'緊急任務'),(847,'緊急任務'),(848,'緊急任務'),(849,'緊急任務'),(850,'緊急任務'),(851,'緊急任務'),(852,'緊急任務'),(853,'緊急任務'),(854,'緊急任務'),(855,'緊急任務'),(856,'緊急任務'),(857,'緊急任務'),(858,'緊急任務'),(859,'緊急任務'),(860,'緊急任務'),(861,'緊急任務'),(862,'緊急任務'),(863,'緊急任務'),(864,'緊急任務'),(865,'緊急任務'),(866,'緊急任務'),(867,'緊急任務'),(868,'緊急任務'),(869,'緊急任務'),(870,'緊急任務'),(871,'緊急任務'),(872,'緊急任務'),(873,'緊急任務'),(874,'緊急任務'),(875,'緊急任務'),(876,'緊急任務'),(877,'緊急任務'),(878,'緊急任務'),(879,'緊急任務'),(880,'緊急任務'),(881,'緊急任務'),(882,'緊急任務'),(883,'緊急任務'),(884,'緊急任務'),(885,'緊急任務'),(886,'緊急任務'),(887,'緊急任務'),(888,'緊急任務'),(889,'緊急任務'),(890,'緊急任務'),(891,'緊急任務'),(892,'緊急任務'),(893,'緊急任務'),(894,'緊急任務'),(895,'緊急任務'),(896,'緊急任務'),(897,'緊急任務'),(898,'緊急任務'),(899,'緊急任務'),(900,'緊急任務'),(901,'緊急任務'),(902,'緊急任務'),(903,'覺醒 - 龍捲風 1'),(904,'覺醒 - 龍捲風 2'),(905,'覺醒 - 龍捲風 3'),(906,'覺醒 - 龍捲風 4'),(907,'緊急任務'),(908,'緊急任務'),(909,'覺醒 - 毒姬 1'),(910,'覺醒 - 毒姬 2'),(911,'覺醒 - 毒姬 3'),(912,'覺醒 - 毒姬 4'),(913,'緊急任務'),(914,'覺醒 - 百花繚亂 (1/4)'),(915,'覺醒 - 百花繚亂 (2/4)'),(916,'覺醒 - 百花繚亂 (3/4)'),(917,'覺醒 - 百花繚亂 (4/4)'),(918,'緊急任務'),(919,'覺醒 - 鬥魂 1'),(920,'覺醒 - 鬥魂 2'),(921,'覺醒 - 鬥魂 3'),(922,'覺醒 - 鬥魂 4'),(923,'緊急任務'),(924,'緊急任務'),(925,'覺醒 - 毀滅者 1'),(926,'覺醒 - 毀滅者 2'),(927,'覺醒 - 毀滅者 3'),(928,'覺醒 - 毀滅者 4'),(929,'緊急任務'),(930,'覺醒 - 亡命之徒 1'),(931,'覺醒 - 亡命之徒 2'),(932,'覺醒 - 亡命之徒 3'),(933,'覺醒 - 亡命之徒 4'),(934,'緊急任務'),(935,'緊急任務'),(936,'覺醒 - 機械戰神 1'),(937,'覺醒 - 機械戰神 2'),(938,'覺醒 - 機械戰神 3'),(939,'覺醒 - 機械戰神 4'),(940,'緊急任務'),(941,'緊急任務'),(942,'覺醒 - 將軍 1'),(943,'覺醒 - 將軍 2'),(944,'覺醒 - 將軍 3'),(945,'覺醒 - 將軍 4'),(946,'緊急任務'),(947,'緊急任務'),(948,'覺醒 - 大魔導士 1'),(949,'覺醒 - 大魔導士 2'),(950,'覺醒 - 大魔導士 3'),(951,'覺醒 - 大魔導士 4'),(952,'緊急任務'),(953,'緊急任務'),(954,'緊急任務'),(955,'緊急任務'),(956,'緊急任務'),(957,'覺醒 - 月之女皇 1'),(958,'覺醒 - 月之女皇 2'),(959,'覺醒 - 月之女皇 3'),(960,'覺醒 - 月之女皇 4'),(961,'緊急任務'),(962,'緊急任務'),(963,'緊急任務'),(964,'緊急任務'),(965,'緊急任務'),(966,'緊急任務'),(967,'覺醒 - 貝亞娜鬥神 1'),(968,'覺醒 - 貝亞娜鬥神 2'),(969,'覺醒 - 貝亞娜鬥神 3'),(970,'覺醒 - 貝亞娜鬥神 4'),(971,'緊急任務'),(972,'緊急任務'),(973,'緊急任務'),(974,'覺醒 - 劍聖 1'),(975,'覺醒 - 劍聖 2'),(976,'覺醒 - 劍聖 3'),(977,'覺醒 - 劍聖 4'),(978,'緊急任務'),(979,'緊急任務'),(980,'緊急任務'),(981,'覺醒 - 魂狩 1'),(982,'覺醒 - 魂狩 2'),(983,'覺醒 - 魂狩 3'),(984,'覺醒 - 魂狩 4'),(985,'緊急任務'),(986,'緊急任務'),(987,'緊急任務'),(988,'覺醒 - 獄血魔神 1'),(989,'覺醒 - 獄血魔神 2'),(990,'覺醒 - 獄血魔神 3'),(991,'覺醒 - 獄血魔神 4'),(992,'緊急任務'),(993,'緊急任務'),(994,'緊急任務'),(995,'覺醒 - 大暗黑天 1'),(996,'覺醒 - 大暗黑天 2'),(997,'覺醒 - 大暗黑天 3'),(998,'覺醒 - 大暗黑天 4'),(999,'轉職 - (Class Change)'),(1000,'緊急任務'),(1001,'緊急任務'),(1002,'緊急任務'),(1004,'緊急任務'),(1005,'緊急任務'),(1006,'緊急任務'),(1007,'緊急任務'),(1008,'緊急任務'),(1009,'緊急任務'),(1010,'緊急任務'),(1011,'緊急任務'),(1012,'學習技能 1'),(1013,'緊急任務'),(1015,'緊急任務'),(1016,'賽莉亞'),(1017,'緊急任務'),(1018,'緊急任務'),(1019,'緊急任務'),(1020,'緊急任務'),(1021,'緊急任務'),(1022,'緊急任務'),(1023,'緊急任務'),(1024,'緊急任務'),(1025,'緊急任務'),(1026,'緊急任務'),(1027,'緊急任務'),(1028,'收集美麗的小晶塊'),(1029,'緊急任務'),(1030,'緊急任務'),(1031,'緊急任務'),(1032,'緊急任務'),(1033,'緊急任務'),(1034,'緊急任務'),(1035,'緊急任務'),(1036,'緊急任務'),(1037,'緊急任務'),(1038,'緊急任務'),(1039,'緊急任務'),(1040,'緊急任務'),(1041,'緊急任務'),(1042,'緊急任務'),(1043,'緊急任務'),(1044,'緊急任務'),(1045,'緊急任務'),(1046,'緊急任務'),(1047,'緊急任務'),(1048,'緊急任務'),(1049,'緊急任務'),(1052,'緊急任務'),(1053,'緊急任務'),(1054,'緊急任務'),(1055,'緊急任務'),(1056,'緊急任務'),(1057,'緊急任務'),(1058,'緊急任務'),(1059,'緊急任務'),(1060,'緊急任務'),(1061,'緊急任務'),(1062,'新菜單 - 德雷克香檳'),(1063,'緊急任務'),(1064,'新菜單 - 特烤章魚燒'),(1065,'緊急任務'),(1066,'緊急任務'),(1067,'緊急任務'),(1068,'緊急任務'),(1069,'緊急任務'),(1070,'緊急任務'),(1071,'緊急任務'),(1072,'緊急任務'),(1073,'緊急任務'),(1074,'緊急任務'),(1075,'緊急任務'),(1076,'緊急任務'),(1077,'緊急任務'),(1078,'緊急任務'),(1079,'緊急任務'),(1080,'緊急任務'),(1081,'緊急任務'),(1082,'緊急任務'),(1083,'種族的榮耀'),(1084,'緊急任務'),(1085,'緊急任務'),(1086,'緊急任務'),(1087,'緊急任務'),(1088,'緊急任務'),(1089,'緊急任務'),(1090,'緊急任務'),(1091,'緊急任務'),(1092,'緊急任務'),(1093,'緊急任務'),(1094,'緊急任務'),(1095,'緊急任務'),(1096,'緊急任務'),(1097,'緊急任務'),(1098,'緊急任務'),(1099,'緊急任務'),(1100,'緊急任務'),(1101,'緊急任務'),(1102,'緊急任務'),(1103,'緊急任務'),(1104,'緊急任務'),(1105,'緊急任務'),(1106,'G.S.D的修練 - 心眼'),(1107,'緊急任務'),(1108,'緊急任務'),(1109,'魔力提取 - 螢石'),(1110,'緊急任務'),(1111,'緊急任務'),(1112,'緊急任務'),(1113,'緊急任務'),(1114,'緊急任務'),(1115,'緊急任務'),(1116,'緊急任務'),(1117,'緊急任務'),(1118,'緊急任務'),(1119,'緊急任務'),(1120,'緊急任務'),(1121,'緊急任務'),(1122,'緊急任務'),(1123,'緊急任務'),(1124,'緊急任務'),(1125,'緊急任務'),(1126,'緊急任務'),(1127,'緊急任務'),(1128,'緊急任務'),(1129,'緊急任務'),(1130,'緊急任務'),(1131,'緊急任務'),(1132,'緊急任務'),(1133,'緊急任務'),(1134,'緊急任務'),(1135,'緊急任務'),(1136,'緊急任務'),(1137,'緊急任務'),(1138,'緊急任務'),(1139,'緊急任務'),(1140,'緊急任務'),(1141,'緊急任務'),(1142,'緊急任務'),(1143,'緊急任務'),(1144,'緊急任務'),(1145,'緊急任務'),(1148,'緊急任務'),(1149,'緊急任務'),(1151,'緊急任務'),(1153,'緊急任務'),(1154,'驅動迷你鑽頭'),(1155,'緊急任務'),(1156,'收集廢棄物品'),(1157,'緊急任務'),(1158,'緊急任務'),(1159,'緊急任務'),(1160,'緊急任務'),(1161,'緊急任務'),(1163,'緊急任務'),(1164,'緊急任務'),(1165,'緊急任務'),(1166,'緊急任務'),(1167,'魔力提取 - 尖晶石'),(1168,'緊急任務'),(1169,'緊急任務'),(1170,'緊急任務'),(1171,'緊急任務'),(1172,'緊急任務'),(1173,'緊急任務'),(1174,'緊急任務'),(1175,'緊急任務'),(1176,'緊急任務'),(1177,'緊急任務'),(1178,'緊急任務'),(1179,'緊急任務'),(1180,'緊急任務'),(1181,'緊急任務'),(1182,'緊急任務'),(1183,'緊急任務'),(1184,'緊急任務'),(1185,'緊急任務'),(1186,'緊急任務'),(1187,'緊急任務'),(1188,'緊急任務'),(1189,'緊急任務'),(1190,'緊急任務'),(1191,'緊急任務'),(1192,'緊急任務'),(1193,'緊急任務'),(1194,'緊急任務'),(1195,'緊急任務'),(1196,'緊急任務'),(1197,'緊急任務'),(1198,'緊急任務'),(1199,'緊急任務'),(1200,'緊急任務'),(1201,'緊急任務'),(1202,'緊急任務'),(1203,'緊急任務'),(1204,'緊急任務'),(1205,'緊急任務'),(1206,'緊急任務'),(1207,'魔力提取 - 龍人之眼'),(1208,'緊急任務'),(1209,'緊急任務'),(1210,'緊急任務'),(1211,'緊急任務'),(1212,'緊急任務'),(1213,'緊急任務'),(1214,'緊急任務'),(1215,'緊急任務'),(1216,'緊急任務'),(1217,'緊急任務'),(1218,'緊急任務'),(1219,'牛頭的鍊金術考察'),(1220,'緊急任務'),(1221,'緊急任務'),(1222,'緊急任務'),(1223,'緊急任務'),(1224,'緊急任務'),(1225,'魔力提取 - 鋯石'),(1226,'緊急任務'),(1227,'緊急任務'),(1230,'緊急任務'),(1231,'緊急任務'),(1232,'緊急任務'),(1233,'緊急任務'),(1234,'緊急任務'),(1235,'緊急任務'),(1236,'緊急任務'),(1237,'緊急任務'),(1238,'緊急任務'),(1239,'緊急任務'),(1240,'緊急任務'),(1241,'凱莉的考驗'),(1242,'緊急任務'),(1243,'製作柯卡穆的干擾晶片'),(1244,'緊急任務'),(1245,'緊急任務'),(1246,'緊急任務'),(1247,'緊急任務'),(1248,'緊急任務'),(1249,'緊急任務'),(1250,'緊急任務'),(1251,'緊急任務'),(1252,'緊急任務'),(1253,'緊急任務'),(1254,'緊急任務'),(1255,'緊急任務'),(1256,'緊急任務'),(1257,'緊急任務'),(1258,'緊急任務'),(1259,'擊退盜賊團'),(1260,'消滅盜賊團'),(1261,'盜賊團的狗'),(1262,'緊急任務'),(1263,'緊急任務'),(1264,'緊急任務'),(1265,'緊急任務'),(1266,'緊急任務'),(1267,'緊急任務'),(1268,'緊急任務'),(1269,'緊急任務'),(1270,'緊急任務'),(1271,'緊急任務'),(1272,'緊急任務'),(1273,'緊急任務'),(1274,'緊急任務'),(1275,'緊急任務'),(1276,'緊急任務'),(1277,'緊急任務'),(1278,'緊急任務'),(1279,'緊急任務'),(1280,'緊急任務'),(1281,'緊急任務'),(1282,'緊急任務'),(1283,'緊急任務'),(1284,'緊急任務'),(1285,'緊急任務'),(1286,'緊急任務'),(1287,'緊急任務'),(1288,'緊急任務'),(1289,'緊急任務'),(1290,'緊急任務'),(1291,'緊急任務'),(1292,'緊急任務'),(1293,'緊急任務'),(1294,'緊急任務'),(1295,'緊急任務'),(1296,'緊急任務'),(1297,'緊急任務'),(1298,'緊急任務'),(1299,'緊急任務'),(1300,'緊急任務'),(1301,'緊急任務'),(1302,'緊急任務'),(1303,'緊急任務'),(1304,'緊急任務'),(1305,'緊急任務'),(1306,'緊急任務'),(1307,'緊急任務'),(1308,'緊急任務'),(1309,'緊急任務'),(1310,'緊急任務'),(1311,'緊急任務'),(1312,'緊急任務'),(1313,'緊急任務'),(1314,'緊急任務'),(1315,'緊急任務'),(1316,'緊急任務'),(1317,'緊急任務'),(1318,'緊急任務'),(1319,'緊急任務'),(1320,'緊急任務'),(1321,'緊急任務'),(1322,'緊急任務'),(1323,'緊急任務'),(1324,'緊急任務'),(1325,'緊急任務'),(1326,'緊急任務'),(1327,'緊急任務'),(1328,'緊急任務'),(1329,'緊急任務'),(1330,'緊急任務'),(1331,'緊急任務'),(1332,'[古代地下城] 不滅之王'),(1333,'緊急任務'),(1334,'緊急任務'),(1335,'緊急任務'),(1336,'緊急任務'),(1337,'緊急任務'),(1338,'緊急任務'),(1339,'緊急任務'),(1340,'緊急任務'),(1341,'緊急任務'),(1342,'緊急任務'),(1343,'緊急任務'),(1344,'緊急任務'),(1345,'緊急任務'),(1346,'緊急任務'),(1347,'緊急任務'),(1348,'緊急任務'),(1349,'緊急任務'),(1350,'緊急任務'),(1351,'緊急任務'),(1352,'緊急任務'),(1353,'緊急任務'),(1354,'緊急任務'),(1355,'緊急任務'),(1356,'緊急任務'),(1357,'緊急任務'),(1358,'緊急任務'),(1359,'緊急任務'),(1360,'緊急任務'),(1361,'緊急任務'),(1362,'緊急任務'),(1363,'緊急任務'),(1364,'緊急任務'),(1365,'緊急任務'),(1366,'緊急任務'),(1367,'緊急任務'),(1368,'緊急任務'),(1369,'緊急任務'),(1370,'緊急任務'),(1371,'緊急任務'),(1372,'緊急任務'),(1373,'緊急任務'),(1374,'緊急任務'),(1375,'緊急任務'),(1376,'緊急任務'),(1377,'緊急任務'),(1378,'緊急任務'),(1379,'緊急任務'),(1380,'緊急任務'),(1381,'緊急任務'),(1382,'緊急任務'),(1383,'緊急任務'),(1384,'緊急任務'),(1385,'緊急任務'),(1386,'緊急任務'),(1387,'緊急任務'),(1388,'緊急任務'),(1389,'緊急任務'),(1390,'緊急任務'),(1391,'緊急任務'),(1392,'緊急任務'),(1393,'緊急任務'),(1431,'獵人秘密'),(1432,'艾力斯的求援'),(1471,'美食家 - 夏洛克'),(1473,'美味的章魚觸鬚'),(1474,'次品晶片的用途'),(1475,'失蹤的夏洛克'),(1476,'皇帝的大理石像'),(1477,'收集石像碎塊'),(1478,'夏洛克的支援'),(1492,'悲鳴草種子'),(1493,'最好的絲綢'),(1531,'魔法研究 - 光屬性篇'),(1535,'緊急任務'),(1536,'緊急任務'),(1537,'緊急任務'),(1538,'緊急任務'),(1539,'緊急任務'),(1540,'緊急任務'),(1541,'緊急任務'),(1542,'緊急任務'),(1543,'緊急任務'),(1544,'緊急任務'),(1545,'緊急任務'),(1546,'緊急任務'),(1547,'緊急任務'),(1548,'緊急任務'),(1549,'緊急任務'),(1550,'緊急任務'),(1551,'緊急任務'),(1552,'禁止的GBL 教的古文書'),(1553,'不可以存在的物品'),(1555,'緊急任務'),(1556,'操縱石巨人'),(1557,'緊急任務'),(1558,'緊急任務'),(1559,'緊急任務'),(1560,'緊急任務'),(1561,'緊急任務'),(1562,'緊急任務'),(1563,'緊急任務'),(1564,'緊急任務'),(1565,'緊急任務'),(1566,'緊急任務'),(1567,'緊急任務'),(1568,'緊急任務'),(1569,'緊急任務'),(1570,'緊急任務'),(1571,'緊急任務'),(1572,'緊急任務'),(1573,'緊急任務'),(1574,'緊急任務'),(1575,'緊急任務'),(1576,'緊急任務'),(1577,'緊急任務'),(1578,'緊急任務'),(1579,'緊急任務'),(1580,'緊急任務'),(1581,'緊急任務'),(1582,'緊急任務'),(1583,'緊急任務'),(1584,'緊急任務'),(1585,'緊急任務'),(1586,'緊急任務'),(1587,'緊急任務'),(1588,'緊急任務'),(1589,'緊急任務'),(1590,'緊急任務'),(1591,'克倫特的淚水'),(1592,'收集邪念體'),(1593,'緊急任務'),(1594,'緊急任務'),(1595,'緊急任務'),(1596,'緊急任務'),(1597,'緊急任務'),(1598,'緊急任務'),(1599,'緊急任務'),(1600,'緊急任務'),(1601,'緊急任務'),(1602,'緊急任務'),(1603,'緊急任務'),(1604,'緊急任務'),(1605,'緊急任務'),(1606,'緊急任務'),(1607,'緊急任務'),(1608,'緊急任務'),(1609,'緊急任務'),(1610,'緊急任務'),(1611,'奧菲莉亞的家寶'),(1612,'緊急任務'),(1613,'緊急任務'),(1614,'緊急任務'),(1615,'緊急任務'),(1616,'緊急任務'),(1617,'緊急任務'),(1618,'緊急任務'),(1619,'緊急任務'),(1620,'緊急任務'),(1621,'緊急任務'),(1622,'緊急任務'),(1623,'緊急任務'),(1624,'緊急任務'),(1625,'緊急任務'),(1626,'緊急任務'),(1627,'緊急任務'),(1628,'緊急任務'),(1629,'緊急任務'),(1630,'緊急任務'),(1631,'緊急任務'),(1632,'緊急任務'),(1633,'緊急任務'),(1634,'緊急任務'),(1635,'緊急任務'),(1636,'緊急任務'),(1637,'緊急任務'),(1638,'緊急任務'),(1639,'緊急任務'),(1640,'緊急任務'),(1641,'緊急任務'),(1642,'緊急任務'),(1643,'緊急任務'),(1644,'緊急任務'),(1645,'緊急任務'),(1646,'緊急任務'),(1647,'緊急任務'),(1648,'緊急任務'),(1649,'緊急任務'),(1650,'緊急任務'),(1651,'緊急任務'),(1652,'緊急任務'),(1653,'緊急任務'),(1654,'緊急任務'),(1655,'緊急任務'),(1656,'緊急任務'),(1657,'緊急任務'),(1658,'緊急任務'),(1659,'緊急任務'),(1660,'緊急任務'),(1661,'緊急任務'),(1662,'緊急任務'),(1663,'緊急任務'),(1664,'緊急任務'),(1665,'緊急任務'),(1666,'緊急任務'),(1667,'緊急任務'),(1668,'緊急任務'),(1669,'緊急任務'),(1670,'緊急任務'),(1671,'緊急任務'),(1672,'緊急任務'),(1673,'緊急任務'),(1674,'緊急任務'),(1675,'緊急任務'),(1676,'緊急任務'),(1677,'緊急任務'),(1678,'緊急任務'),(1679,'緊急任務'),(1689,'緊急任務'),(1690,'緊急任務'),(1691,'緊急任務'),(1692,'緊急任務'),(1693,'緊急任務'),(1694,'緊急任務'),(1695,'緊急任務'),(1696,'緊急任務'),(1697,'緊急任務'),(1698,'緊急任務'),(1699,'緊急任務'),(1700,'緊急任務'),(1701,'緊急任務'),(1702,'緊急任務'),(1703,'緊急任務'),(1704,'緊急任務'),(1705,'緊急任務'),(1706,'緊急任務'),(1707,'緊急任務'),(1708,'緊急任務'),(1709,'緊急任務'),(1710,'緊急任務'),(1711,'緊急任務'),(1712,'緊急任務'),(1713,'緊急任務'),(1714,'緊急任務'),(1715,'緊急任務'),(1716,'緊急任務'),(1717,'緊急任務'),(1718,'緊急任務'),(1719,'緊急任務'),(1720,'緊急任務'),(1721,'緊急任務'),(1722,'緊急任務'),(1723,'緊急任務'),(1724,'緊急任務'),(1725,'緊急任務'),(1726,'緊急任務'),(1727,'緊急任務'),(1728,'緊急任務'),(1729,'緊急任務'),(1730,'緊急任務'),(1731,'緊急任務'),(1732,'緊急任務'),(1733,'緊急任務'),(1734,'緊急任務'),(1735,'緊急任務'),(1736,'緊急任務'),(1737,'緊急任務'),(1738,'緊急任務'),(1739,'緊急任務'),(1740,'緊急任務'),(1741,'緊急任務'),(1742,'緊急任務'),(1743,'緊急任務'),(1744,'緊急任務'),(1745,'緊急任務'),(1746,'緊急任務'),(1747,'緊急任務'),(1748,'緊急任務'),(1749,'緊急任務'),(1750,'緊急任務'),(1751,'緊急任務'),(1752,'緊急任務'),(1753,'緊急任務'),(1761,'緊急任務'),(1764,'緊急任務'),(1765,'緊急任務'),(1766,'緊急任務'),(1767,'緊急任務'),(1768,'緊急任務'),(1769,'緊急任務'),(1770,'緊急任務'),(1771,'緊急任務'),(1772,'緊急任務'),(1773,'緊急任務'),(1800,'魔法師之路 - 開始'),(1801,'魔法師之路 - 赫頓瑪爾'),(1802,'魔法師之路 - 所謂的轉'),(1803,'更強的敵人'),(1804,'G.S.D的試驗'),(1805,'新武器的威力'),(1806,'魔法師之路 - 艾麗絲'),(1807,'魔法師之路 - 任務商店'),(1901,'鬼劍士之路 - 開始'),(1902,'格鬥家之路 - 開始'),(1903,'神槍之路 - 開始'),(1904,'魔法師之路 - 開始'),(1905,'聖職者之路 - 開始'),(1906,'[古代地下城] 最高級的'),(1907,'[古代地下城] 泰拉石武'),(1908,'[古代地下城] 泰拉石武'),(1909,'[古代地下城] 泰拉石武'),(1910,'[古代地下城] 泰拉石武'),(1911,'[古代地下城] 泰拉石武'),(1915,'最高級的材料泰拉石'),(1916,'神槍之路 - 開始'),(1917,'盜賊之路 - 開始'),(1918,'[古代地下城] 泰拉石武'),(2102,'進化 - 費尼克斯'),(2104,'進化 - 華利弗'),(2105,'進化 - 哈帕斯'),(2108,'進化 - 冰拉波拉斯'),(2109,'進化 - 貝傑夫特 1'),(2110,'進化 - 貝傑夫特 2'),(2111,'進化 - 貝傑夫特 3'),(2112,'進化 - 金豬'),(2254,'火焰的鍛煉 (重複)'),(2322,'木罐的打賭 - 龍人之塔'),(2323,'木罐的打賭 - 人偶玄關'),(2324,'木罐的打賭 - 人偶玄關'),(2325,'木罐的打賭 - 人偶玄關'),(2326,'木罐的打賭 - 人偶玄關'),(2327,'木罐的打賭 - 石巨人塔'),(2328,'木罐的打賭 - 黑暗玄廊'),(2329,'木罐的打賭 - 城主宮殿'),(2334,'水罐的賭注 - 血獄'),(2336,'木罐的打賭 - 人偶玄關'),(2339,'木罐的打賭 - 人偶玄關'),(2354,'大地寶珠'),(2355,'天空寶珠'),(2502,'巴爾雷娜大嬸'),(2503,'獲得班圖的認可 1'),(2504,'獲得班圖的認可 2'),(2505,'拉比納哥哥'),(2506,'兔神的保佑'),(2507,'裝馬奶酒的皮袋子'),(2508,'有用的皮革'),(2509,'班圖族女戰士'),(2511,'班圖族的侵略'),(2512,'班圖族的副族長'),(2514,'30年後覺醒的冰龍斯卡�'),(2515,'班圖族的由來'),(2518,'小孩的聲音'),(2519,'孩子啊… 我的孩子..'),(2520,'查理的身份'),(2521,'守護查理的心臟'),(2522,'永恆的悲慘命運'),(2523,'流逝的生命'),(2524,'把悲傷藏在心裡'),(2528,'斯卡迪女王的親筆信副'),(2529,'班圖族的習俗'),(2603,'深淵派對Ep1 漸漸浮現�'),(2610,'深淵派對Ep2. 邪惡來臨'),(2613,'深淵派對Ep3 - 烏雲籠罩'),(2622,' 深淵派對Ep4 - 天界的�'),(2651,'[古代地下城] 征服悲鳴'),(2702,'專門職業-魔法賦予師'),(2708,'專門職業-鍊金術師'),(2710,'專門職業-解體師'),(2712,'專門職業-人形師'),(2809,'[古代地下城] 泰拉石武'),(2810,'[古代地下城] 泰拉石武'),(2811,'[古代地下城] 泰拉石武'),(2812,'[古代地下城] 泰拉石武'),(2813,'[古代地下城] 泰拉石武'),(2814,'[古代地下城] 泰拉石武'),(2815,'[古代地下城] 泰拉石武'),(2816,'[古代地下城] 泰拉石武'),(2817,'[古代地下城] 泰拉石武'),(2818,'[古代地下城] 泰拉石武'),(2819,'[古代地下城] 泰拉石首'),(2820,'[古代地下城] 泰拉石首'),(2821,'[古代地下城] 泰拉石首'),(2822,'[古代地下城] 泰拉石武'),(2823,'[古代地下城] 泰拉石武'),(3500,'追捕逃亡者 1'),(3501,'追捕逃亡者 2 '),(3502,'追捕逃亡者 3'),(3576,'恐懼之源 (重複)'),(3588,'調查死亡之塔'),(3589,'預言家希莫娜'),(3590,'死神與希莫娜的關係'),(3591,'征服死亡之塔'),(3592,'死神德萊弗斯的目的'),(3606,'死神的氣息 - 神秘的影'),(3611,'混沌魔石碎片 (重複)'),(3612,'混沌魔石 (重複)'),(3700,'冰龍的威脅'),(3701,'冰女王的傳說'),(3702,'[古代地下城] 王的冤魂'),(3703,'消滅盜賊團'),(3704,'[遠古 - 招募公告: 比爾'),(3705,'笛聲… 與復仇'),(3706,'暗黑城的無頭門衛'),(3707,'[古代地下城] 再次傳來'),(3711,'除掉鬼魂'),(3712,'破壞蜘蛛卵'),(3713,'[異界地下城]收集哥布�'),(3714,'[異界地下城]過去的天�'),(3715,'[異界地下城]威脅帝國�'),(3716,'召募潛入奧德薩街頭的'),(3717,'都市的超能力者'),(3718,'卡勒特的暗號文類型'),(3719,'[古代地下城] 爆發瘟疫'),(3720,'協同 : 夜間襲擊戰'),(3721,'協同 : 補給線阻斷戰'),(3722,'協同 : 追擊殲滅戰'),(3723,'協同 : 血蝴蝶之舞'),(3724,'協同 : 疑惑之村'),(3725,'協同 : 列車上的海賊'),(3726,'協同 : 奪回西部線'),(3727,'零件名稱： GT-203'),(3728,'海賊們的財產'),(3801,'奧菲利亞的信'),(3802,'G.B.L 阿拉德分部'),(3803,'魔手沒有伸過來？'),(3804,'所有的一切都是騙局'),(3805,'G.B.L 阿拉德分部'),(3806,'G.B.L 研究所'),(3808,'潛入怪物研究所'),(3809,'G.B.L 研究所的研究資料'),(3810,'實驗物32-4β'),(3811,'希特拉克的恐怖'),(3812,'破壞實驗工具！'),(3813,'讓希特拉克廢棄吧'),(3814,'羅特斯的卵還存在！'),(3815,'破壞羅特斯的卵的方法'),(3816,'裝胃液的容器'),(3819,'破壞羅特斯的卵'),(3820,'血腥淨化突擊隊長班傑'),(3821,'擊敗班傑里斯'),(3823,'珍貴的古文書'),(3824,'收集GBL教假面'),(3825,'破壞GBL巨像'),(3826,'神秘的古代書籍'),(3827,'特殊的洗碗工具'),(3828,'破壞實驗物TLF-3'),(3829,'除掉菲裡斯'),(3901,'前往奧德薩的道路'),(3902,'需要哥布林的協助'),(3903,'垃圾堆中的遊俠'),(3904,'奧德薩街頭'),(3905,'鐵蓋'),(3906,'火箭人'),(3907,'莫納亨的秘密'),(3908,'德魯伊米亞'),(3909,'蟲之狄桑'),(3910,'念動力者麥瑟·莫納亨'),(3911,'詭異的物體'),(3914,'究竟是誰操作能力好？'),(3915,'殊死戰'),(3918,'正面交鋒'),(3922,'艾麗絲喜歡書'),(4000,'為了更好的明天'),(4001,'請求'),(4002,'鷹眼的考驗'),(4003,'瑪拉格的考驗'),(4004,'拉裡的考驗'),(4005,'美杜莎的考驗'),(4006,'雀瑟的挑戰'),(4007,'被阻擋的路'),(4008,'灰衣劍士'),(4009,'敏泰的打賭'),(4010,'雷諾的打賭'),(4011,'四戰士'),(4012,'與雀瑟的較量'),(4013,'與布萬加對練'),(4014,'英雄的試練'),(4015,'維納斯女神'),(4016,'古老的羊皮紙'),(4017,'偽造文書'),(4018,'GBL女神殿'),(4019,'女神的詛咒'),(4020,'解除詛咒'),(4021,'詛咒的結晶'),(4022,'淨化女神殿'),(4023,'獵人秘密2'),(4024,'天帷巨獸的生態系統調'),(4025,'木本植物的樣本 1'),(4026,'木本植物的樣本 2'),(4027,'採集弗賴爾的血液'),(4028,'使徒造成的影響'),(4029,'繁殖的主犯'),(4030,'清掃GBL信徒餘黨'),(4031,'天帷巨獸的生態系統調'),(4032,'皇女的下落'),(4033,'你知道海賊團？'),(4034,'向馬琳報告'),(4035,'獲得海賊信賴的方法'),(4036,'錢買來的信賴'),(4037,'皇女在西部無法地帶…'),(4038,'開向無法地帶的海上列'),(4039,'霧之都海伊茲'),(4040,'除掉守衛'),(4041,'皇女在哪裡？'),(4042,'斯提班普拉丁'),(4043,'梅爾文·里克特的特製�'),(4044,'皇女的下落'),(4045,'狙擊瞄準鏡'),(4047,'協同 : 霧之都海伊茲'),(4048,'收集勳章'),(4049,'決戰'),(4050,'必死的抗戰'),(4051,'舊時代的終結'),(4052,'老當益壯哈斯'),(4053,'傳說的結束'),(4054,'黎明之眼的安祖賽弗'),(4055,'安祖‧賽弗的殘影'),(4056,'收集卡勒特情報'),(4057,'自作自受'),(4058,'不共戴天'),(4059,'臥薪嘗膽'),(4060,'事必歸正'),(4061,'乾坤一擲'),(4062,'去卡勒特司令部…。'),(4065,'轉職 - 元素爆破師（Ele'),(4068,'轉職 - 冰結師（Glacial M'),(4069,'青龍大會'),(4070,'取得青龍大會參加資格'),(4071,'青龍大會優勝'),(4072,'青龍資格（重複）'),(4073,'藍色念氣'),(4074,'黑暗念氣'),(4076,'穿越紅色森林'),(4077,'鐵人之城修南'),(4078,'黃龍大會'),(4079,'取得黃龍大會參加資格'),(4080,'黃龍大會優勝'),(4081,'黃龍的資格（重複）'),(4082,'覺醒 - 魔皇 1'),(4083,'覺醒 - 魔皇 2'),(4084,'覺醒 - 魔皇 3'),(4085,'覺醒 - 魔皇 4'),(4086,'覺醒 - 冰霜之心 1'),(4087,'覺醒 - 冰霜之心 2'),(4088,'覺醒 - 冰霜之心 3'),(4089,'覺醒 - 冰霜之心 4'),(4090,'勇者 - 異次元裂縫的旅'),(4091,'勇者 - 壓制異界氣息的'),(4092,'勇者 - 蘊含異界氣息的'),(4093,'勇者 - 重領蘊含異界氣'),(4094,'勇者 - 蘊含異界氣息的'),(4095,'勇者 - 重領蘊含異界氣'),(4099,'紫色念氣'),(4100,'金色念氣'),(4101,'灰衣劍士'),(4102,'探索'),(4103,'酒館的暴動'),(4104,'赫頓尼斯幫的霍利奧'),(4105,'目擊者'),(4106,'再會的約定'),(4107,'賒帳'),(4108,'除掉惡棍'),(4109,'霍利奧的挑戰'),(4110,'赫頓尼斯幫的襲擊'),(4111,'收集隱約發光的曲玉'),(4112,'收集華麗的曲玉'),(4201,'危機的根特'),(4202,'偵查根特週邊'),(4203,'拯救被俘的冒險家'),(4204,'馬琳的呼喚'),(4205,'維持治安'),(4206,'破解暗號 - 1'),(4207,'阻止縱火兵'),(4208,'被稱為「沙影」的男人'),(4209,'教訓縱火犯'),(4210,'向澤丁·施奈德報告'),(4212,'喧鬧的城外'),(4213,'阻止機動隊入侵'),(4214,'破解暗號 - 2'),(4215,'暗號傳遞的資訊'),(4216,'擾亂轟炸目標'),(4217,'阻止埋設地雷'),(4218,'殲滅機動隊員'),(4220,'被改造的卡勒特士兵'),(4221,'掌握卡勒特組織的資訊'),(4222,'維修城牆'),(4224,'獲得急救箱'),(4225,'暴風雷兄弟？'),(4226,'解體摩托車'),(4227,'驅逐縱火兵'),(4228,'疾風之蘇雷德'),(4257,'澤丁·施奈德的請求'),(4258,'遺失的AT-5T 步行者'),(4259,'AT-5T 步行者的操作方法'),(4260,'回收AT-5T 步行者'),(4261,'皇都軍的生機'),(4262,'消滅北門的敵人'),(4263,'卡勒特的指令書'),(4264,'突擊隊長左倫'),(4265,'卡勒特諜報員'),(4266,'機械臂沃傑'),(4267,'破壞掩蔽物'),(4268,'卡勒特的戰略'),(4269,'解體技師'),(4270,'喜愛分解'),(4271,'巡查根特北門'),(4272,'垃圾回收從我做起'),(4273,'AT-5T 步行者訓練'),(4274,'調查機械臂'),(4275,'清掃垃圾'),(4276,'不確切的情報'),(4277,'巡查根特森林'),(4278,'再探根特森林'),(4279,'游擊隊的蹤跡'),(4280,'確認游擊隊兵力'),(4281,'棘手的醫療兵'),(4282,'保衛根特'),(4283,'最後的支援兵'),(4284,'爭取作戰時間'),(4285,'不同尋常的攻擊'),(4286,'研究大砲'),(4287,'缺少研究資料'),(4288,'傳達研究資料'),(4289,'與預想的一樣'),(4290,'堅持就是勝利'),(4291,'防守根特週邊'),(4292,'撿取炮身'),(4293,'調查殘餘兵器'),(4294,'破壞遺留的武器'),(4295,'根特防禦戰'),(4296,'想做狗肉湯？'),(4297,'消滅炮擊部隊'),(4298,'根特防禦的第一步'),(4301,'與賽莉亞的緣分'),(4302,'隕落的哥布林的傳說'),(4303,'怪獸獵殺者'),(4305,'鬼手的反應'),(4306,'不尋常的天空之城氣息'),(4307,'G.S.D親自出馬'),(4308,'去更高地方'),(4309,'鬼手啊，你到底想說什'),(4310,'朝向天空之城的最上層'),(4311,'朝向天空之城的最上層'),(4312,'和賽格哈特對決'),(4313,'答案在使徒身上'),(4314,'變成石像的冒險家'),(4315,'光之軍隊'),(4316,'石刃拉澤爾'),(4317,'另一個懸空城'),(4318,'懸空城的無重力碎片 1'),(4319,'懸空城的無重力碎片 2'),(4321,'占卜師艾麗絲'),(4324,'使徒是為了什麼而存在'),(4325,'衰弱的羅特斯'),(4326,'消滅羅特斯'),(4327,'沉睡吧，羅特斯'),(4328,'使徒的死亡，重生的希'),(4330,'[古代地下城] 林納斯的'),(4331,'[古代地下城] 布萬加的'),(4332,'[古代地下城] 林納斯的'),(4333,'[古代地下城] 布萬加的'),(4334,'[古代地下城] 林納斯的'),(4335,'[古代地下城] 布萬加的'),(4336,'[古代地下城] 林納斯的'),(4337,'[古代地下城] 布萬加的'),(4338,'[古代地下城] 林納斯的'),(4339,'[古代地下城] 布萬加的'),(4340,'[古代地下城] 神聖的刀'),(4341,'[古代地下城] 探索悲鳴'),(4342,'[古代地下城] 探索悲鳴'),(4343,'[古代地下城] 探索悲鳴'),(4344,'[古代地下城] 探索悲鳴'),(4345,'[古代地下城] 探索悲鳴'),(4346,'[古代地下城] 消滅戮蠱'),(4347,'[古代地下城] 強大的支'),(4348,'[古代地下城] 強大的支'),(4349,'[古代地下城] 強大的支'),(4350,'[古代地下城] 強大的支'),(4351,'[古代地下城] 強大的支'),(4352,'[古代地下城]  支援者�'),(4353,'[古代地下城]  支援者�'),(4354,'[古代地下城]  支援者�'),(4355,'[古代地下城]  支援者�'),(4356,'[古代地下城]  支援者�'),(4357,'[古代地下城] 骷髏凱恩'),(4358,'[古代地下城] 與阿甘左'),(4359,'[古代地下城] 阿甘左的'),(4360,'看不見的希望'),(4361,'構築防禦線'),(4362,'秘密的召喚'),(4363,'奪取彈藥'),(4364,'奇怪的兵器'),(4365,'機動兵器 GT-9600'),(4366,'寡不敵眾'),(4367,'機動兵器的弱點'),(4368,'收集資料'),(4369,'製作兵器'),(4370,'破壞通訊器'),(4371,'卡勒特幹部的徽章 (重�'),(4372,'[古代地下城] 林納斯的'),(4373,'[古代地下城] 布萬加的'),(4374,'[古代地下城] 探索悲鳴'),(4375,'[古代地下城] 強大的支'),(4376,'[古代地下城]  支援者�'),(4377,'[古代地下城] 生命是珍'),(4378,'[古代地下城] 重回故地'),(4379,'[古代地下城] 相似的人'),(4404,'摩根的遺言'),(4405,'偵察'),(4406,'蜘蛛洞穴'),(4407,'艾克洛索'),(4408,'魯莽的菜鳥'),(4409,'不必要的慈悲'),(4410,'冒險的妨礙'),(4411,'令人煩躁的慘叫聲'),(4414,'終於開啟的天界之門'),(4415,'前往天界'),(4416,'天界的守備隊長'),(4417,'先發制人'),(4419,'火的鍛煉'),(4420,'[古代地下城]  古代王�'),(4421,'[古代地下城]  古代王�'),(4422,'只剩下暗黑城入口了'),(4423,'基礎很重要'),(4424,'卡勒特幹部的徽章'),(4425,'[古代地下城] 歌蘭蒂斯'),(4426,'[古代地下城] 歌蘭蒂斯'),(4427,'恭喜你轉職了！'),(4428,'恭喜你轉職了！'),(4429,'恭喜你轉職了！'),(4430,'恭喜你轉職了！'),(4431,'恭喜你轉職了！'),(4432,'恭喜你轉職了！'),(4433,'恭喜你轉職了！'),(4434,'恭喜你轉職了！'),(4435,'恭喜你轉職了！'),(4436,'[古代地下城]  王的榮�'),(4437,'老朋友 - 戒指 (1/3)'),(4438,'老朋友 - 手環 (2/3)'),(4439,'老朋友 - 項鍊 (3/3)'),(4440,'灰色結晶和賽莉亞'),(4441,'為了獲得結晶的魔法'),(4442,'抽取結晶的氣息'),(4443,'[古代地下城] 無法前往'),(4444,'[古代地下城] 曾經平靜'),(4445,'[古代地下城] 摩根的日'),(4446,'[古代地下城] 艾麗絲的'),(4447,'[古代地下城] 使徒的氣'),(4448,'[古代地下城] 意料之外'),(4449,'[古代地下城] 狄瑞吉的'),(4450,'[古代地下城] 解不開的'),(4451,'[古代地下城] 解不開的'),(4452,'[古代地下城] 如果是偽'),(4453,'[古代地下城] 偽裝者的'),(4454,'[古代地下城] 暴戾搜捕'),(4455,'[古代地下城] 歌蘭蒂斯'),(4456,'[古代地下城] 格拉西亞'),(4457,'[古代地下城] 免疫魔法'),(4461,'壓抑的悲鳴聲'),(4462,'記憶中的往事'),(4465,'第一個時間碎片 - 洛藍'),(4466,'阿法利亞的危機'),(4467,'暗精靈的危機'),(4468,'加爾伊萊絲'),(4469,'第二個時間碎片'),(4470,'尋找時間碎片1'),(4471,'尋找時間碎片2'),(4472,'脆弱的時間碎片'),(4473,'強化的時間碎片 1'),(4474,'強化的時間碎片 2'),(4475,'一定要更強'),(4476,'新的力量 - 任務商店'),(4477,'時間碎片 - 格蘭之森'),(4478,'時間碎片 - 第一個時間'),(4479,'時間碎片 - 天帷巨獸'),(4480,'時間碎片 - 諾伊佩拉'),(4481,'時間碎片 - 暗黑城'),(4482,'時間碎片 -萬年雪山'),(4483,'時間碎片 - 墮落殿堂'),(4484,'時間碎片 - 諾斯瑪爾'),(4485,'時間碎片 - 陌生要塞'),(4486,'時間碎片 - 安特貝爾峽'),(4487,'時間碎片 - 海上列車'),(4491,'[古代地下城] 林納斯的'),(4492,'[古代地下城] 布萬加的'),(4493,'[古代地下城] 探索悲鳴'),(4494,'[古代地下城] 強大的支'),(4495,'[古代地下城]  支援者�'),(4500,'帝國想要你！'),(4501,'白色影子的怪物'),(4503,'暴風前夕'),(4504,'不詳的預感'),(4505,'咆哮的聲音'),(4506,'我族背負的業報'),(4514,'巴爾雷娜的記憶力'),(4515,'初次看見的衣料'),(4516,'煩人的魔法師'),(4520,'廢墟中移動的白色巨物'),(4521,'母親的擔心'),(4522,'異變現象的影子'),(4523,'披上敵人的外衣'),(4525,'母親的心思'),(4526,'雪山的號角'),(4527,'以眼還眼， 以牙還牙'),(4528,'化成雪飄落'),(4536,'雀瑟飲酒的理由'),(4537,'醒酒'),(4538,'一爭高下'),(4542,'班圖的傳統民謠'),(4543,'洛絲之歌'),(4544,'無法置信'),(4545,'一線希望'),(4546,'守護夢想'),(4547,'發現線索'),(4548,'被發現的內幕，羅希的'),(4549,'實現最後的夢想'),(4557,'冰霜中的呼喚'),(4558,'尋找洛希婭的蹤跡'),(4559,'有淒涼故事的年輕人'),(4560,'說服，可是'),(4561,'真正的禮物'),(4562,'不沉睡的龍'),(4563,'忍耐的極限'),(4564,'決斷'),(4565,'給帝國的信'),(4566,'帝國的來信'),(4567,'生死一念間'),(4568,'決戰，斯卡薩！'),(4569,'死鬥的證據'),(4571,'最後一擊'),(4572,'雪之榮譽'),(4601,'行蹤不明的羅莉安'),(4603,'斯卡迪女王的親筆信'),(4605,'收集防具材料'),(4606,'怪異的收集癖'),(4607,'讓徘徊的靈魂安息'),(4608,'羅特斯的傀儡'),(4609,'叢林支配者羅丁'),(4610,'黑暗中的狩獵大師'),(4611,'龍頭炮的操縱者'),(4612,'大神官諾特魯'),(4613,'最後的抵抗'),(5001,'[古代地下城] 林納斯的'),(5002,'[古代地下城] 布萬加的'),(5003,'[古代地下城] 探索悲鳴'),(5004,'[古代地下城] 探尋強力'),(5005,'[古代地下城]  支援者�'),(5151,'[異界地下城] 奇怪的管'),(5152,'[異界地下城] 封印之地'),(5153,'[異界地下城] 異次元裂'),(5154,'[古代地下城] 城… 那�'),(5155,'[異界地下城] 異次元裂'),(5156,'[異界地下城] 蘭蒂盧斯'),(5157,'[異界地下城] 凱莉的委'),(5270,'光輝之魔石碎片 (重複)'),(5307,'覺醒 - 天啟聖徒 1'),(5308,'覺醒 - 天啟聖徒 2'),(5309,'覺醒 - 天啟聖徒 3'),(5310,'覺醒 - 天啟聖徒 4'),(5314,'覺醒 - 神之手 1'),(5315,'覺醒 - 神之手 2'),(5316,'覺醒 - 神之手 3'),(5317,'覺醒 - 神之手 4'),(5321,'覺醒 - 龍鬥士 1'),(5322,'覺醒 - 龍鬥士 2'),(5323,'覺醒 - 龍鬥士 3'),(5324,'覺醒 - 龍鬥士 4'),(5329,'覺醒 - 血色玫瑰 1'),(5330,'覺醒 - 血色玫瑰 2'),(5331,'覺醒 - 血色玫瑰 3'),(5332,'覺醒 - 血色玫瑰 4'),(5333,'覺醒 - 殲滅者 1'),(5334,'覺醒 - 殲滅者 2'),(5335,'覺醒 - 殲滅者 3'),(5336,'覺醒 - 殲滅者 4'),(5340,'覺醒 - 鋼鐵之心 1'),(5341,'覺醒 - 鋼鐵之心 2'),(5342,'覺醒 - 鋼鐵之心 3'),(5343,'覺醒 - 鋼鐵之心 4'),(5344,'覺醒 - 女武神 1'),(5345,'覺醒 - 女武神 2'),(5346,'覺醒 - 女武神 3'),(5347,'覺醒 - 女武神 4'),(5350,'覺醒 - 魔術師 1'),(5351,'覺醒 - 魔術師 2'),(5352,'覺醒 - 魔術師 3'),(5353,'覺醒 - 魔術師 4'),(5401,'Test'),(5402,'Test'),(5403,'Test'),(5404,'Test'),(5405,'Test'),(5406,'Test'),(5407,'Test'),(5408,'Test'),(5409,'Test'),(5410,'Test'),(5411,'Test'),(5412,'Test'),(5413,'Test'),(5414,'Test'),(5415,'Test'),(5416,'Test'),(5417,'Test'),(5418,'Test'),(5419,'Test'),(5420,'Test'),(5421,'Test'),(5433,'Test'),(5442,'Test'),(5443,'Test'),(5444,'Test'),(5445,'Test'),(5446,'Test'),(5447,'Test'),(5448,'Test'),(5449,'Test'),(5450,'Test'),(5451,'Test'),(5452,'Test'),(5453,'Test'),(5454,'Test'),(5455,'Test'),(5456,'Test'),(5457,'Test'),(5458,'Test'),(5459,'Test'),(5460,'Test'),(5461,'Test'),(5462,'Test'),(5463,'Test'),(5465,'Test'),(5466,'Test'),(5467,'Test'),(5468,'Test'),(5469,'Test'),(5470,'Test'),(5471,'Test'),(5472,'Test'),(5473,'Test'),(5474,'Test'),(5475,'Test'),(5476,'Test'),(5477,'Test'),(5478,'時間之門區域冒險'),(5479,'Test'),(5480,'Test'),(5481,'Test'),(5650,'不祥的建築物'),(5651,'從地獄來的生物'),(5652,'來自地獄的生物'),(5653,'死神阿加雷斯'),(5654,'死神到底想要甚麼？'),(5655,'熱血沸騰的鍊金術師'),(5656,'終極鍊金術'),(5657,'不滅之藥'),(5658,'無盡的研究'),(5659,'挑戰無盡的祭壇'),(5660,'講述冒險故事'),(5661,'預言的道具'),(5678,'覺醒 - 銀月之刃 1'),(5679,'覺醒 - 銀月之刃 2'),(5680,'覺醒 - 銀月之刃 3'),(5681,'覺醒 - 銀月之刃 4'),(5684,'覺醒 - 死亡使者 1'),(5685,'覺醒 - 死亡使者 2'),(5686,'覺醒 - 死亡使者 3'),(5687,'覺醒 - 死亡使者 4'),(5720,'偵查野營地'),(5721,'新的敵人'),(5722,'一夜的作戰'),(5723,'再次突襲'),(5724,'收集情報'),(5725,'敵人的真面目1'),(5726,'敵人的真面目2'),(5727,'不可告人的交易'),(5728,'擊退雜技團'),(5729,'敵人的噩夢之夜'),(5730,'麻煩的小矮人'),(5731,'掌握野營地構造'),(5732,'愛美之心'),(5733,'特殊的火種'),(5734,'甜美的夢'),(5741,'這個夜晚不再寒冷'),(5742,'愛美是女人的天性'),(5743,'探索補給基地'),(5744,'破壞武器倉庫'),(5745,'尋找敵人的糧食'),(5746,'破壞糧食倉庫'),(5747,'補給部隊的首長是？'),(5748,'吉賽爾博士的陰謀'),(5749,'被改造的士兵們'),(5750,'生物實驗的真相'),(5751,'終極實驗體'),(5752,'彈藥改造'),(5753,'槍械如同愛人'),(5754,'今天我來當廚師 (1/2)'),(5755,'缺乏工具'),(5756,'零件調配'),(5765,'追擊吉賽爾'),(5766,'准將尼貝爾'),(5767,'魯莽的柯維'),(5768,'秘密武器飛燕'),(5769,'特種部隊集結'),(5770,'亡命者'),(5771,'背信者的嚴懲'),(5772,'無名女人'),(5773,'她的過去'),(5774,'戰鬥準備'),(5775,'破壞掩蔽物'),(5776,'天寒地凍'),(5777,'消滅幹部'),(5778,'控制黑暗的人'),(5779,'最終作戰'),(5780,'搜查殲滅'),(5781,'總決戰'),(5784,'彈藥改造專家'),(5785,'籌措工具'),(5786,'士兵的生命'),(5787,'悄無聲息'),(5788,'擾亂敵軍計畫'),(5789,'梅爾文·里克特的愛好'),(5790,'百姓的痛苦'),(5791,'收集樣品'),(5793,'戰場上的友情'),(5796,'希望的火種'),(5797,'保障物資'),(5798,'殲滅最後的敵人'),(5799,'溫暖人心'),(5800,'尋找盜賊團的痕跡'),(5801,'沙中振翅'),(5802,'血蝶之舞'),(5803,'摩斯昆的蜂針'),(5804,'破壞蟲繭'),(5805,'失蹤的特工'),(5806,'如果不想要樹立敵人，'),(5807,'食夢樹'),(5808,'神奇的夢之粉'),(5809,'冒險家的夢'),(5810,'失蹤的特工'),(5811,'如果不想要樹立敵人，'),(5812,'食夢樹'),(5813,'神奇的夢之粉'),(5814,'冒險家的夢'),(5816,'強身健體'),(5817,'液狀表皮細胞'),(5818,'最好不要去打擾蜂巢'),(5819,'破壞蟲繭'),(5820,'最好不要去打擾蜂巢'),(5821,'如果不想要樹立敵人，'),(5824,'珍貴材料'),(5825,'暗精靈的智慧'),(5826,'虛空魔石'),(5827,'虛空魔石 (重複)'),(5828,'英雄 - 英雄的夢'),(5829,'[英雄] 與西嵐的夢'),(5831,'幻影手鐲 1/2'),(5832,'幻影手鐲 2/2'),(5833,'幻影手鐲在一個'),(5836,'前往懸空的海港！'),(5837,'要搭乘海上列車嗎？'),(5838,'第一次交易'),(5839,'列車上的黑色鱗片'),(5840,'第二次交易'),(5841,'在天界被同化的美人魚'),(5842,'鱷魚的巢穴'),(5843,'天界珍珠'),(5844,'初隆的好朋友，空空'),(5845,'鱷魚的巢穴'),(5846,'天界珍珠 (重複)'),(5847,'我不要嫁給雄人魚！！'),(5848,'我不要嫁給雄人魚！！'),(5849,'尋找空空伊'),(5850,'鐵鱗海盜團（團員）'),(5851,'鐵鱗海盜團（副船長）'),(5852,'鐵鱗海盜團（船長）'),(5853,'鐵鱗海盜團（艦長）'),(5859,'交換船員的戒指 '),(5860,'深海項鍊 (1/2)'),(5861,'深海項鍊 (2/2)'),(5862,'重領深海項鍊'),(5863,'天界生命體的變化'),(5864,'卡勒特裝備搬運列車時'),(5865,'世上沒有免費的午餐'),(5866,'確認列車內部'),(5867,'破壞運輸中的裝備'),(5868,'有用的零件'),(5869,'烏龜'),(5870,'最高級的鐵鱗'),(5871,'海賊團頭目'),(5872,'堅硬的龜殼'),(5873,'堅硬的龜殼 (重複)'),(5874,'這裡也有空空？'),(5875,'貴賓用桌子'),(5876,'有用的零件'),(5877,'破壞運輸中的裝備'),(5878,'貴賓用桌子'),(5889,'疑惑之村'),(5890,'翡翠戒指'),(5891,'佩戴翡翠戒指的少女'),(5892,'悲慘的村莊'),(5893,'具有生氣的頭髮'),(5894,'響尾蛇的尾巴'),(5895,'灰色結晶 (大)'),(5899,'紅色鑽石'),(5900,'破壞油桶'),(5901,'到底是不是寶箱'),(5902,'噁心的怪物'),(5903,'修練的好對象'),(5904,'紅色鑽石 (重複)'),(5905,'破壞油桶'),(5906,'到底是不是寶箱'),(5907,'噁心的溶解怪'),(5908,'修練的好對象'),(5924,'既然如此，連瓷器也'),(5925,'貴重的瓷器'),(5926,'交換副船長的戒指'),(5928,'梅爾文·里克特的高科�'),(5929,'重領高科技戒指'),(5950,'收集徽章'),(5951,'收集階級章'),(6501,'Lv10及以上的角色可在G.'),(6502,'Lv12及以上的角色可在�'),(6503,'Lv14及以上的角色可在�'),(6504,'Lv16及以上的角色可在�'),(6505,'Lv18及以上的角色可在�'),(6506,'Lv20及以上的角色可在�'),(6507,'Lv22及以上的角色可在�'),(6508,'Lv25及以上的角色可在�'),(6509,'Lv25及以上的角色可在G.'),(6510,'Lv28及以上的角色可在�'),(6511,'Lv32及以上的角色可在�'),(6512,'Lv34及以上的角色可在�'),(6513,'Lv36及以上的角色可在�'),(6514,'Lv39及以上的角色可在�'),(6515,'Lv40及以上的角色可在�'),(6516,'Lv43及以上的角色可在�'),(6517,'Lv44及以上的角色可在�'),(6518,'Lv46及以上的角色可在�'),(6519,'Lv48及以上的角色可在�'),(6520,'Lv49及以上的角色可在�'),(6521,'Lv51及以上的角色可在�'),(6522,'Lv53及以上的角色可在�'),(6523,'Lv54及以上的角色可在�'),(6524,'Lv58及以上的角色可在�'),(6525,'Lv60及以上的角色可在�'),(6526,'Lv63及以上的角色可在�'),(6527,'Lv64及以上的角色可在�'),(6528,'Lv65級可在貝倫‧博內�'),(6529,'Lv65級可在貝倫‧博內�'),(6530,'Lv65級可在貝倫‧博內�'),(6531,'角色達到Lv70。'),(6532,'使用技能時， 消耗10000'),(6533,'背擊攻擊達到500次。'),(6534,'在地下城中， 攻擊敵�'),(6535,'在地下城， 最高連擊�'),(6536,'一次攻擊同時被5名及�'),(6537,'解體裝備時獲得50個以�'),(6538,'Lv66級可在貝倫‧博內�'),(6539,'角色達到Lv70後， 將剩�'),(6540,'為隊友使用50個復活幣�'),(6541,'組隊時， 出現10次擲出'),(6542,'組隊時， 獲得100個以�'),(6543,'使用人形師製作的女性'),(6544,'使用人形師製作的男性'),(6545,'Lv50級可在莎蘭處接受�'),(6546,'在10分鐘內， 通過死中'),(6547,'在死中孜薴丑A 被死中�'),(6548,'通過死中孜臐A 並且不�'),(6549,'Lv52級可在賽莉亞處接�'),(6550,'Lv52級可在賽莉亞處接�'),(6551,'Lv52級可在賽莉亞處接�'),(6552,'Lv52級可在賽莉亞處接�'),(6553,'Lv52級可在賽莉亞處接�'),(6554,'Lv52級可在賽莉亞處接�'),(6555,'在異界地下城中， 獨�'),(6556,'在新異界地下城(巴卡�'),(6557,'在新異界地下城(巴卡�'),(6558,'在10分鐘內， 通過蘭蒂'),(6559,'在蠕動之城內的3個龍�'),(6560,'哥布林王國用中央裝置'),(6561,'哥布林王國克利克的憤'),(6562,'[黑色大地]地下城中， '),(6563,'[異界裂縫]領主房間中�'),(6564,'[巴卡爾之城]領主的DDR�'),(6565,'除了輔助裝備、 魔法�'),(6566,'除了稱號之外， 所有�'),(6567,'裝備Lv55以上的神器等�'),(6568,'穿戴Lv50以上的神器等�'),(6569,'開啟100個土罐出售的袖'),(6570,'開啟300個火罐出售的袖'),(6571,'開啟300個木罐出售的袖'),(6572,'開啟300個水罐出售的袖'),(6573,'開啟150個金罐出售的袖'),(6574,'開啟100個初隆出售的袖'),(6575,'野草莓、 有機草莓、 �'),(6576,'累計消耗1000個銳眼藥�'),(6577,'技能初始化5次'),(6578,'累計消耗500個軍糧 (皇�'),(6579,'累計消耗500個鍊金術師'),(6580,'擁有麵包和牛奶各1000�'),(6581,'擁有30件及以上的裝扮�'),(6582,'穿戴克隆稀有裝扮的部'),(6583,'擁有孵化的寵物達到5�'),(6584,'將裝扮重鑄為徽章10次�'),(6585,'擁有不同顏色的大晶體'),(6586,'擁有200個[強烈之痕跡]�'),(6587,'擁有50個[濃縮的純潔之'),(6588,'擁有[燦爛的宇宙靈魂]�'),(6589,'打破20個稀有級以上等�'),(6590,'將稀有及以上等級的裝'),(6591,'將某一個裝備強化至+15'),(6592,'在公平的決鬥場中， �'),(6593,'在決鬥場擂臺賽中， �'),(6594,'在決鬥場擂臺賽中， 0�'),(6595,'讓一個角色在城鎮中連'),(6596,'在DNF專屬網咖， ， 連�'),(6597,'施放主動覺醒技能達到'),(6598,'使用伺服器喇叭或解放'),(6599,'進行3次街頭爭霸。'),(6600,'通過絕望之塔第1層。'),(6601,'通過絕望之塔第3層。'),(6602,'通過絕望之塔第5層。'),(6603,'通過絕望之塔第7層。'),(6604,'通過絕望之塔第8層。'),(6605,'通過絕望之塔第9層。'),(6606,'通過絕望之塔第11層。'),(6607,'通過絕望之塔第14層。'),(6608,'通過絕望之塔第16層。'),(6609,'通過絕望之塔第17層。'),(6610,'通過絕望之塔第18層。'),(6611,'通過絕望之塔第21層。'),(6612,'通過絕望之塔第22層。'),(6613,'通過絕望之塔第24層。'),(6614,'通過絕望之塔第25層。'),(6615,'通過絕望之塔第27層。'),(6616,'通過絕望之塔第28層。'),(6617,'通過絕望之塔第29層。'),(6618,'通過絕望之塔第31層。'),(6619,'通過絕望之塔第33層。'),(6620,'通過絕望之塔第34層。'),(6621,'通過絕望之塔第35層。'),(6622,'通過絕望之塔第36層。'),(6623,'通過絕望之塔第38層。'),(6624,'通過絕望之塔第39層。'),(6625,'通過絕望之塔第43層。'),(6626,'通過絕望之塔第44層。'),(6627,'通過絕望之塔第45層。'),(6628,'通過絕望之塔第46層。'),(6629,'通過絕望之塔第47層。'),(6630,'通過絕望之塔第49層。'),(6631,'通過絕望之塔第55層。'),(6632,'通過絕望之塔第59層。'),(6633,'通過絕望之塔第61層。'),(6634,'通過絕望之塔第63層。'),(6635,'通過絕望之塔第68層。'),(6636,'通過絕望之塔第69層。'),(6637,'通過絕望之塔第73層。'),(6638,'通過絕望之塔第78層。'),(6639,'通過絕望之塔第82層。'),(6640,'通過絕望之塔第83層。'),(6641,'通過絕望之塔第84層。'),(6642,'通過絕望之塔第88層。'),(6643,'通過絕望之塔第89層。'),(6644,'通過絕望之塔第93層。'),(6645,'通過絕望之塔第95層。'),(6646,'通過絕望之塔第97層。'),(6647,'通過絕望之塔第98層。'),(6648,'通過絕望之塔第100層。'),(6649,'一般難度以上通過[巴�'),(6650,'被絕望之泰瑪特的絕望'),(6651,'在空間支配者卡烏尼斯'),(6652,'完成從Lv71 克倫特獲得�'),(6653,'完成Lv72西嵐給予的「�'),(6654,'完成在Lv73歌蘭蒂斯獲�'),(6655,'完成LV75西嵐給予的「�'),(6656,'完成Lv76俊給予的「少�'),(6657,'完成Lv77艾麗絲給予的�'),(6658,'完成Lv78 佩勒威因給的�'),(6659,'完成Lv79 中尉尼貝爾給�'),(6660,'完成Lv80 中尉尼貝爾給�'),(6661,'完成Lv81 中尉尼貝爾給�'),(6662,'完成Lv82 佩勒威因給的�'),(6700,'活動已結束。'),(6701,'活動已結束。'),(6702,'活動已結束。'),(6703,'活動已結束。'),(6704,'活動已結束。'),(6705,'活動已結束。'),(6706,'在普通或者公會聊天欄'),(6707,'使用[活力小狗]12個。 ('),(6708,'破招攻擊數達到777次。'),(6709,'成功使用[命運硬幣]、 '),(6710,'累計消滅2012隻怪物。'),(6711,'使用15個以下的[無色小'),(7100,'夜間襲擊戰 - 時間'),(7101,'夜間襲擊戰 - 被擊數'),(7104,'夜間襲擊戰 - 復活次數'),(7105,'夜間襲擊戰 - 默契'),(7106,'夜間襲擊戰 - 連擊率(Co'),(7107,'夜間襲擊戰 - 背後偷襲'),(7108,'夜間襲擊戰 - 破敵制勝'),(7109,'夜間襲擊戰 - 最大連擊'),(7110,'夜間襲擊戰 - 地圖通過'),(7113,'夜間襲擊戰 - 群體攻擊'),(7114,'補給線阻斷戰 - 時間'),(7115,'補給線阻斷戰 - 被擊數'),(7118,'補給線阻斷戰 - 復活次'),(7119,'補給線阻斷戰 - 默契'),(7120,'補給線阻斷戰 - 連擊率'),(7121,'補給線阻斷戰 - 背後偷'),(7122,'補給線阻斷戰 - 破敵制'),(7123,'補給線阻斷戰 - 最大連'),(7124,'補給線阻斷戰 - 地圖通'),(7127,'補給線阻斷戰 - 群體攻'),(7128,'追擊殲滅戰 - 時間'),(7129,'追擊殲滅戰 - 被擊數'),(7132,'追擊殲滅戰 - 復活次數'),(7133,'追擊殲滅戰 - 默契'),(7134,'追擊殲滅戰 - 連擊率(Co'),(7135,'追擊殲滅戰 - 背後偷襲'),(7136,'追擊殲滅戰 - 破敵制勝'),(7137,'追擊殲滅戰 - 最大連擊'),(7138,'追擊殲滅戰 - 地圖通過'),(7141,'追擊殲滅戰 - 群體攻擊'),(7142,'血蝴蝶之舞 - 時間'),(7143,'血蝴蝶之舞 - 被擊數'),(7146,'血蝴蝶之舞 - 復活次數'),(7147,'血蝴蝶之舞 - 默契'),(7148,'血蝴蝶之舞 - 連擊率(Co'),(7149,'血蝴蝶之舞 - 背後偷襲'),(7150,'血蝴蝶之舞 - 破敵制勝'),(7151,'血蝴蝶之舞 - 最大連擊'),(7152,'血蝴蝶之舞 - 地圖通過'),(7155,'血蝴蝶之舞 - 群體攻擊'),(7156,'疑惑之村 - 時間'),(7157,'疑惑之村 - 被擊數'),(7160,'疑惑之村 - 復活次數'),(7161,'疑惑之村 - 默契'),(7162,'疑惑之村 - 連擊率(Combo'),(7163,'疑惑之村 - 背後偷襲'),(7164,'疑惑之村 - 破敵制勝(Co'),(7165,'疑惑之村 - 最大連擊數'),(7169,'疑惑之村 - 群體攻擊'),(7170,'列車上的海賊 - 時間'),(7171,'列車上的海賊 - 被擊數'),(7174,'列車上的海賊 - 復活次'),(7175,'列車上的海賊 - 默契'),(7176,'列車上的海賊 - 連擊率'),(7177,'列車上的海賊 - 背後偷'),(7178,'列車上的海賊 - 破敵制'),(7179,'列車上的海賊 - 最大連'),(7180,'列車上的海賊 - 地圖通'),(7183,'列車上的海賊 - 群體攻'),(7184,'奪回西部線 - 時間'),(7185,'奪回西部線 - 被擊數'),(7188,'奪回西部線 - 復活次數'),(7189,'奪回西部線 - 默契'),(7190,'奪回西部線 - 連擊率(Co'),(7191,'奪回西部線 - 背後偷襲'),(7192,'奪回西部線 - 破敵制勝'),(7193,'奪回西部線 - 最大連擊'),(7194,'奪回西部線 - 地圖通過'),(7197,'奪回西部線 - 群體攻擊'),(7310,'貝利特的考驗 - 決鬥勝'),(7312,'貝利特的考驗 - 迷妄之'),(7313,'貝利特的考驗 - 死亡之'),(7314,'貝利特的考驗 - 死亡之'),(7315,'貝利特的考驗 - 根特週'),(7316,'貝利特的考驗 - 根特東'),(7317,'貝利特的考驗 - 根特南'),(7318,'貝利特的考驗 - 古代地'),(7319,'貝利特的考驗 - 收集徽'),(7320,'貝利特的考驗 - 宇宙靈'),(7322,'貝利特的考驗 - 連擊殺'),(7323,'貝利特的考驗 - 連擊殺'),(7324,'貝利特的考驗 - 連擊殺'),(7325,'貝利特的考驗 - 通過死'),(7326,'貝利特的考驗 - 死亡之'),(7327,'貝利特的考驗 - 決鬥勝'),(7328,'貝利特的考驗 - 宇宙靈'),(7329,'貝利特的考驗 - 時間根'),(7330,'貝利特的考驗 - 時間根'),(7331,'貝利特的考驗 - 時間根'),(7332,'貝利特的考驗 - 攻略所'),(7333,'貝利特的考驗 - 攻略所'),(7334,'貝利特的考驗 - 攻略所'),(7336,'貝利特的考驗 - 收集材'),(7337,'貝利特的考驗 - 收集材'),(7338,'貝利特的考驗 - 卡勒特'),(7612,'覺醒 - 狂虎帝 1'),(7613,'覺醒 - 狂虎帝 2'),(7614,'覺醒 - 狂虎帝 3'),(7615,'覺醒 - 狂虎帝 4'),(7618,'覺醒 - 武極1 '),(7619,'覺醒 - 武極2 '),(7620,'覺醒 - 武極3 '),(7621,'覺醒 - 武極4 '),(7628,'覺醒 - 千手羅漢 1'),(7629,'覺醒 - 千手羅漢 2'),(7630,'覺醒 - 千手羅漢 3'),(7631,'覺醒 - 千手羅漢 4'),(7634,'覺醒 - 泰坦 1'),(7635,'覺醒 - 泰坦 2'),(7636,'覺醒 - 泰坦 3'),(7637,'覺醒 - 泰坦 4'),(7640,'格鬥家之路 - 開始'),(7641,'格鬥家之路 - 赫頓瑪爾'),(7642,'格鬥家之路 - 所謂的轉'),(7643,'更強的敵人'),(7644,'G.S.D的試驗'),(7645,'新武器的威力'),(7646,'格鬥家之路 - 風震'),(7647,'格鬥家之路 - 任務商店'),(7648,'[古代地下城] 林納斯的'),(7649,'[古代地下城] 布萬加的'),(7650,'[古代地下城] 探索悲鳴'),(7651,'[古代地下城] 強大的支'),(7652,'[古代地下城]  支援者�'),(7680,'Test'),(7681,'Test'),(7682,'Test'),(7683,'Test'),(7684,'Test'),(7685,'Test'),(7686,'Test'),(7687,'Test'),(7688,'Test'),(7689,'Test'),(7690,'Test'),(7691,'Test'),(7704,'Test'),(7705,'Test'),(7706,'Test'),(7707,'Test'),(7708,'Test'),(7709,'Test'),(7710,'Test'),(7711,'Test'),(7803,'轉職 - 劍魂（WeaponMaster'),(7807,'轉職 - 噬魂者（Soulbring'),(7810,'轉職 - 狂戰士（Berserker'),(7814,'轉職 - 阿修羅（Asura）'),(7817,'轉職 -鬥氣師（NEN Master'),(7820,'轉職 - 武鬥（Striker）'),(7824,'轉職 - 街霸（Street Fight'),(7827,'轉職 - 柔道家（Grappler�'),(7831,'轉職 - 遊俠（Ranger）'),(7834,'轉職 - 重炮手（Launcher�'),(7837,'轉職 - 機械師（Mechanic�'),(7840,'轉職 - 魔彈射手（Spitfi'),(7842,'轉職 - 元素使（Elemental'),(7845,'轉職 - 召喚士（Summoner�'),(7848,'轉職 - 魔鬥士（Battle Ma'),(7851,'轉職 - 魔道學者（Witch�'),(7855,'轉職 - 聖騎士（Crusader�'),(7859,'轉職 - 藍拳聖使（Infigh'),(7862,'轉職 - 驅魔師（Exorcist�'),(7866,'轉職 - 復仇者（Avenger�'),(7870,'轉職 - 遊俠（Ranger）'),(7873,'轉職 - 重炮手（Launcher�'),(7876,'轉職 - 機械師（Mechanic�'),(7879,'轉職 - 魔彈射手（Spitfi'),(7882,'轉職 - 暗行御史（Rogue�'),(7886,'轉職 - 死靈術士（Necrom'),(7889,'轉職 -鬥氣師（NEN Master'),(7892,'轉職 - 武鬥（Striker）'),(7895,'轉職 - 街霸（Street Fight'),(7898,'轉職 - 柔道家（Grappler�'),(9501,'新生的DNF'),(9502,'端午好 Fun 粽！'),(9503,'深淵的碎片');
/*!40000 ALTER TABLE `quest_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_state_info`
--

DROP TABLE IF EXISTS `server_state_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_state_info` (
  `category` int(11) NOT NULL DEFAULT '-1',
  `code` int(11) NOT NULL DEFAULT '-1',
  `state` binary(12) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0',
  `start_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`category`,`code`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_state_info`
--

LOCK TABLES `server_state_info` WRITE;
/*!40000 ALTER TABLE `server_state_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_state_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `single_rank_avg`
--

DROP TABLE IF EXISTS `single_rank_avg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `single_rank_avg` (
  `dungeon_index` smallint(6) NOT NULL DEFAULT '0',
  `level` smallint(6) NOT NULL DEFAULT '0',
  `job` smallint(6) NOT NULL DEFAULT '0',
  `clear_count` bigint(20) NOT NULL DEFAULT '0',
  `average` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dungeon_index`,`level`,`job`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `single_rank_avg`
--

LOCK TABLES `single_rank_avg` WRITE;
/*!40000 ALTER TABLE `single_rank_avg` DISABLE KEYS */;
/*!40000 ALTER TABLE `single_rank_avg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sp_reward`
--

DROP TABLE IF EXISTS `sp_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sp_reward` (
  `grade` int(11) NOT NULL DEFAULT '0',
  `sp` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sp_reward`
--

LOCK TABLES `sp_reward` WRITE;
/*!40000 ALTER TABLE `sp_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `sp_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stat_game_channel`
--

DROP TABLE IF EXISTS `stat_game_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stat_game_channel` (
  `gc_channel` varchar(10) NOT NULL DEFAULT '',
  `gc_up_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gc_now` smallint(6) NOT NULL DEFAULT '0',
  KEY `gc_channel` (`gc_channel`,`gc_up_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stat_game_channel`
--

LOCK TABLES `stat_game_channel` WRITE;
/*!40000 ALTER TABLE `stat_game_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `stat_game_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
